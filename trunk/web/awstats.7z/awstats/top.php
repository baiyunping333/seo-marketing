﻿<?php
$params = array();
if (isset($_GET['year']) && isset($_GET['month'])) {
    $params = array(
        'year' => $_GET['year'],
        'month' => $_GET['month'],
    );
}
if (isset($_GET['domain'])){
	$params['domain']= $_GET['domain'];
}
$params['toUrl']="/cgi-bin/awstats.pl";
$isrefresh=0;
if (isset($_GET['isrefresh'])){
	$isrefresh=$_GET['isrefresh'];
}
include 'Calendar.php';
$cal = new Calendar($params);
$defaultUrl= $cal->defaultUrl();
?>
 
<html>
    <head>
        <title>日历demo</title>
        <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
		<script type="text/javascript">
			var isrefresh=<?php echo $isrefresh;?>;
			function load(){
				if (isrefresh){
					top.mainFrame.location.href="<?php echo $params['toUrl'].$defaultUrl;?>";
				}
			}
		</script>
        <style type="text/css">
			
			select {font-size:12px;}
			select option {font-size:12px;}
			form{margin:0}  
            table.calendar {
                border: 0px solid #050;
				font-size:12px;
				valign:top;
				topmargin:0px; 
            }
            .calendar th, .calendar td {
                width:40px;
				height:12px;
                text-align:center;
				font-size:12px;
            }           
            .calendar th {
                background-color:#050;
                color:#fff;
				height:12px;
				font-size:12px;
            }
            .today{
			color:#fff;
			background-color:#050;  
			font-size:12px;			
            }
        </style>
    </head>
	
    <body topmargin=0px leftmargin=0px onload="load()">
	<div style="padding-left:0px;padding-top:0px;position:absolute;top:-5px;left:0px;" >
            <?php
                $cal->display();
            ?>   
	</div>
    </body>
	
</html>
