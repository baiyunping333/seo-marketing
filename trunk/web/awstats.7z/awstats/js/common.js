$(function(){
	//leftMenu
	$('.leftMenu .m cite').click(function(){
		var $cite=$(this);
		var $sub=$(this).next(".sub");
		var isVisible=!($sub[0].style.display=="block");
		$sub.toggle();
		if(isVisible){
			$cite.css("background-image","url(images/minus.gif)");
		}else{
			$cite.css("background-image","url(images/add.gif)");
		}
	});
});