<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';

	if( $Types == "1" ) 
	{
		//��¼����
		$Res = $Conn->Execute( " select id from $TableList[ip_limit] where website = '$website' group by pageurl" );
		$DataCount = $Res->RecordCount();

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select count(id) as counts,pageurl as page,pagetitle from $TableList[ip_limit] where website = '$website' group by page ORDER BY `counts` DESC ", $PageSize,$PageItems[Offset] );

		while( $Tmp = @$Res->FetchRow() )
		{
			$Tmp[pagetitle] = $Tmp[pagetitle] == ""?"�ޱ����ĵ�":$Tmp[pagetitle];
			$Tmp[urlpage] = urlencode($Tmp[page]);
			preg_match( "|http://[^/]+?(/.*)|is", $Tmp[page], $Tmp1 );
			$Tmp[pageshort] = trim( $Tmp1[1] );	
			$CountAll += $Tmp[counts];
			//ҳ������
			if($Types == 1)
			{
				$Res2 = $Conn->Execute( " select counts from $TableList[page] where page = '$Tmp[page]' and types = 4 and website = '$website' order by times desc limit 1");
				$Tmp2 = @$Res2->FetchRow();
				if($Tmp[counts] >= $Tmp2[counts])
				{				
					$precent = @sprintf("%01.2f",(($Tmp[counts]-$Tmp2[counts])/$Tmp2[counts]) ) * 100;
					$title   = "<FONT COLOR=#0000ff>��</FONT>(+".$precent."%)";
					$Tmp[title] = $title;
				}
				if($Tmp[counts] < $Tmp2[counts])
				{				
					$precent = @sprintf("%01.2f",(($Tmp2[counts]-$Tmp[counts])/$Tmp2[counts]) ) * 100;
					$title   = "<FONT COLOR=#ff0000>��</FONT>(-".$precent."%)";
					$Tmp[title] = $title;
				}
			}

			
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Datas[] = $Tmp;
			$DatasPage[$Tmp[page]] = array('counts'=>$Tmp[counts]);
			$SqlDatas[] = array('page'=>$Tmp[page],'pagetitle'=>$Tmp[pagetitle],'pvcounts'=>$Tmp[counts]);

		}
		unset($Tmp);unset($Res);
		$Res = $Conn->SelectLimit( " select *  from $TableList[adv] where website = '$website'");
		while( $Tmp = @$Res->FetchRow() )
		{	
			$DatasAds[$Tmp[urls]][] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
		}		
	}

##############################################################
	if( $Types == "0" or $Types == "2" ) 
	{
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where = " and times >= $StartTime and times < $EndTime ";
		}
		$Res = $Conn->Execute( " select pageid from $TableList[page] where types = 4 and website = '$website' $Where group by page" );
		$DataCount = $Res->RecordCount();

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select sum(counts) as counts,pagetitle ,page from $TableList[page] where types = 4 and website = '$website' $Where group by page ORDER BY `counts` DESC ", $PageSize,$PageItems[Offset] );

		while( $Tmp = @$Res->FetchRow() )
		{			
			$Tmp[pagetitle] = $Tmp[pagetitle] == ""?"�ޱ����ĵ�":$Tmp[pagetitle];
			$Tmp[urlpage] = urlencode($Tmp[page]);
			preg_match( "|http://[^/]+?(/.*)|is", $Tmp[page], $Tmp1 );
			$Tmp[pageshort] = trim( $Tmp1[1] );	
			$CountAll += $Tmp[counts];
			
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Datas[] = $Tmp;			
			$SqlDatas[] = array('page'=>$Tmp[page],'pagetitle'=>$Tmp[pagetitle],'pvcounts'=>$Tmp[counts]);

		}
		
	}
##############################################################
	if( count($Datas) > 0 )
	foreach( $Datas as $key => $Val )
	{
		$Datas[$key][percent] = sprintf("%01.2f", ( $Datas[$key][counts]/$CountAll ) * 100 );	
	}

	$Tpl->assign( 'Datas', $Datas );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('���ҳ��','ҳ�����','���յ��(PV)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode(" select page,pagetitle,counts as pvcounts from $TableList[page] where types = $Types and website = '$website' ORDER BY `counts` DESC  ") );
	$Tpl->assign( 'fname', 'page' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	//$Tpl->assign( 'Main', $Tpl->fetch( 'entry_exit_page.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '���ҳ�� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', "���ҳ��");
	$Tpl->assign( 'Main', $Tpl->fetch( 'entry_exit_page.html' ) . $ScriptCode );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>