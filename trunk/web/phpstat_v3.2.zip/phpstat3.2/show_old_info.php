<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/09	
*/
/*
	�޸��ļ����Լ��鿴ģʽ
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'page'=>'intval' ,'types'=>'intval','website'=>'strval','Date_Day'=>'intval','Date_Month'=>'intval','Date_Year'=>'intval') );
	include_once 'initmenu.php';
	$Year  = $_GET[Date_Year]  == 0?date( 'Y' ):$_GET[Date_Year];
	$Month = $_GET[Date_Month] == 0?date( 'm' ):$_GET[Date_Month];
	$Day   = $_GET[Date_Day]   == 0?date( 'd' ):$_GET[Date_Day];
	$StartTime = mktime (0,0,0,$Month,$Day,$Year ) - 86400;
	$EndTime = mktime (0,0,0,$Month,$Day,$Year );

	$Title = "���շ�����ϸ";
	if($_GET[Date_Year] or $_GET[Date_Month] or $_GET[Date_Day])
	{
		$Title = date("Y-m-d",$StartTime)." �շ�����ϸ";	
	}
	//ͳ��ͼ
	$Res = $Conn->Execute( " select * from $TableList[day_data] where times = $StartTime and  website = '$website'" );
	$Row = $Res->FetchRow();	
	for( $i = 0; $i < 24; $i++ )
	{
		$CountIp = $Row["hourip$i"] + rand(NUM1,NUM2);
		$Count = $Row["hour$i"] + rand(NUM1,NUM2);
		if( strlen( $i ) == 1 ) $j = '0'.$i;
		else $j = $i;
		$Tmp[] = $j.','.$CountIp.','.$Count;
	}
	$Datas = implode( ';', $Tmp);
	$Tpl->assign( 'Data_Tu', $Datas );
	unset($Datas);
	//��¼����
	$Res = $Conn->Execute( " select count(*) as count  from $TableList[ip_history] where `time` <= $EndTime and `time` >= $StartTime and  website = '$website'" );
	$Count = $Res->FetchRow();
	$DataCount = $Count[count];

	$PageSize = 20;
	if( $DataCount > 0 )
	{
		include_once ( './include.inc/page.inc.php' );
		$PageItems = MakePageItems ( $DataCount, $PageSize );
		$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
		$Tpl->assign( 'PageLinks', $PageLinks );
	}
	if($PageItems[Offset] == "")$PageItems[Offset] = 0;
	$Res = $Conn->SelectLimit( " select *  from $TableList[ip_history] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' ORDER BY `time` DESC ", $PageSize ,$PageItems[Offset] );

	include_once './include.inc/function_timezone.php';
	include_once './include.inc/function_language.php';
	include_once './include.inc/function_system.php';

	while( $Tmp = $Res->FetchRow() )
	{
		$Tmp[language] = GetLanguage( $Tmp[language] );
		$Tmp[timezone] = GetTimeZone( $Tmp[timezone] );
		$Tmp[system]   = GetSystem( $Tmp[system] );
		preg_match( "|http://[^/]+?(/.*)|is", $Tmp[pageurl], $Tmp1 );
		$Tmp[pagesite] = trim( $Tmp1[1] );
        if( $Tmp[firsttime] == $Tmp[lasttime] )
		{
			$Tmp[isfirst] = "<span style='color:red'>*</span>";
		}
		
		$Tmp[firsttime] = @date("Y-m-d H:i:s",$Tmp[firsttime]);
		$Tmp[lasttime] = date("Y-m-d H:i:s",$Tmp[lasttime]);
		$Tmp[time] = date("Y-m-d H:i:s",$Tmp[time]);
		$Datas[] = $Tmp;
		$SqlDatas[] = array('datetimes'=>$Tmp[time],'ip'=>$Tmp[ip],'address'=>$Tmp[country].$Tmp[province].$Tmp[city].$Tmp[address],'pvcounts'=>$DataCountNum);
	}
	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'Day', $Day );	
	$Tpl->assign( 'DataTime', $StartTime );

	$Tpl->assign( 'Datas', $Datas );
	$Tpl->assign( 'website', $website );
	
	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('ʱ��','IP��ַ','����','�������(PV)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode("select time as datetime,ip as IP,CONCAT(country,province,city,address) as address from $TableList[ip_history] where `time` <= $EndTime and `time` >= $StartTime and website = '$website'  ORDER BY `time` DESC") );
	$Tpl->assign( 'fname', 'show_today_old' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'Main', $Tpl->fetch( 'show_old_info.html' ) );

	$Tpl->assign( 'Title', $Title. '- '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'QuickLink', "   <a href=show_old.php?website=$website>����ģʽ���</a>" );
	if( $_GET[Date_Year] )
	$Tpl->assign( 'QuickLink', "   <a href=show_old.php?website=$website&Date_Month=$_GET[Date_Month]&Date_Day=$_GET[Date_Day]&Date_Year=$_GET[Date_Year]>����ģʽ���</a>" );
	$Tpl->assign( 'NowView', $Title );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>