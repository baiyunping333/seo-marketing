<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
	describe:����ͳ��
*/

	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';	
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	
	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval','website'=>'strval','sub'=>'strval'  ) );
	$website = $_GET[website];
	include_once 'initmenu.php';
	
	
	if( $Types == "1" )
	{

		//��¼����
		
		$Res = $Conn->Execute( " select id from $TableList[ip_limit] where website = '$website' group by address" );
		$Count = $Res->FetchRow();
		$DataCount = $Res->RecordCount();

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select count(id) as counts,address from $TableList[ip_limit] where website = '$website' group by address ORDER BY `counts` DESC ",$PageSize , $PageItems[Offset]  );
		
		$CountAll = 0;//�����ܺ�
		while( $Tmp = @$Res->FetchRow() )
		{			
			$Tmp[area] = $Tmp[address];
			$CountAll += $Tmp[counts];
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Datas[] = $Tmp;
			$SqlDatas[] = array('area'=>$Tmp[area],'ipcounts'=>$Tmp[counts]);
		}
	}

	if( $Types == "0" or $Types == "2" )
	{
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where = " and times >= $StartTime and times < $EndTime ";
		}		
		$Res = $Conn->Execute( " select count(areaid) from $TableList[area] where types = 3 and website = '$website' $Where group by area" );
		$Count = $Res->FetchRow();
		$DataCount = $Count[count];

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select sum(counts) as counts,area from $TableList[area] where types = 3 and website = '$website' $Where group by area ORDER BY `counts` DESC ",$PageSize , $PageItems[Offset]  );
		
		$CountAll = 0;//�����ܺ�
		while( $Tmp = @$Res->FetchRow() )
		{
			preg_match( "|(http://[^/]+?)/.*|isU", $Tmp[lastpage], $LastSite );
			$Tmp[lastsite] = trim( $LastSite[1] );
			$CountAll += $Tmp[counts];
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Datas[] = $Tmp;
			$SqlDatas[] = array('area'=>$Tmp[area],'ipcounts'=>$Tmp[counts]);
		}
	}
	if( count( $Datas ) > 0 )
	{
		foreach( $Datas as $Key=>$Val )
		{		
			
			$Datas[$Key][Percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );
			$Datas[$Key][percent] = & $Datas[$Key][Percent];
		}
	}
	$Tpl->assign( 'Datas', $Datas );
	
	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('����/���뷽ʽ','���ʴ���(IP)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode(" select area,counts as ipcounts from $TableList[area] where types = $Types and website = '$website' $where ORDER BY `counts` DESC ") );
	$Tpl->assign( 'fname', 'area' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'Main', $Tpl->fetch( 'area.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '����ͳ�� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '����ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">��������</a> <a href=\"?website=$website&type=2\">��������</a> <a href=\"?website=$website&type=0\">��������</a> " );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>