<object id=factory viewastext  style=display:none
  classid=clsid:1663ed61-23eb-11d2-b92f-008048fdd814
  codebase=smsx.cab#Version=6,2,433,70>
</object>
<script defer> 
function window.onload() { 
factory.printing.header = This is MeadCo 
factory.printing.footer = Advanced Printing by ScriptX 
factory.printing.portrait = false 
factory.printing.leftMargin = 1.0 
factory.printing.topMargin = 1.0 
factory.printing.rightMargin = 1.0 
factory.printing.bottomMargin = 1.0
} 
</script> 