<?
echo urldecode("%E5%9B%BD%E6%97%85&btnG=%E6%90%9C%E7%B4%A2");
?>