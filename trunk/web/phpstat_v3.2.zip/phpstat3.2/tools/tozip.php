<?
include_once './phpzip.inc.php';
$z = new PHPZip();
$z -> Zip("../myreport/", "../tmp/myreport.zip"); //����ָ��Ŀ¼
if(file_exists('../tmp/myreport.zip'))
include_once './downzip.php';
else header("location:../myreport/index.htm");
?>
