<?
$file_name="myreport.zip";
$file_dir="../tmp/";
$file=fopen($file_dir.$file_name,"r");
Header("Content-type: application/octet-stream");
Header("Accept-Ranges: bytes");
Header("Accept-Length: ".filesize($file_dir . $file_name));
Header("Content-Disposition: attachment; filename=" . $file_name);
echo fread($file,filesize($file_dir.$file_name));
fclose($file);
?>