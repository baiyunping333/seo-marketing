<?php

$data = array(
    'port'      =>      '6033',
    'host'      =>      'localhost',
    'name'      =>      'phpstat',
    'user'      =>      'root',
    'pass'      =>      'root'
);

?>