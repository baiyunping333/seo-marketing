<?
    include ("htmlparser.inc");
	function getPageTitle($htmlText)
	{	
		$parser = new HtmlParser($htmlText);
		$loopmark = false;
		
		while ($parser->parse()) 
		{	
			if( $loopmark )
				return  $parser->iNodeValue;
			if(strtolower($parser->iNodeName) == "title") 
			{
				$loopmark = true;			
			}
		}
	}
	
?>
