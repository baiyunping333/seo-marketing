<?
include_once './include.inc/global.inc.php';
$website = strval($_GET[website]);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

<title>RSS���� - <?=$SoftWareName.$SoftWareVersion?></title>
<link href="./templates/business/imagefiles/printstyle.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript" src="./templates/business/imagefiles/printfunc.js"></SCRIPT>
</head>
<SCRIPT LANGUAGE="JavaScript">
<!--
function killErrors()
{
  return true;
}

window.onerror = killErrors;
self.moveTo(200,210); 
self.resizeTo(700,300);
self.focus(); 
window.defaultStatus="��ҳ60���Ӻ��Զ��ر�"; 
setTimeout("window.close()",60000);
//-->
</SCRIPT>
<body topmargin="0">
<center>
  <p><br>
    <strong>RSS���� </strong></p>
  <p><strong>
    <input name="textfield" type="text" size="80" value="<?=DOMAIN_NAME?>/rssfeed.php?website=<?=$website?>">
    </strong></p>
  </center>

</body>

</html>

