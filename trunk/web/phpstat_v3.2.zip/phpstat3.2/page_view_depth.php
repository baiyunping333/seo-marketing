<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/25
	describe:ҳ��������
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';

	if( $Types == "1" )
	{
		//�����߷���ʱ��
		$Sql = "SELECT count(id) as counts from " . $TableList[ip] . " where website = '$website' group by ip order by counts asc;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{				
				if($Tmp[counts] <= 1)
					$onLimeDepth[0]++;
				elseif($Tmp[counts] <= 2)
					$onLimeDepth[1]++;
				elseif($Tmp[counts] <= 3)
					$onLimeDepth[2]++;
				elseif($Tmp[counts] <= 4)
					$onLimeDepth[3]++;
				elseif($Tmp[counts] <= 5)
					$onLimeDepth[4]++;
				elseif($Tmp[counts] <= 6)
					$onLimeDepth[5]++;
				elseif($Tmp[counts] <= 7)
					$onLimeDepth[6]++;
				elseif($Tmp[counts] <= 8)
					$onLimeDepth[7]++;
				elseif($Tmp[counts] <= 9)
					$onLimeDepth[8]++;
				elseif($Tmp[counts] <= 10)
					$onLimeDepth[9]++;
				elseif($Tmp[counts] <= 11)
					$onLimeDepth[10]++;
				elseif($Tmp[counts] <= 12)
					$onLimeDepth[11]++;
				elseif($Tmp[counts] <= 13)
					$onLimeDepth[12]++;
				elseif($Tmp[counts] <= 14)
					$onLimeDepth[13]++;
				elseif($Tmp[counts] <= 15)
					$onLimeDepth[14]++;
				elseif($Tmp[counts] <= 16)
					$onLimeDepth[15]++;
				elseif($Tmp[counts] <= 17)
					$onLimeDepth[16]++;
				elseif($Tmp[counts] <= 18)
					$onLimeDepth[17]++;
				elseif($Tmp[counts] <= 19)
					$onLimeDepth[18]++;
				elseif($Tmp[counts] <= 20)
					$onLimeDepth[19]++;
				else
					$onLimeDepth[20]++;			
			
		}
		for($i=0;$i<=20;$i++)
		{	
			if($i == 20)
			{
				$DTmp[$i] = "21+ҳ,".($onLimeDepth[$i] == ""?0:$onLimeDepth[$i]);
			}
			else
			{
				$DTmp[$i] = ($i+1)."ҳ,".($onLimeDepth[$i] == ""?0:$onLimeDepth[$i]);
			}						
		}
		
		
	}
	
	if( $Types == "0" or  $Types == "2" )
	{
		$Res = $Conn->Execute( " select sum(counts) as counts ,returner from $TableList[returner] where types = 6 and website = '$website' group by returner ORDER BY `returner` ASC ");

		while( $Tmp = @$Res->FetchRow() )
		{
			preg_match( "|(http://[^/]+?)/.*|isU", $Tmp[lastpage], $LastSite );
			$Tmp[lastsite] = trim( $LastSite[1] );
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Datas[] = $Tmp;
				if($Tmp[returner] <= 1)
					$onLimeDepth[0] = $Tmp[counts];
				elseif($Tmp[returner] <= 2)
					$onLimeDepth[1] = $Tmp[counts];
				elseif($Tmp[returner] <= 3)
					$onLimeDepth[2] = $Tmp[counts];
				elseif($Tmp[returner] <= 4)
					$onLimeDepth[3] = $Tmp[counts];
				elseif($Tmp[returner] <= 5)
					$onLimeDepth[4] = $Tmp[counts];
				elseif($Tmp[returner] <= 6)
					$onLimeDepth[5] = $Tmp[counts];
				elseif($Tmp[returner] <= 7)
					$onLimeDepth[6] = $Tmp[counts];
				elseif($Tmp[returner] <= 8)
					$onLimeDepth[7] = $Tmp[counts];
				elseif($Tmp[returner] <= 9)
					$onLimeDepth[8] = $Tmp[counts];
				elseif($Tmp[returner] <= 10)
					$onLimeDepth[9] = $Tmp[counts];
				elseif($Tmp[returner] <= 11)
					$onLimeDepth[10] = $Tmp[counts];
				elseif($Tmp[returner] <= 12)
					$onLimeDepth[11] = $Tmp[counts];
				elseif($Tmp[returner] <= 13)
					$onLimeDepth[12] = $Tmp[counts];
				elseif($Tmp[returner] <= 14)
					$onLimeDepth[13] = $Tmp[counts];
				elseif($Tmp[returner] <= 15)
					$onLimeDepth[14] = $Tmp[counts];
				elseif($Tmp[returner] <= 16)
					$onLimeDepth[15] = $Tmp[counts];
				elseif($Tmp[returner] <= 17)
					$onLimeDepth[16] = $Tmp[counts];
				elseif($Tmp[returner] <= 18)
					$onLimeDepth[17] = $Tmp[counts];
				elseif($Tmp[returner] <= 19)
					$onLimeDepth[18] = $Tmp[counts];
				elseif($Tmp[returner] <= 20)
					$onLimeDepth[19] = $Tmp[counts];
				else
					$onLimeDepth[20] = $Tmp[counts];
		for($i=0;$i<=20;$i++)
		{	
			if($i == 20)
			{
				$DTmp[$i] = "21+ҳ,".($onLimeDepth[$i] == ""?0:$onLimeDepth[$i]);
			}
			else
			{
				$DTmp[$i] = ($i+1)."ҳ,".($onLimeDepth[$i] == ""?0:$onLimeDepth[$i]);
			}						
		}
			$SqlDatas[] = array('returner'=>($Tmp[returner]+1),'ipcounts'=>$Tmp[counts]);
		}
	}
	$Tpl->assign( 'Datas', $Datas );
	
	//ͳ��ͼ
	//@sort( $DTmp );
	$Datas = @implode( ';', $DTmp);
	$Tpl->assign( 'WIDTH_NUM1', WIDTH_NUM3 );
	$Tpl->assign( 'WIDTH_NUM2', WIDTH_NUM4 );
	$Tpl->assign( 'Data', $Datas );	
	
	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('�������','�˴�')) ));
	$Tpl->assign( 'fname', 'returner' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'Main', $Tpl->fetch( 'page_view_depth.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '������� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '�������' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>