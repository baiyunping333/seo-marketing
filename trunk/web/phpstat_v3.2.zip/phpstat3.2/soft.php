<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	include_once './include.inc/function_system.php';
	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';

	if( $Types == "1" ) 
	{
		$Res = $Conn->Execute( " select count(id) as counts ,browser from $TableList[ip_limit] where website = '$website' group by browser ORDER BY counts desc ");
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[browser2] = urlencode($Tmp[browser]);
			$Browser[] = $Tmp;	
		}
		unset($Res);unset($Tmp);
		$Res = $Conn->Execute( " select count(id) as counts ,system from $TableList[ip_limit] where website = '$website' group by system ORDER BY counts desc ");
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[system2] = urlencode($Tmp[system]);
			$Tmp[system] = GetSystem( $Tmp[system] );
			$System[] = $Tmp;
		}
	}

	if( $Types == "2" or $Types == "0" ) 
	{	
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where .= " and times >= $StartTime and times < $EndTime ";
		}
		//��ȡ�����ͳ��
		$Res = $Conn->Execute( " select sum(counts) as counts,browser from $TableList[browser] where types = 3 and website = '$website' $Where GROUP BY browser ORDER BY `counts` DESC " );
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[browser2] = urlencode($Tmp[browser]);
			$Browser[] = $Tmp;		
		}	

		//��ȡ����ϵͳͳ��
		
		$Res = $Conn->Execute( " select sum(counts) as counts,system from $TableList[system] where types = 3 and website = '$website' $Where GROUP BY system ORDER BY `counts` DESC " );
		while( $Tmp = @$Res->FetchRow() )
		{
			$Tmp[system2] = urlencode($Tmp[system]);
			$Tmp[system] = GetSystem( $Tmp[system] );
			$System[] = $Tmp;
		}
	}


	if( count( $Browser ) > 0 )
	{
		foreach( $Browser as $Key=>$Val )
		{
			$BrowserCountAll += $Val[counts];
		}
		foreach( $Browser as $Key=>$Val )
		{
			$Browser[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$BrowserCountAll ) * 100 );
			$SqlDatas[] = array('browser'=>$Browser[$Key][browser],'ipcounts'=>$Val[counts],'precent'=>$Browser[$Key][percent]);
		}
	}
	$Tpl->assign( 'Browser', $Browser );

	if( count( $System ) > 0 )
	{
		foreach( $System as $Key=>$Val )
		{
			$SystemCountAll += $Val[counts];
		}
		foreach( $System as $Key=>$Val )
		{
			$System[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$SystemCountAll ) * 100 );
			$SqlDatas[] = array('browser'=>$System[$Key][system],'ipcounts'=>$Val[counts],'precent'=>$System[$Key][percent]);
		}
	}
	$Tpl->assign( 'System', $System );
	
	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('����ͳ��','���ʴ���(IP)','�ٷֱ�')) ));	
	$Tpl->assign( 'fname', 'country' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	$Tpl->assign( 'Main', $Tpl->fetch( 'soft.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '����ͳ�� - '.$SoftWareName .$SoftWareVersion);
	$Tpl->assign( 'NowView', '����ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>