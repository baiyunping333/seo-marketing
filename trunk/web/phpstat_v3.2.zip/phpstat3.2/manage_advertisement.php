<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';	
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	initialize( $_GET, array( 'action'=>'strval','type'=>'intval', 'page'=>'intval', 'website'=>'strval','value'=>'intval','advid'=>'intval') );
	initialize( $_POST, array( 'action'=>'strval', 'advurl'=>'strval', 'advname'=>'strval', 'advcode'=>'strval', 'advlink'=>'strval' ) );
	$website = $_GET[website];
	include_once 'initmenu.php';
	$Tpl->assign( 'action', 'insert' );
	if( $_POST[action] == "insert" )
	{	
		$_POST[advname] = addslashes( trim($_POST[advname]) );
		$_POST[advurl] = addslashes( trim($_POST[advurl]) );
		$_POST[advcode] = addslashes( trim($_POST[advcode]) );
		$_POST[advlink] = addslashes( trim($_POST[advlink]) );
		$date = mktime(date("H"),date("i"),date("s"),date("m"),date("d"),date("Y"));
		$Res = $Conn->Execute( " insert into $TableList[adv](adv,urls,code,website,times,link) values('$_POST[advname]','$_POST[advurl]','$_POST[advcode]','$website','$date','$_POST[advlink]')" );	
	}
	
	if($_GET[action] == "changeflag" and is_int($_GET[advid]))
	{	
		$Conn->Execute( " update $TableList[adv] set flag = '$_GET[value]' where advid = '$_GET[advid]' and website = '$website'" );	
	}
	
	if($_POST[action] == "updateadv" and is_int($_GET[advid]))
	{	
		$_POST[advname] = addslashes( trim($_POST[advname]) );
		$_POST[advurl] = addslashes( trim($_POST[advurl]) );
		$_POST[advcode] = addslashes( trim($_POST[advcode]) );
		$_POST[advlink] = addslashes( trim($_POST[advlink]) );
		$Res = $Conn->Execute( " update $TableList[adv] set adv = '$_POST[advname]', urls = '$_POST[advurl]',code = '$_POST[advcode]',link = '$_POST[advlink]' where advid = '$_GET[advid]' and website = '$website'" );		
	}

	if($_GET[action] == "modadv" and is_int($_GET[advid]))
	{	
		$Res = $Conn->Execute( " select * from $TableList[adv] where advid = '$_GET[advid]' and website = '$website'" );
		$Tmp = $Res->FetchRow();
		$Tpl->assign( 'advname', $Tmp[adv] );
		$Tpl->assign( 'advurl', $Tmp[urls] );
		$Tpl->assign( 'advcode', $Tmp[code] );
		$Tpl->assign( 'advlink', $Tmp[link] );
		if($Tmp[link] == "?")
			$Tpl->assign( 'link2', "selected");
		else
			$Tpl->assign( 'link1', "selected");
		$Tpl->assign( 'action', 'updateadv' );

		$Res = $Conn->Execute( " select * from $TableList[adv] where advid = '$_GET[advid]' and website = '$website'" );
		$Tmp = $Res->FetchRow();
		$Tpl->assign( 'code', $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code] );
	}

	

	if($_GET[action] == "deladv" and is_int($_GET[advid]))
	{	
		$Res = $Conn->Execute( " delete from $TableList[adv] where advid = '$_GET[advid]' and website = '$website'" );		
	}
	


	//��¼����
	$Res = $Conn->Execute( " select count(*) as count  from $TableList[adv] where website = '$website'" );
	$Count = $Res->FetchRow();
	$DataCount = $Count[count];

	$PageSize = 20;
	if( $DataCount > 0 )
	{
		include_once ( './include.inc/page.inc.php' );
		$PageItems = MakePageItems ( $DataCount, $PageSize );
		$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
		$Tpl->assign( 'PageLinks', $PageLinks );
	}
	if($PageItems[Offset] == "")$PageItems[Offset] = 0;
	$Res = $Conn->Execute( " select *  from $TableList[adv] where  website = '$website' ORDER BY `advid` DESC ",$PageSize , $PageItems[Offset]  );

	while( $Tmp = @$Res->FetchRow() )
	{	
		$Tmp[times] = date( "Y-m-d H:i" ,$Tmp[times]); 
		$Tmp[flagvalue] = $Tmp[flag];
		if( $Tmp[flag] == 1)
			$Tmp[flag] = "ͳ����";
		else
			$Tmp[flag] = "<FONT  COLOR=red>��ͣ</FONT>";
		$Tmp[urls1] = "?phpstatfrom=".$Tmp[code];
		$Tmp[urls2] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
		$Datas[] = $Tmp;
	}
	$Tpl->assign( 'Datas', $Datas );

	
	$Tpl->assign( 'website', $website );



	$Tpl->assign( 'Main', $Tpl->fetch( 'manage_advertisement.html' ) . $scriptCode );
	
	$Tpl->assign( 'Title', '���ͳ�ƹ��� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '���ͳ�ƹ���' );
	$Tpl->assign( 'QuickLink', "<a href=\"advertisement.php?website=$website&type=1\">����ͳ��</a> <a href=\"advertisement.php?website=$website&type=2\">����ͳ��</a> <a href=\"advertisement.php?website=$website&type=0\">����ͳ��</a>  | <a href=\"manage_advertisement.php?website=$website\">������</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>