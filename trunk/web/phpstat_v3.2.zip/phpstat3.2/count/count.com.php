<?
	//chdir( '../' );	
	include_once '../include.inc/config.inc.php';
	include_once '../include.inc/conn.db.inc.php';
	include_once '../include.inc/global.inc.php';
	include_once '../include.inc/stat.class.php';
	include_once '../include.inc/function.php';

	//��ʼ��$_GET����
	Initialize( $_GET, array( 'website'=>'strval','image'=>'strval','referer'=>'strval','language'=>'strval','charset'=>'strval','pageurl'=>'strval' ) );
	$counturl = "http://work.phpstat.net/cms/phpstat10";
	$website = $_GET[website];
	$image = $_GET[image];
	//ȷ��ͼƬ
	if(!$image)
	$imagesrc = "../templates/".TPL_NAME."/".TPL_IMGDIR."/icos/countlogo1.gif";
	else
	$imagesrc = "../templates/".TPL_NAME."/".TPL_IMGDIR."/icos/".$image;
	//����ͼƬ
	header("Content-type: image/gif");
	readfile($imagesrc);
	@flush();
	//��ȡ��Ϣ����
	$_GET[counturl] = $counturl;
	//$_GET[pageurl] = "http://".$_SERVER[HTTP_HOST].$_SERVER['SCRIPT_NAME'];	
	if($_SERVER[HTTP_REFERER])
	$_GET[referer] = $_SERVER[HTTP_REFERER];
	$_GET[language] = $_SERVER[HTTP_ACCEPT_LANGUAGE];
	$_GET[charset] = $_SERVER[HTTP_ACCEPT_CHARSET];
	$_GET[firsttime] = date("Y-m-d-H-i-s");
	$_GET[lasttime] = date("Y-m-d-H-i-s");
	$Stat = new _Stat( );

?>