<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10
	describe:��ͷ��ͳ��
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval','Date_Day'=>'intval','Date_Month'=>'intval','Date_Year'=>'intval') );
	$website = $_GET[website];
	include_once 'initmenu.php';
	
	
	if($_GET[Date_Year])
	{
		$Year  = $_GET[Date_Year]  == 0?date( 'Y' ):$_GET[Date_Year];
		$Month = $_GET[Date_Month] == 0?date( 'm' ):$_GET[Date_Month];
		$Day   = $_GET[Date_Day]   == 0?date( 'd' ):$_GET[Date_Day];
		$StartTime = mktime (0,0,0,$Month,$Day,$Year );
		$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );
		$Where = " and times >= $StartTime and times < $EndTime ";
	}
	
	if( $Types == "1" ) 
	{
		//��¼����
		$Res = $Conn->Execute( " select id from $TableList[ip_limit] where website = '$website' and returner != 0 group by returner" );
		$DataCount = $Res->RecordCount();
	
		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select count(id) as counts ,returner from $TableList[ip_limit] where website = '$website' and returner != 0 group by returner ORDER BY counts desc ",$PageSize,$PageItems[Offset] );
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$CountAll += $Tmp[counts];
			$Datas[] = $Tmp;
			$DTmp[] = $Tmp['returner'].'��,'.$Tmp[counts];
			$SqlDatas[] = array('returner'=>$Tmp[returner],'ipcounts'=>$Tmp[counts]);
		}
	}

	if( $Types == "2" or  $Types == "0" ) 
	{	
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where = " and times >= $StartTime and times < $EndTime ";
		}
		//��¼����		
		$Res = $Conn->Execute( " select count(*) as count from $TableList[returner] where types = 3 and website = '$website' $Where group by returner" );
		$Count = $Res->RecordCount();
		$DataCount = $Count;

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select sum(counts) as counts ,returner from $TableList[returner] where types = 3 and website = '$website' $Where group by returner ORDER BY `returner` desc ",$PageSize,$PageItems[Offset] );
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$CountAll += $Tmp[counts];
			$Datas[] = $Tmp;
			$DTmp[] = $Tmp['returner'].'��,'.$Tmp[counts];
			$SqlDatas[] = array('returner'=>$Tmp[returner],'ipcounts'=>$Tmp[counts]);
		}
	}
	if( count($Datas) > 0 )
	foreach( $Datas as $key => $Val )
	{
		$Datas[$key][percent] = sprintf("%01.2f", ( $Datas[$key][counts]/$CountAll ) * 100 );	
	}

	$Tpl->assign( 'Datas', $Datas );
	
	//ͳ��ͼ
	//@sort( $DTmp );
	$Datas = @implode( ';', $DTmp);
	$Tpl->assign( 'WIDTH_NUM1', WIDTH_NUM3 );
	$Tpl->assign( 'WIDTH_NUM2', WIDTH_NUM4 );
	$Tpl->assign( 'Data', $Datas );

	$Tpl->assign( 'Year', $Year == ""?date("Y"):$Year);
	$Tpl->assign( 'Month', $Month == ""?date("m"):$Month );
	$Tpl->assign( 'Day', $Day == ""?date("d"):$Day );		
	$Tpl->assign( 'DataTime', $StartTime );

	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('�������ҳ϶�','�˴�')) ));
	$Tpl->assign( 'fname', 'returner' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'Main', $Tpl->fetch( 'viewer_fealty.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '�������ҳ϶� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '�������ҳ϶�' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>