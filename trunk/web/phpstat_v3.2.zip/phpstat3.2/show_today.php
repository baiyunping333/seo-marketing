<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/09	
*/
/*
	2006-10-09 �����ӵ��ļ����޸��ˡ������������Ĳ鿴��ʽ
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'page'=>'intval' ,'types'=>'intval','website'=>'strval') );

	include_once 'initmenu.php';
	$Year  = $_GET[Date_Year]  == 0?date( 'Y' ):$_GET[Date_Year];
	$Month = $_GET[Date_Month] == 0?date( 'm' ):$_GET[Date_Month];
	$Day   = $_GET[Date_Day]   == 0?date( 'd' ):$_GET[Date_Day];

	$StartTime = mktime (0,0,0,$Month,$Day,$Year );
	$EndTime = mktime (0,0,0,$Month,$Day,$Year ) + 86400;

	$Title = "���շ�����ϸ";	

	//ͳ��ͼip,pv
	$Res = $Conn->Execute( " select * from $TableList[day_data] where times = $StartTime and  website = '$website'" );
	$Row = $Res->FetchRow();
	for( $i = 0; $i < 24; $i++ )
	{
		$CountIp = $Row["hourip$i"] + rand(NUM1,NUM2);
		$Count = $Row["hour$i"] + rand(NUM1,NUM2);
		if( strlen( $i ) == 1 ) $j = '0'.$i;
		else $j = $i;
		$Tmp[] = $j.','.$CountIp.','.$Count;
	}
	$Datas = implode( ';', $Tmp);
	$Tpl->assign( 'Data_Tu', $Datas );
	unset($Datas);

	//��¼����
	$Res = $Conn->Execute( " select count(*) as count  from $TableList[ip_limit] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' and todayfirst = '1'" );
	$Count = $Res->FetchRow();
	$DataCount = $Count[count];

	$PageSize = 20;
	if( $DataCount > 0 )
	{
		include_once ( './include.inc/page.inc.php' );
		$PageItems = MakePageItems ( $DataCount, $PageSize );
		$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
		$Tpl->assign( 'PageLinks', $PageLinks );
	}
	if($PageItems[Offset] == "")$PageItems[Offset] = 0;
	$Res = $Conn->SelectLimit( " select *  from $TableList[ip_limit] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' and todayfirst = '1' ORDER BY `time` DESC ", $PageSize ,$PageItems[Offset] );

	include_once './include.inc/function_timezone.php';
	include_once './include.inc/function_language.php';
	include_once './include.inc/function_system.php';

	while( $Tmp = $Res->FetchRow() )
	{
		$Tmp[language] = GetLanguage( $Tmp[language] );
		$Tmp[timezone] = GetTimeZone( $Tmp[timezone] );
		$Tmp[system]   = GetSystem( $Tmp[system] );
		preg_match( "|http://[^/]+?(/.*)|is", $Tmp[pageurl], $Tmp1 );
		$Tmp[pagesite] = trim( $Tmp1[1] );        
		
		$Tmp[firsttime] = @date("Y-m-d H:i:s",$Tmp[firsttime]);
		$Tmp[lasttime] = date("Y-m-d H:i:s",$Tmp[lasttime]);
		$Tmp[time] = date("Y-m-d H:i:s",$Tmp[time]);

		$ResNum = $Conn->Execute( " select count(*) as count  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' and ip = '$Tmp[ip]'" );
		$CountNum = $ResNum->FetchRow();
		$DataCountNum = $CountNum[count];
		$Tmp[countnum] = $DataCountNum;
		$Datas[] = $Tmp;
		$SqlDatas[] = array('datetimes'=>$Tmp[time],'ip'=>$Tmp[ip],'address'=>$Tmp[country].$Tmp[province].$Tmp[city].$Tmp[address],'pvcounts'=>$DataCountNum);
	}
		
	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'Day', $Day );	
	$Tpl->assign( 'DataTime', $StartTime );
	$Tpl->assign( 'Datas', $Datas );

###############################################
	$Res = $Conn->Execute( " select time,ip from $TableList[ip_limit] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' and returner != '0' order by time asc", $PageSize ,$PageItems[Offset] );
	unset($Tmp);unset($DTmp);unset($Datas);
	while( $Tmp = $Res->FetchRow() )
	{
		$ResReturn = $Conn->Execute( " select count(id) as counts from $TableList[ip] where `time` < $EndTime and `time` >= $StartTime and website = '$website' and ip = '$Tmp[ip]'");
		$TmpPv = $ResReturn->FetchRow();
		$MTmp[time] = $Tmp[time];
		$MTmp[counts] = $TmpPv[counts];
		$DTmp[] = $MTmp;
	}
	if( count($DTmp) > 0)
	foreach( $DTmp as $value )
	{ 
		for( $i = 0; $i < 24; $i++ )
		{
			if( $value[time] >= mktime($i,0,0,date("m",$StartTime),date("d",$StartTime),date("Y",$StartTime)) and $value[time] < mktime($i+1,0,0,date("m",$StartTime),date("d",$StartTime),date("Y",$StartTime)))
			{
				$DatasIp[$i]++;
				$DatasPv[$i] += $value[counts];
				break;
			}			
		}
	}
	
	unset($ReDatas);
	//print_r($Datas);
	for( $i = 0; $i < 24; $i++ )
	{	
		if( strlen($i) == 1) $j = "0".$i;
		else				 $j = $i;
		$ReDatas[] = $j.",".$DatasIp[$i].",".$DatasPv[$i]."";					
	}
	$Tpl->assign( 'Data_Tu2', implode( ';', $ReDatas) );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('ʱ��','IP��ַ','����','�������(IP)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode("select time as datetimes,ip as ip,CONCAT(country,province,city,address) as address,count(ip) as pvcounts from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' group by ip ORDER BY `time` DESC") );
	$Tpl->assign( 'fname', 'show_today' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	$Tpl->assign( 'Main', $Tpl->fetch( 'show_today.html' ) );

	$Tpl->assign( 'Title', $Title. '- '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'QuickLink', "   <a href=show_today_info.php?website=$website>��ϸģʽ���</a>" );
	if($_GET[types] == 2)
	{
		$Tpl->assign( 'QuickLink', "   <a href=show_today_info.php?website=$website>��ϸģʽ���</a>" );
		$Tpl->assign( 'Type', "&type=2" );
	}
	$Tpl->assign( 'NowView', $Title );	
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>