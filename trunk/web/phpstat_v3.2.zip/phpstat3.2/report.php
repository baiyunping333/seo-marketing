<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	include_once './include.inc/function_timezone.php';
	include_once './include.inc/function_language.php';
	global $website;
	Initialize( $_GET, array( 'page'=>'intval' ) );

	$Year = date( 'Y' );
	$Month = date( 'm' );
	$Day = date( 'd' );
	$hour = date( 'H' );
	$minute = date( 'i' );
	if($minute <= 10) $minute = '00';
	else $minute = $minute - 10;
	$StartTime = mktime ($hour,$minute,0,$Month,$Day,$Year );
	$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );
	//echo $sitecode;
	//��¼����

	$Res = $Conn->Execute( " select time,ip,country,address,pageurl,pagefromsite from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' group by ip ORDER BY `time`" );



	while( $Tmp = $Res->FetchRow() )
	{	
		preg_match( "|http://[^/]+?(/.*)|is", $Tmp[pageurl], $Tmp1 );
		$Tmp[pagesite] = trim( $Tmp1[1] );
		$Tmp[time] = date("Y-m-d H:i:s",$Tmp[time]);
		$Datas[] = $Tmp;
	}

	$Tpl->assign( 'Datas', $Datas );
	
	//��ȡ����24Сʱͳ����Ϣ
	$DataTime = mktime (0,0,0,date("m"),date("d"),date("Y"));
	
	$Res = $Conn->Execute( " select * from $TableList[day_data] where times = $DataTime and  website = '$website'" );
	$Row = $Res->FetchRow();
	$MaxCount = 0;
	$CountIpAll = $CountAll = 0;
	for( $i = 0; $i < 24; $i++ )
	{	
		$CountIpAll += $Row["hourip$i"];
		$CountAll += $Row["hour$i"];
		$MaxCount = $Row["hour$i"] > $MaxCount ? $Row["hour$i"] : $MaxCount;
	}

	$CountIpAll = $CountIpAll > 0 ? $CountIpAll : 0;
	$CountAll = $CountAll > 0 ? $CountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$HourLineCount = intval( $MaxCount / 5 );
	
	for( $i = 0; $i < 24; $i++ )
	{
		$Row["hourippercent$i"] = $CountIpAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hourip$i"]/$CountIpAll ) * 100 );
		$Row["hourippillarheight$i"] = $Quotiety * $Row["hourip$i"];
		$Row["hourippillarheight$i"] = $Row["hourippillarheight$i"] < 1 ? 1 : $Row["hourippillarheight$i"];

		$Row["hourpercent$i"] = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hour$i"]/$CountAll ) * 100 );
		$Row["hourpillarheight$i"] = ( $Quotiety * $Row["hour$i"] ) - $Row["hourippillarheight$i"];
		$Row["hourpillarheight$i"] = $Row["hourpillarheight$i"] < 1 ? 1 : $Row["hourpillarheight$i"];
        
		$HourData[$i] = array(
								'hourippercent' =>$Row["hourippercent$i"], 
								'hourippillarheight' => $Row["hourippillarheight$i"],
								'hourpercent' => $Row["hourpercent$i"],
								'hourpillarheight' => $Row["hourpillarheight$i"],
								'hourip' => $Row["hourip$i"],
								'hour' => $Row["hour$i"],
								'time' => $i,
								);

		$DayHour[$i] = $i;
	}
	$DataTime = date("Y-m-d ",$DataTime);
	$Tpl->assign( 'DataTime', $DataTime );
	$Tpl->assign( 'DayHour', $DayHour );
	$Tpl->assign( 'HourData', $HourData );

	//������ȡ����24Сʱͳ����Ϣ


	//��ȡ���10��ͳ�Ʊ���ͳ����Ϣ
	if($Day >10) $Day = $Day - 9;
	$MonthTime = mktime (0,0,0,date("m"),$Day,date("Y"));
	$EndTime = mktime (0,0,0,$Month+1,$Day+9,$Year );
	$Res = $Conn->Execute( " select day_count, day_count_ip, times  from $TableList[day_data] where times <= $EndTime and times >= $MonthTime and website = '$website'" );
	$CountIpAll = $CountAll = 0;
	while( $Tmp = $Res->FetchRow() )
	{   
		$TmpDay = intval( date( 'd', $Tmp[times] ) );
		$StatIp[$TmpDay] = intval( $Tmp[day_count_ip] );
		$Stat[$TmpDay] = intval( $Tmp[day_count] );

		$CountIpAll += $StatIp[$TmpDay];
		$CountAll += $Stat[$TmpDay];
		$MaxCount = $Stat[$TmpDay] > $MaxCount ? $Stat[$TmpDay] : $MaxCount;
	}

	$CountIpAll = $CountIpAll > 0 ? $CountIpAll : 0;
	$CountAll = $CountAll > 0 ? $CountAll : 0;


	// 
	for( $i = $Day; $i <= $Day+9; $i++ )
	{

		$DayIpPercent = $CountIpAll == 0 ? 0 : sprintf("%01.2f", ( $StatIp[$i]/$CountIpAll ) * 100 );
		

		$DayPercent = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Stat[$i]/$CountAll ) * 100 );
		$DayPillarHeight = ( $Quotiety * $Stat[$i] ) - $DayIpPillarHeight;
		$DayPillarHeight = $DayPillarHeight < 1 ? 1 : $DayPillarHeight;

		$MonthDay = mktime (0,0,0,date("m"),$i,date("Y"));
		 $MonthDay = date("Y-m-d H:i:s",$MonthDay);
		$DayData[$i] = array(
									'DayIpPercent' => $DayIpPercent,
									'DayIpPillarHeight' => $DayIpPillarHeight,
									'DayPercent' => $DayPercent,
									'DayPillarHeight' => $DayPillarHeight,
									'DayIpCount' => intval( $StatIp[$i] ),
									'DayCount' => intval( $Stat[$i] ),
									'MonthDay' => $MonthDay,
								);
	}
	
	$Tpl->assign( 'DayData', $DayData );
	//������ȡ���10��ͳ�Ʊ���ͳ����Ϣ

	//������·ͳ�Ʊ���
	$Res = $Conn->Execute( " select *  from $TableList[referer] where types = 1 and website = '$website' ORDER BY `counts` DESC " );

	while( $Tmp = $Res->FetchRow() )
	{
		preg_match( "|(http://[^/]+?)/.*|isU", $Tmp[lastpage], $LastSite );
		$Tmp[lastsite] = trim( $LastSite[1] );
		$comefrom[] = $Tmp;
	}
	$Tpl->assign( 'comefrom', $comefrom );
	//����������·ͳ�Ʊ���


	//�������50������ͳ�Ʊ���
	$Year = date( 'Y' );
	$Month = date( 'm' );
	$Day = date( 'd' );
	$StartTime = mktime (0,0,0,$Month,$Day,$Year );
	$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );
	$Res = $Conn->Execute( " select time,pagefromsite  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' ORDER BY `time` DESC LIMIT 50" );

	while( $Tmp = $Res->FetchRow() )
	{	
		$Tmp[time] = date("Y-m-d H:i:s",$Tmp[time]);
		$zuijin[] = $Tmp;				
	}
	$Tpl->assign( 'Zuijin', $zuijin );
	//�����������50������ͳ�Ʊ���


	//�����ܷ�ҳ��ͳ�Ʊ���
	$Res = $Conn->Execute( " select *  from $TableList[page] where types = 1 and website = '$website' ORDER BY `counts` DESC " );
	while( $Tmp = $Res->FetchRow() )
	{
		preg_match( "|(http://[^/]+?)/.*|isU", $Tmp[lastpage], $LastSite );
		$Tmp[lastsite] = trim( $LastSite[1] );
		$Pages[] = $Tmp;
	}
	$Tpl->assign( 'Pages', $Pages );
	//�����ܷ�ҳ��ͳ�Ʊ���
	
	//��������������·ͳ�Ʊ���
	
	$Engines = array(
		'baidu.com',
		'google.com',
		'search.sohu.com',
		'search.sina.com.cn',
		'so.163.com',
		'websearch.yahoo.com',
		'search.lycos.com',
		'seek.3721.com',
		'search.qq.com',
		'search.tom.com',
		'sogou.com',
		'search.21cn.com',
		'search.aol.com'
		);
	$Where = ' and referer REGEXP "' . implode( '|', $Engines ) .'" ';

	$Res = $Conn->Execute( " select *  from $TableList[referer] where types = 1 $Where and website = '$website' ORDER BY `counts` DESC ");
	$CountIpAll = $CountAll = 0;
	while( $Tmp = $Res->FetchRow() )
	{
		$Searchs[] = $Tmp;
	}

	//ͳ�ưٷֱ�
	$Res = $Conn->Execute( " select sum(counts) as counts  from $TableList[referer] where types = 1 $Where and website = '$website'" );
	$Count = $Res->FetchRow();
	$CountAll = $Count[counts];
	if( count( $Searchs ) > 0 )
	{
		foreach( $Searchs as $Key=>$Val )
		{
			$Searchs[$Key][Percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );
			$Searchs[$Key][percent] = & $Searchs[$Key][Percent];
		}
	}

	$Tpl->assign( 'Searchs', $Searchs );
	//������������������·ͳ�Ʊ���

	//���������ؼ���ͳ�Ʊ��� 
	$Res = $Conn->Execute( " select *  from $TableList[keyword] where types = 1 and website = '$website' ORDER BY `counts` DESC " );

	while( $Tmp = @$Res->FetchRow() )
	{
		preg_match( "|(http://[^/]+?)/.*|isU", $Tmp[lastpage], $LastSite );
		$Tmp[lastsite] = trim( $LastSite[1] );
		$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
		$Keywords[] = $Tmp;
	}
	$Tpl->assign( 'Keywords', $Keywords );
	//�������������ؼ���ͳ�Ʊ��� 

	$Tpl->assign( 'Website', $website );
	_out($Tpl->fetch( 'report.html' ));

?>