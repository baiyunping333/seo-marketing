<?
session_start();
include_once '../../include.inc/config.inc.php';
include_once '../../include.inc/conn.db.inc.php';
include_once '../../include.inc/global.inc.php';	
$website = strval($_GET[website]);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE></TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<META content=TRUE name=MSSmartTagsPreventParsing>
<META http-equiv=MSThemeCompatible content=Yes>
<META http-equiv=html content=no-cache>
<link href="imagefiles/style.css" rel="stylesheet" type="text/css">
<STYLE type=text/css>
A {
	COLOR: #000000; TEXT-DECORATION: none
}
A:hover {
	COLOR: #4455aa; TEXT-DECORATION: underline
}
BODY {
	FONT-SIZE: 12px;  MARGIN: 0px; COLOR: #000000; FONT-FAMILY: Tahoma;  TEXT-ALIGN: center
}
FONT {
	LINE-HEIGHT: normal
}
TD {
	FONT-SIZE: 12px; LINE-HEIGHT: 15px; FONT-FAMILY: Tahoma
}
.en {
	FONT-SIZE: 11px; FONT-FAMILY: verdana
}
</STYLE>

<META content="MSHTML 6.00.2900.2604" name=GENERATOR></HEAD>
<BODY>
<SCRIPT>
function checkclick(msg){
if(confirm(msg)){
event.returnValue=true;
}else{
event.returnValue=false;
}
}
</SCRIPT>

<DIV class=menuskin id=popmenu onmouseover=clearhidemenu() style="Z-INDEX: 100" 
onmouseout=dynamichide(event)></DIV>
<TABLE height="100%" cellSpacing=0 cellPadding=0 width="100%" align=center>
  <TBODY>
  <TR>
    <TD class=tablebody12 vAlign=top align=middle width="100%">
      <TABLE style="WIDTH: 100%" cellSpacing=0 cellPadding=0>
        <TBODY>
          <TR> 
            <TD width="100%" height=30 valign="top" background="imagefiles/menubg.jpg" > 
              <B> <IMG id=aimgboard5 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <A href="../../main.php?website=<?=$website?>" 
            target=window_main><font color="#333333">ͳ�Ƹſ�</font></A></B> </TD>
          </TR>
          <TR> 
            <TD 
          width="100%" height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard0','subimgboard0','aimgboard0','bookopen.gif','bookclose.gif')" > 
              <IMG id=aimgboard0 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">ʵʱͳ��</font></A></B> </TD>
          </TR>
          <TR> 
            <TD id=submenuboard0 style="DISPLAY: yes"> <TABLE width="100%" align=center cellPadding=0 cellSpacing=0>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../show_today.php?website=<?=$website?>" 
                  target=window_main>������ϸ</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp; &nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12">&nbsp;<A 
                  href="../../show_today.php?website=<?=$website?>&types=2" 
                  target=window_main>��ʷ��ϸ</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../online.php?website=<?=$website?>&types=3" 
                  target=window_main>��ʮ��������</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- �ܷ�ҳ���� -->
          <TR> 
            <TD height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard4','subimgboard4','aimgboard4','bookopen.gif','bookclose.gif')" > 
              <IMG id=aimgboard4 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">�����߷���</font></A></B> </TD>
          </TR>
          <TR id=submenuboard4 style="DISPLAY: yes"> 
            <TD height=30><TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR onclick="showsubmenu('submenuboard41','subimgboard41','aimgboard41','bookopen.gif','bookclose.gif')"> 
                    <TD align=left vAlign=middle bgcolor="#CCCCCC" class=tablebody1>&nbsp; 
                      &nbsp;&nbsp;<img src="imagefiles/blue22.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
            style="cursor: hand;">��һ�����߸���</A></TD>
                  </TR>
                  <TR  id=submenuboard41 style="DISPLAY: none"> 
                    <TD class=tablebody1 vAlign=middle align=left><TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                        <TBODY>
                          <TR>
                            <TD class=tablebody2 vAlign=middle align=left>&nbsp; 
                              &nbsp;&nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../stat_alexa.php?website=<?=$website?>" 
                  target=window_main>Alexa������</A></TD>
                          </TR>
                          <TR> 
                            <TD class=tablebody2 vAlign=middle align=left>&nbsp;&nbsp; 
                              &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../viewer_daily.php?website=<?=$website?>" target=window_main>ÿ�շ�����</A></TD>
                          </TR>
                          <TR> 
                            <TD class=tablebody2 vAlign=middle align=left>&nbsp;&nbsp; 
                              &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../viewer_views.php?website=<?=$website?>" target=window_main>�������������</A></TD>
                          </TR>
                          <TR> 
                            <TD class=tablebody2 vAlign=middle align=left>&nbsp;&nbsp; 
                              &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../viewer_fealty.php?website=<?=$website?>" target=window_main>�������ҳ϶�</A></TD>
                          </TR>
                          <TR> 
                            <TD class=tablebody2 vAlign=middle align=left>&nbsp;&nbsp; 
                              &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../viewer_similar.php?website=<?=$website?>" target=window_main>�������½���</A></TD>
                          </TR>
                        </TBODY>
                      </TABLE></TD>
                  </TR>
                  <TR onclick="showsubmenu('submenuboard42','subimgboard42','aimgboard42','bookopen.gif','bookclose.gif')"> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp; &nbsp;&nbsp;<A 
            style="cursor: hand;"><strong></strong></A><A 
            style="cursor: hand;"><img src="imagefiles/blue22.gif" width="12" height="12" align="absmiddle"> 
                      ���з����߸���</A></TD>
                  </TR>
                  <TR  id=submenuboard42 style="DISPLAY: none"> 
                    <TD class=tablebody1 vAlign=middle align=left><table width="100%" border="0" cellpadding="0" cellspacing="0">
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2>&nbsp;&nbsp; 
                            &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../referer.php?website=<?=$website?>" 
                  target=window_main>������Դ</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2>&nbsp; 
                            &nbsp;&nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../domain.php?website=<?=$website?>" 
                  target=window_main>��Դվ��</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2> &nbsp;&nbsp; 
                            &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../country.php?website=<?=$website?>" 
                  target=window_main>����ͳ��</A></TD>
                        </TR>
                        <TR> 
                          <TD height="17" align=left vAlign=middle class=tablebody2> 
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../province.php?website=<?=$website?>" 
                  target=window_main>ʡ��ͳ��</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2>&nbsp;&nbsp;&nbsp;&nbsp; 
                            &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12">&nbsp;<A 
                  href="../../city.php?website=<?=$website?>" 
                  target=window_main>����ͳ��</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2> &nbsp;&nbsp; 
                            &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../area.php?website=<?=$website?>" 
                  target=window_main>����λ��</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2>&nbsp;&nbsp; 
                            &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../language.php?website=<?=$website?>"target=window_main>����</A></TD>
                        </TR>
                        <TR> 
                          <TD align=left vAlign=middle class=tablebody2>&nbsp;&nbsp; 
                            &nbsp;&nbsp;&nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../timezone.php?website=<?=$website?>" target=window_main>ʱ��</A></TD>
                        </TR>
                      </table></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <TR> 
            <TD 
          width="100%" height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard6','subimgboard6','aimgboard6','bookopen.gif','bookclose.gif')" > 
              <IMG id=aimgboard6 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">���ҳ�����</font></A></B> </TD>
          </TR>
          <TR> 
            <TD id=submenuboard6 style="DISPLAY: yes"> <TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../page.php?website=<?=$website?>" 
                  target=window_main>����ҳ��</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../pagetitle.php?website=<?=$website?>" 
                  target=window_main>���ű���</A></TD>
                  </TR>
                  <TR> 
                    <TD height="28" align=left vAlign=middle class=tablebody1> 
                      &nbsp;&nbsp; &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../entry_page.php?website=<?=$website?>&type=0" 
                  target=window_main>���ҳ��</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../exit_page.php?website=<?=$website?>&type=0" 
                  target=window_main>����ҳ��</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../page_dynamic.php?website=<?=$website?>" 
                  target=window_main>��̬����</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../page_view_depth.php?website=<?=$website?>" target=window_main>�������</A><A 
                  href="#"></A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../page_view_times.php?website=<?=$website?>" target=window_main>����ʱ��</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- �ܷ�ҳ�������� -->
          <!-- ������� -->
          <TR> 
            <TD 
          width="100%" height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard8','subimgboard8','aimgboard8','bookopen.gif','bookclose.gif')"> 
              <IMG id=aimgboard8 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">�����������</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD id=submenuboard8 style="DISPLAY: none"> <TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../keyword.php?website=<?=$website?>" 
                  target=window_main>�ؼ���</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../referer.php?website=<?=$website?>&engine=true" 
                  target=window_main>��������</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../bot.php?website=<?=$website?>" 
                  target=window_main>����֩��</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- ����������� -->
          <!-- ��ͷ�ʷ��� -->
          <TR> 
            <TD 
          width="100%" height=30 background="imagefiles/menubg.jpg"> <IMG id=aimgboard5 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
                  href="../../advertisement.php?website=<?=$website?>" 
                  target=window_main><FONT  COLOR="red">���ͳ�Ʒ���</font></A></B> </TD>
          </TR>
          <!-- ��ͷ�ʷ������� -->
          <!-- ͳ�Ʊ������� 
          <TR> 
            <TD height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard32','subimgboard32','aimgboard32','bookopen.gif','bookclose.gif')" > 
              <IMG id=aimgboard5 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A style="cursor: hand;"><font color="#333333">ͳ�Ʊ�������</font></A></B></TD>
          </TR>
          <TR> 
            <TD id=submenuboard32 style="DISPLAY: none"><TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../report.php?website=<?=$website?>" 
                  target=_blank>���ٱ���</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../myreport/index.htm" 
                  target=window_main>ÿ�ܱ���</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A        
                  href="../../alexa.php?website=<?=$website?>" 
                  target=window_main>Alexa����</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
		 ͳ�Ʊ����������� -->
          <!-- ʱ�η��� -->
          <TR> 
            <TD 
          width="100%" height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard10','subimgboard10','aimgboard10','bookopen.gif','bookclose.gif')"> 
              <IMG id=aimgboard10 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">��ʷ���ݷ���</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD id=submenuboard10 style="DISPLAY: none"> <TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../stat_day.php?website=<?=$website?>" 
                  target=window_main>ÿ��ͳ��</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../stat_month.php?website=<?=$website?>" 
                  target=window_main>ÿ��ͳ��</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../stat_year.php?website=<?=$website?>" 
                  target=window_main>ÿ�����</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- ʱ�η������� -->
          <!-- ����������� -->
          <TR> 
            <TD 
          width="100%" height=25 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard12','subimgboard12','aimgboard12','bookopen.gif','bookclose.gif')"> 
              <IMG id=aimgboard12 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">web�������</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD id=submenuboard12 style="DISPLAY: none"> <TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../language.php?website=<?=$website?>"target=window_main>ϵͳ����</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../soft.php?website=<?=$website?>" 
                  target=window_main>ƽ̨&������汾</A></TD>
                  </TR>
                  <TR>
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../screen.php?website=<?=$website?>" target=window_main>��Ļ�ֱ���&��ɫ</A></TD>
                  </TR>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../plug.php?website=<?=$website?>" target=window_main>������Java&Flash</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- ��������������� -->
          <!-- ͳ��վ�� -->
          <?
		  include_once '../../include.inc/config.inc.php';
		  include_once '../../include.inc/conn.db.inc.php';
		  if( $_SESSION[SESSION_USERGROUP] == "admin" or $_SESSION[SESSION_USERGROUP] == "superadmin" )
			{
			?>
          <TR>
            <TD height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard14','subimgboard14','aimgboard14','openfolder.gif','closedfolder.gif')"><IMG id=aimgboard14 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">ʵ�ù���</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD  id=submenuboard14 style="DISPLAY: none"><TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left>&nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../ip_search.php?website=<?=$website?>" 
                  target=window_main>IP��ַ��ѯ</A></TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
          <TR> 
            <TD height=30 background="imagefiles/menubg.jpg" 
          onclick="showsubmenu('submenuboard109','subimgboard109','aimgboard109','openfolder.gif','closedfolder.gif')"> 
              <IMG id=aimgboard109 alt=չ���˵� 
            src="imagefiles/bookclose.gif" align=absMiddle> <B><A 
            style="cursor: hand;"><font color="#333333">ͳ��վ���б�</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD id=submenuboard109 style="DISPLAY: none"><TABLE cellSpacing=0 cellPadding=0 width="100%" align=center>
                <TBODY>
                  <?
			
		if($_SESSION[SESSION_USERGROUP] == 'superadmin')
		{	
			$rs = $Conn->Execute( " select site,sitename,sitetype,website,all_count,all_count_ip from $TableList[site]");
		}
		else
		{	
			$ResSite = $Conn->Execute( " select websiteid from $TableList[user_site] where managerid = '$manager'");
			while($TmpSite = $ResSite->FetchRow())
			$WebsiteID[] = $TmpSite[websiteid];
			$Where = implode("|",$WebsiteID);
			$Res = $Conn->Execute( " select site,sitename,sitetype,website,all_count,all_count_ip from $TableList[site] where website REGEXP '".$Where."'");
			$manager = $_SESSION[SESSION_MANAGER];
			$rs = $Conn->Execute("select sitename,website,site from $TableList[site] where managerid = '$manager' order by id asc");
		}
			while($row = $rs->FetchRow())
				{
			?>
                  <TR> 
                    <TD class=tablebody1 vAlign=middle align=left> &nbsp;&nbsp; 
                      &nbsp;<img src="imagefiles/blue21.gif" width="12" height="12" align="absmiddle">&nbsp;<A 
                  href="../../index.php?website=<?=$row[website]?>" 
                  target=window_main> 
                      <?=$row[sitename]?>
                      </A></TD>
                  </TR>
                  <?
				}			
			?>
                </TBODY>
              </TABLE></TD>
          </TR>
          <!-- ͳ��վ����� -->
          <?
			}
			 ?>
          <TR> 
            <TD width="100%" height=30 background="imagefiles/menubg.jpg"> &nbsp;&nbsp;&nbsp;<IMG src="imagefiles/h1.gif"> 
              <B><A  onclick="checkclick('ȷʵҪ�˳�������?')" 
                  href="../../login.php?logout=true" 
                  target=window_main><font color="#333333">��ȫ�˳�</font></A></B> 
            </TD>
          </TR>
          <TR> 
            <TD></TD>
          </TR>
        </TBODY>
      </TABLE></TD></TR>
  <TR>
    <TD class=tablebody111 vAlign=bottom>
      <TABLE cellSpacing=0 cellPadding=0 width="96%" align=left border=0>
        <TBODY>
        <TR>
          <TD align=middle></TD></TR></TD></TR>
        <TR></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<SCRIPT language=javascript1.2>

function showsubmenu(ss,iis,ii)
{
var menuobjedt=document.getElementById(ss);
if (menuobjedt)
{
 if (menuobjedt.style.display=="none") 
  {menuobjedt.style.display="";
   document.getElementById(ii).src="imagefiles/bookopen.gif";
   document.getElementById(ii).alt="�رղ˵�";
   //document.getElementById(aa).src="imagefiles/"+openimg;
   //document.getElementById(aa).alt="�رղ˵�";
}
 else
  {menuobjedt.style.display="none"; 
	document.getElementById(ii).src="imagefiles/bookclose.gif";
	document.getElementById(ii).alt="չ���˵�";
	//document.getElementById(aa).src="imagefiles/"+closeimg;
	//document.getElementById(aa).alt="չ���˵�";
   }
}
}
function reloadpage(){
	parent.window_left.location.reload();
}
</SCRIPT>
</BODY></HTML>
