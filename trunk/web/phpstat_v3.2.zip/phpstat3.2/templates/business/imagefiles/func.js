function showsubmenu(id)
{
var menuobjedt=document.getElementById(id);
if (menuobjedt)
{
 if (menuobjedt.style.display=="none") 
  {menuobjedt.style.display="";
}
 else
  {menuobjedt.style.display="none"; 
   }
}
}

function showsubmenu2(sub,a)
{	
	var id = 1;
	var menuobjedt;
	//document.write(a);
	if(sub == '1')
	{
		for(id=1;id<200;id++)
		{	
			menuobjedt=document.getElementById(a+id);
			if (menuobjedt)
			{
				menuobjedt.style.display=""; 
			}
		}
	}
	if(sub == '0')
	{
		for(id=1;id<200;id++)
		{	
			menuobjedt=document.getElementById(a+id);
			if (menuobjedt)
			{
				menuobjedt.style.display="none"; 	 
			}
		}
	}
}

function showsubmenu3(a)
{	
	var id = 1;
	var menuobjedt;
	for(id=1;id<200;id++)
	{
		menuobjedt=document.getElementById(a+id);
		if (menuobjedt)
		{
		 if (menuobjedt.style.display=="none") 
		  {menuobjedt.style.display="";
		}
		 else
		  {menuobjedt.style.display="none"; 
		   }
		}
	}
}

var d=new Array();//ͳ����������
var d_ip_max=0;//���IP��
var d_pv_max=0;//���PV��
var d_ip_all=0;//IP����
var d_pv_all=0;//PV����
var title_all="";//ͳ��ͼ����
var title_ip="";//IP���ݱ���
var title_pv="";//PV���ݱ���
var b_w=0;//��״ͼ����
var b_s_w=0;//��״ͼ���
var b_id_s='';//��״ͼ���
var base_x;//��ʼ����X(���ڻ�����ͼ)
var base_y;//��ʼ����Y(���ڻ�����ͼ)
var mark='a';//��ʼ����Y(���ڻ�����ͼ)
function init_data(v)//��ʼ������
{
	d=new Array();
	d_ip_max=0;
	d_pv_max=0;
	d_ip_all=0;
	d_pv_all=0;
	var di=v.split(";");
	var di0,di1,di2;
	d[0]=di[0].split(",");
	title_all=d[0][0];
	title_ip=d[0][1];
	title_pv=d[0][2];
	b_w=Math.floor(d[0][3]);
	b_s_w=Math.floor(d[0][4]);
	mark=d[0][5];
	if(!mark)mark='a';
	b_id_s=d[0][6];
	for(var i=1;i<di.length;i++)
	{
		d[i]=di[i].split(",");
		di0=Math.floor(d[i][0]);
		di1=Math.floor(d[i][1]);
		di2=Math.floor(d[i][2]);
		d_ip_all+=di1;	
		d_pv_all+=di2;	
		d_ip_max=d_ip_max>di1?d_ip_max:di1;	
		d_pv_max=d_pv_max>di2?d_pv_max:di2;	
	}
}
function draw_bar(sa)//����״ͼ
{
	var sa_div=document.getElementsByName("sa")[sa];
	var v=sa_div.data;
	init_data(v);
	var b_d1="";
	var b_d2="";
	var title="";
	var b='<div align="center">'+title_all+' (��״ͼ) <a href="javascript:draw_line('+sa+')">->�л�������ͼ</a> | <a href="javascript:showsubmenu2(1,\''+mark+'\')">��ʾ����</a>  <a href="javascript:showsubmenu2(0,\''+mark+'\')">��������</a>  <a href="javascript:showsubmenu3(\''+mark+'\')">������ʾ</a></div><table border="0" cellpadding="0" cellspacing="0" align="center" class=picbackground><tr ><td valign="top" rowspan="2" class=pictdbackground><p align="right" style="line-height: 12px; margin-right: 2">';
	for(var i=1;i<d.length;i++)
	{	
		var b_id = "";
		var b_id_2 = "";
		title=''+title_pv+':'+d[i][2]+' '+Math.floor(d[i][2]/d_pv_all*1000)/10+'%\n'+title_ip+':'+d[i][1]+' '+Math.floor(d[i][1]/d_ip_all*1000)/10+'%';		
		b_id = mark+i;
		b_id_2 = mark+(i+100);
		b_d1+='<td align="center" valign="bottom" width="'+(b_w+b_s_w)+'"  title="'+title+'"  onMouseDown="showsubmenu(\''+b_id+'\');showsubmenu(\''+b_id_2+'\')"><div class="gra2" style="width:'+b_w+';border:0px;height:'+d[i][2]/d_pv_max*100+'"><div class="gra" style="width:'+b_w+';border:0px;height:'+((d[i][2]-d[i][1])/d_pv_max)*100+'"><span class="pillar-text3" id='+b_id+' style="DISPLAY: yes;">'+d[i][2]+'</span></div><span class="pillar-text2"   id='+b_id_2+' style="DISPLAY: yes;">'+d[i][1]+'</span></div></td>';
		b_d2+='<td width='+(b_w+b_s_w)+' title="'+title+'" id="x_'+sa+'_'+i+'"><u style="FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif;">'+d[i][0]+'</u></td>';
	}
	var d_per=d_pv_max%4==0?d_pv_max/4:(d_pv_max/4);
	for(var i=4;i>0;i--) b+=Math.floor(d_per*i)+'<br><br>';
	b+='0</p></td>';
	b+='<td width="10" valign="top" class=pictdbackground><img src="templates/business/imagefiles/tu_back_left.gif" width="10" ></td>';
	b+=b_d1;
	b+='<td width="10" valign="top" class=pictdbackground><img src="templates/business/imagefiles/tu_back_right.gif" width="10"></td></tr><tr height="20" align="center" style="letter-spacing:-2;font-family:Arial;font-size:12px"><td></td>';
	b+=b_d2;
	b+='<td></td></tr></table><div align="center"><span class="gra2" style="height:10px;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_ip+' '+d_ip_all+'&nbsp;&nbsp;<span class="gra" style="height:10;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_pv+' '+d_pv_all+'</div>';
	sa_div.innerHTML=b;
}

function draw_bar_single(sa)//����һ��״ͼ
{
	var sa_div=document.getElementsByName("sa")[sa];
	var v=sa_div.data;
	init_data(v);
	var b_d1="";
	var b_d2="";
	var title="";
	var b='<div align="center">'+title_all+' (��״ͼ) <a href="javascript:draw_line_single('+sa+')">->�л�������ͼ</a> | <a href="javascript:showsubmenu2(1,\''+mark+'\')">ȫ����ʾ</a>  <a href="javascript:showsubmenu2(0,\''+mark+'\')">ȫ������</a>  <a href="javascript:showsubmenu3(\''+mark+'\')">������ʾ</a></div><table border="0" cellpadding="0" cellspacing="0" align="center"><tr ><td valign="top" rowspan="2"><p align="right" style="line-height: 12px; margin-right: 2">';
	for(var i=1;i<d.length;i++)
	{	
		var b_id = "";
		//var b_id_2 = "";
		title=''+title_ip+':'+d[i][1]+' '+Math.floor(d[i][1]/d_ip_all*1000)/10+'%';		
		b_id = mark+i;
		//b_id_2 = Math.floor(Math.random()*4015.4)+i;
		b_d1+='<td align="center" valign="bottom" width="'+(b_w+b_s_w)+'"  class=picbackground title="'+title+'" ><div class="gra2" style="width:'+b_w+';border:0px;height:'+((d[i][1])/d_ip_max)*100+'" onMouseDown="showsubmenu(\''+b_id+'\')"><span class="pillar-text2"   id='+b_id+' style="DISPLAY: yes;">'+d[i][1]+'</span></div></td>';
		b_d2+='<td width='+(b_w+b_s_w)+' title="'+title+'" id="x_'+sa+'_'+i+'"><u style="FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif;">'+d[i][0]+'</u></td>';
	}
	var d_per=d_ip_max%4==0?d_ip_max/4:(d_ip_max/4);
	for(var i=4;i>0;i--) b+=Math.floor(d_per*i)+'<br><br>';
	b+='0</p></td>';
	b+='<td width="10" valign="top"><img src="templates/business/imagefiles/tu_back_left.gif" width="10" ></td>';
	b+=b_d1;
	b+='<td width="10" valign="top"><img src="templates/business/imagefiles/tu_back_right.gif" width="10"></td></tr><tr height="20" align="center" style="letter-spacing:-2;font-family:Arial;font-size:12px"><td></td>';
	b+=b_d2;
	b+='<td></td></tr></table><div align="center"><span class="gra2" style="height:10px;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_ip+' '+d_ip_all+'&nbsp;&nbsp;</div>';
	sa_div.innerHTML=b;
}



function draw_line(sa)//������ͼ
{
	var sa_div=document.getElementsByName("sa")[sa];
	var v=sa_div.data;
	init_data(v);	
	var l_d1="";
	var l_d2="";
	var title="";
	var l_x='';
	var l_y='';
	var e=document.getElementsByName("x_"+sa+"_1")[0];
	var t=e.offsetTop;
	var l=e.offsetLeft;
	while(e=e.offsetParent)
	{
		t+=e.offsetTop;
		l+=e.offsetLeft;
	}
	e=document.getElementsByName("x_"+sa+"_"+(d.length-1))[0];
	var t2=e.offsetTop;
	var l2=e.offsetLeft;
	while(e=e.offsetParent)
	{
		t2+=e.offsetTop;
		l2+=e.offsetLeft;
	}
	var w=(l2-l)/(d.length-2)*3/4;
	base_x=l*3/4-3/2*w;
	base_y=t*3/4;
	var l='<div align="center">'+title_all+' (����ͼ) <a href="javascript:draw_bar('+sa+')">->�л�����״ͼ</a> | <a href="javascript:showsubmenu2(1,\''+mark+'\')">��ʾ����</a>  <a href="javascript:showsubmenu2(0,\''+mark+'\')">��������</a>  <a href="javascript:showsubmenu3(\''+mark+'\')">������ʾ</a></div><table border="0" cellpadding="0" cellspacing="0" align="center"><tr><td valign="top" rowspan="2"><p align="right" style="line-height: 12px; margin-right: 2">';
	for(var i=1;i<d.length;i++)
	{	
		title=''+title_pv+':'+d[i][2]+' '+Math.floor(d[i][2]/d_pv_all*1000)/10+'%\n'+title_ip+':'+d[i][1]+' '+Math.floor(d[i][1]/d_ip_all*1000)/10+'%';
		l_id = mark+i;
		l_id_2 = mark+(i+100);
		l_d1+='<td align="center" valign="bottom" width="'+(b_w+b_s_w)+'" background="templates/business/imagefiles/tu_back.gif" title="'+title+'"></td>';
		l_d2+='<td width='+(b_w+b_s_w)+' title="'+title+'" valign="bottom" id="x_'+sa+'_'+i+'"><u style="FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif;">'+d[i][0]+'</u></td>';	
		from_x=base_x+i*w;
		to_x=base_x+(i+1)*w;
		if(i>1) 
		{
			from_y=base_y-d[i-1][2]/d_pv_max*75;
			to_y=base_y-d[i][2]/d_pv_max*75;
			l_x+='<v:line strokecolor="#c5c5c5" style="Z-INDEX:100;LEFT:0;TOP:0" from="'+from_x+'pt,'+from_y+'pt" to="'+to_x+'pt,'+to_y+'pt" strokecolor="black" strokeweight="2px"  onMouseDown="showsubmenu(\''+l_id+'\');showsubmenu(\''+l_id_2+'\')"><v:stroke StartArrow="oval" EndArrow="oval"  endarrowwidth="medium" startarrowwidth="medium" startarrowlength="medium"  endarrowlength="medium"/><span class="pillar-text3"  id='+l_id+' style="DISPLAY: yes;">'+d[i-1][2]+'</span></v:line>';
			from_y=base_y-d[i-1][1]/d_pv_max*75;
			to_y=base_y-d[i][1]/d_pv_max*75;
			l_x+='<v:line strokecolor="#4E6A99" style="Z-INDEX:100;LEFT:0;TOP:0" from="'+from_x+'pt,'+from_y+'pt" to="'+to_x+'pt,'+to_y+'pt" strokecolor="black" strokeweight="2px"   onMouseDown="showsubmenu(\''+l_id+'\');showsubmenu(\''+l_id_2+'\')"><v:stroke StartArrow="oval" EndArrow="oval" startarrowwidth="medium" startarrowlength="medium" endarrowwidth="medium" endarrowlength="medium"/><span class="pillar-text4" id='+l_id_2+' style="DISPLAY: yes;margin-bottom:4px">'+d[i-1][1]+'</span></v:line>';
		}
		l_y+='<v:line strokecolor="#dddddd" style="Z-INDEX:10;LEFT:0;TOP:0" from="'+(from_x+w)+'pt,'+base_y+'pt" to="'+(from_x+w)+'pt,'+(base_y-75)+'pt" strokecolor="black" strokeweight="1px"/>';
	}
	
	var d_per=d_pv_max%4==0?d_pv_max/4:(d_pv_max/4);
	for(var i=4;i>0;i--) l+=Math.floor(d_per*i)+'<br><br>';
	l+='0</p></td>';
	l+='<td width="10" valign="top"><img src="templates/business/imagefiles/tu_back_left.gif" width="10"></td>';
	l+=l_d1;
	l+='<td width="10" valign="bottom"><img src="templates/business/imagefiles/tu_back_right.gif" width="10"></td></tr><tr height="20" align="center" style="letter-spacing:-2;font-family:Arial;font-size:12px"><td></td>';
	l+=l_d2;
	l+='<td></td></tr></table><div align="center"><span style="font-size:1px;background-color:#78AFD5;height:10px;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_ip+' '+d_ip_all+'&nbsp;&nbsp;<span style="font-size:1px;background-color:#bbbbbb;height:10px;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_pv+' '+d_pv_all+'</div>';
	sa_div.innerHTML=l+l_x+l_y;
}

function draw_line_single(sa)//������ͼ
{
	var sa_div=document.getElementsByName("sa")[sa];
	var v=sa_div.data;
	init_data(v);	
	var l_d1="";
	var l_d2="";
	var title="";
	var l_x='';
	var l_y='';
	var e=document.getElementsByName("x_"+sa+"_1")[0];
	var t=e.offsetTop;
	var l=e.offsetLeft;
	while(e=e.offsetParent)
	{
		t+=e.offsetTop;
		l+=e.offsetLeft;
	}
	e=document.getElementsByName("x_"+sa+"_"+(d.length-1))[0];
	var t2=e.offsetTop;
	var l2=e.offsetLeft;
	while(e=e.offsetParent)
	{
		t2+=e.offsetTop;
		l2+=e.offsetLeft;
	}
	var w=(l2-l)/(d.length-2)*3/4;
	base_x=l*3/4-3/2*w;
	base_y=t*3/4;
	var l='<div align="center">'+title_all+' (����ͼ) <a href="javascript:draw_bar_single('+sa+')">->�л�����״ͼ</a> | <a href="javascript:showsubmenu2(1,\''+mark+'\')">��ʾ����</a>  <a href="javascript:showsubmenu2(0,\''+mark+'\')">��������</a>  <a href="javascript:showsubmenu3(\''+mark+'\')">������ʾ</a></div><table border="0" cellpadding="0" cellspacing="0" align="center"><tr><td valign="top" rowspan="2"><p align="right" style="line-height: 12px; margin-right: 2">';
	for(var i=1;i<d.length;i++)
	{	
		title=''+title_ip+':'+d[i][1]+' '+Math.floor(d[i][1]/d_ip_all*1000)/10+'%';
		//l_id = Math.floor(Math.random()*8105.1)+i;
		l_id_2 =  mark+i;
		l_d1+='<td align="center" valign="bottom" width="'+(b_w+b_s_w)+'" background="templates/business/imagefiles/tu_back.gif" title="'+title+'"></td>';
		l_d2+='<td width='+(b_w+b_s_w)+' title="'+title+'" valign="bottom" id="x_'+sa+'_'+i+'"><u style="FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif;">'+d[i][0]+'</u></td>';	
		from_x=base_x+i*w;
		to_x=base_x+(i+1)*w;
		if(i>1) 
		{			
			from_y=base_y-d[i-1][1]/d_ip_max*75;
			to_y=base_y-d[i][1]/d_ip_max*75;
			l_x+='<v:line strokecolor="#4E6A99" style="Z-INDEX:100;LEFT:0;TOP:0" from="'+from_x+'pt,'+from_y+'pt" to="'+to_x+'pt,'+to_y+'pt" strokecolor="black" strokeweight="1px" onMouseDown="showsubmenu(\''+l_id_2+'\')"><v:stroke StartArrow="oval" EndArrow="oval" startarrowwidth="medium" startarrowlength="medium" endarrowwidth="medium" endarrowlength="medium"  /><span class="pillar-text3"  id='+l_id_2+' style="DISPLAY: yes;">'+d[i-1][1]+'</span></v:line>';
		}
		l_y+='<v:line strokecolor="#eeeeee" style="Z-INDEX:10;LEFT:0;TOP:0" from="'+(from_x+w)+'pt,'+base_y+'pt" to="'+(from_x+w)+'pt,'+(base_y-75)+'pt" strokecolor="black" strokeweight="1px"/>';
	}
	
	var d_per=d_ip_max%4==0?d_ip_max/4:(d_ip_max/4);
	for(var i=4;i>0;i--) l+=Math.floor(d_per*i)+'<br><br>';
	l+='0</p></td>';
	l+='<td width="10" valign="top"><img src="templates/business/imagefiles/tu_back_left.gif" width="10"></td>';
	l+=l_d1;
	l+='<td width="10" valign="bottom"><img src="templates/business/imagefiles/tu_back_right.gif" width="10"></td></tr><tr height="20" align="center" style="letter-spacing:-2;font-family:Arial;font-size:12px"><td></td>';
	l+=l_d2;
	l+='<td></td></tr></table><div align="center"><span style="font-size:1px;background-color:#78AFD5;height:10px;width:'+b_w+';border:#000000 1px solid;"></span>&nbsp;'+title_ip+' '+d_ip_all+'&nbsp;&nbsp;</div>';
	sa_div.innerHTML=l+l_x+l_y;
}


/*
document.onmouseover=function(){getXY();}
function getXY()
{
	window.status=(event.clientX+","+event.clientY);
}
*/


