<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/25
	describe:�����߶���ʱ��
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';


	if( $Types == "1" )
	{
		//�����߷���ʱ��
		$Sql = "SELECT ip from " . $TableList[ip_limit] . " where website = '$website';";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "SELECT max(time) as maxtime,min(time) as mintime from " . $TableList[ip] . " where website = '$website' and ip = '$Tmp[ip]' limit 1;";
			$ResTime = @$Conn->Execute( $Sql );
			while($RowTime = $ResTime->FetchRow())
			{	
				if(($RowTime[maxtime] - $RowTime[mintime]) <= 10)
					$onLimeTime[0]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 30)
					$onLimeTime[1]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 60)
					$onLimeTime[2]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 180)
					$onLimeTime[3]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 600)
					$onLimeTime[4]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 1800)
					$onLimeTime[5]++;
				else
					$onLimeTime[6]++;

			}			
		}
			$DTmp[0] = '01--10��,'.($onLimeTime[0] == ""?0:$onLimeTime[0]);
			$DTmp[1] = '11--30��,'.($onLimeTime[1] == ""?0:$onLimeTime[1]);
			$DTmp[2] = '31--60��,'.($onLimeTime[2] == ""?0:$onLimeTime[2]);
			$DTmp[3] = '61--180��,'.($onLimeTime[3] == ""?0:$onLimeTime[3]);
			$DTmp[4] = '181--600��,'.($onLimeTime[4] == ""?0:$onLimeTime[4]);
			$DTmp[5] = '601--1800��,'.($onLimeTime[5] == ""?0:$onLimeTime[5]);
			$DTmp[6] = '1801+��,'.($onLimeTime[6] == ""?0:$onLimeTime[6]);			
		
	}
	
	if( $Types == "2" or $Types == "0" )
	{	
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where = " and times >= $StartTime and times < $EndTime ";
		}

		$Res = $Conn->Execute( " select sum(counts) as counts ,returner from $TableList[returner] where types = 5 and website = '$website' $Where group by returner ORDER BY `returner` ASC ",$PageSize,$PageItems[Offset] );
		
		while( $Tmp = @$Res->FetchRow() )
		{
			$Datas[] = $Tmp;
			
			if($Tmp['returner'] <= 10)
				$onLimeTime[0] = $Tmp[counts];
			elseif($Tmp['returner'] <= 30)
				$onLimeTime[1] = $Tmp[counts];
			elseif($Tmp['returner'] <= 60)
				$onLimeTime[2] = $Tmp[counts];
			elseif($Tmp['returner'] <= 180)
				$onLimeTime[3] = $Tmp[counts];
			elseif($Tmp['returner'] <= 600)
				$onLimeTime[4] = $Tmp[counts];
			elseif($Tmp['returner'] <= 1800)
				$onLimeTime[5] = $Tmp[counts];
			else
				$onLimeTime[6] = $Tmp[counts];


			$DTmp[0] = '01--10��,'.($onLimeTime[0] == ""?0:$onLimeTime[0]);
			$DTmp[1] = '11--30��,'.($onLimeTime[1] == ""?0:$onLimeTime[1]);
			$DTmp[2] = '31--60��,'.($onLimeTime[2] == ""?0:$onLimeTime[2]);
			$DTmp[3] = '61--180��,'.($onLimeTime[3] == ""?0:$onLimeTime[3]);
			$DTmp[4] = '181--600��,'.($onLimeTime[4] == ""?0:$onLimeTime[4]);
			$DTmp[5] = '601--1800��,'.($onLimeTime[5] == ""?0:$onLimeTime[5]);
			$DTmp[6] = '1801+��,'.($onLimeTime[6] == ""?0:$onLimeTime[6]);

			$SqlDatas[] = array('returner'=>$start."--".$Tmp[returner],'ipcounts'=>$Tmp[counts]);
		}
	}
	$Tpl->assign( 'Datas', $Datas );
	
	//ͳ��ͼ
	//@sort( $DTmp );
	$Datas = @implode( ';', $DTmp);
	$Tpl->assign( 'WIDTH_NUM1', WIDTH_NUM3+15 );
	$Tpl->assign( 'WIDTH_NUM2', WIDTH_NUM4+15);
	$Tpl->assign( 'Data', $Datas );	
	
	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('����ʱ��','�˴�')) ));
	$Tpl->assign( 'fname', 'returner' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'Main', $Tpl->fetch( 'page_view_times.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '����ʱ�� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '����ʱ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>