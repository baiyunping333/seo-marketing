CREATE TABLE `PREFIX_year_data` (
  `datayearid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `times` int(11) NOT NULL default '0',
  `year` int(11) NOT NULL default '0',
  `year_count` int(11) NOT NULL default '0',
  `year_count_ip` int(11) NOT NULL default '0',
  PRIMARY KEY  (`datayearid`),
  KEY `times` (`times`),
  KEY `year` (`year`),
  KEY `year_count` (`year_count`),
  KEY `year_phpstat_ip` (`year_count_ip`)
) TYPE=MyISAM AUTO_INCREMENT=22 ;