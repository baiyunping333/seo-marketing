<table cellspacing="2" cellpadding="1" width="670" align="center" border="0">
  <tbody>
    <tr>
      <td height="74"> <span class="heading">PHPStat Counter ��װ���ݿ�</span>
        <hr align="left" size="1" width="100%"/>
        <form id="form1" name="form1" method="get" action="install.php">
          <table width="100%" border="0" cellspacing="��" cellpadding="��">
            <tr>
              <td width="28%" rowspan="4"><table width="90%" height="200" border="0" cellpadding="5" cellspacing="3" style="border-right:2px solid #cccccc;">
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>1.���Ŀ¼����</td>
                </tr>
                <tr>
                  <td>2.����������</td>
                </tr>
                <tr>
                  <td><span class="heading">3.��װ���ݿ�</span></td>
                </tr>
                <tr>
                  <td>4.��װ���</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
              <td width="17%" height="25" align="right">�������ʺ�:</td>
              <td width="55%" height="25">
                <input name="username" type="text" id="username" />
              </td>
            </tr>
            <tr>
              <td height="25" align="right">�ʺ�����:</td>
              <td height="25"><input name="password" type="text" id="password" /></td>
            </tr>
            <tr>
              <td height="20" align="right">�ظ�����:</td>
              <td height="20"><input name="repassword" type="text" id="repassword" /></td>
            </tr>
            
            
            
            <tr>
              <td height="100">&nbsp;</td>
              <td><div align="center"> <br />
                <input name="step" type="hidden" id="step" value="4" />
				<input name="submit" type="hidden" id="submit" value="yes" />
                <input name="asd" type="submit" class="button" value="�ᡡ�����䡡��" />
              </div></td>
            </tr>
          </table>
        </form>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="18">&nbsp;</td>
    </tr>
  </tbody>
</table>
