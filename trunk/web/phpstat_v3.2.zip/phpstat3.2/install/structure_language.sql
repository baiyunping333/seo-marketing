CREATE TABLE `PREFIX_language` (
  `languageid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `language` varchar(32) NOT NULL default '0',
  `times` int(11) NOT NULL default '0',
  `lastpage` varchar(255) NOT NULL default '',
  `counts` int(11) NOT NULL default '0',
  `types` int(11) NOT NULL default '0',
  PRIMARY KEY  (`languageid`),
  KEY `keyword` (`language`,`times`,`counts`,`types`,`website`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;