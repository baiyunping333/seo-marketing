<table cellspacing="2" cellpadding="1" width="670" align="center" border="0">
  <tbody>
    <tr>
      <td height="74"> <span class="heading">PHPStat Counter ����������</span>
        <hr align="left" size="1" width="100%"/>
        <form id="form1" name="form1" method="get" action="install.php">
          <table width="100%" border="0" cellspacing="��" cellpadding="��">
            <tr>
              <td width="28%" rowspan="12"><table width="90%" height="200" border="0" cellpadding="5" cellspacing="3" style="border-right:2px solid #cccccc;">
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>1.���Ŀ¼����</td>
                </tr>
                <tr>
                  <td><span class="heading">2.����������</span></td>
                </tr>
                <tr>
                  <td>3.��װ���ݿ�</td>
                </tr>
                <tr>
                  <td>4.��װ���</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
              <td width="17%" height="25" align="right">���ݿ������:</td>
              <td width="55%" height="25"><label>
                <input name="host" type="text" id="host" value="localhost" />
              </label>
              ���磺localhost[:3306]��ѡ</td>
            </tr>
            <tr>
              <td height="25" align="right">���ݿ��û���:</td>
              <td height="25"><input name="user" type="text" id="user" value="root" />
              ���磺root</td>
            </tr>
            <tr>
              <td height="25" align="right">���ݿ�����:</td>
              <td height="25"><input name="password" type="text" id="password" />
���磺root</td>
            </tr>
            <tr>
              <td height="25" align="right">���ݿ���:</td>
              <td height="25"><input name="dbname" type="text" id="dbname" />
���磺phpstat</td>
            </tr>
            <tr>
              <td height="25" align="right">���ݿ��ַ���:</td>
              <td height="25"><select name="dbcharset" id="dbcharset">
                <option value="gbk">GBK[��������]</option>
                </select> 
              ���磺gbk</td>
            </tr>
            <tr>
              <td height="25" align="right">&nbsp;</td>
              <td height="25"><p class="STYLE1">��ʾ������׼ȷ��д���ݿ���ַ������룬����װ��ϵͳ��������롣<br />
                һ�㳣�õ���Mysql���ݿ������:gbk��utf8��big5��latin1<br />
              �������ʣ�����ѯ���Ŀռ�����ṩ�̡�</p></td>
            </tr>
            <tr>
              <td height="25" align="right">���ݱ���ǰ׺:</td>
              <td height="25"><input name="tablepre" type="text" id="tablepre" value="phpstat_" /></td>
            </tr>
            <tr>
              <td height="25" align="right">ģ����ʽ:</td>
              <td height="25"><label>
                <select name="tplname" id="tplname">
                  <option value="business">��Լ����</option>
                </select>
              </label></td>
            </tr>
            <tr>
              <td height="25" align="right">�Ƿ���ע��:</td>
              <td height="25"><label>
                <input name="isregister" type="radio" value="true" checked="checked" />
              
                ����
                <input type="radio" name="isregister" value="false" />
�ر�</label></td>
            </tr>
            <tr>
              <td height="25" align="right">��ʷ��ϸ��������:</td>
              <td height="25"><label>
                <select name="saveolddays" id="saveolddays">
                  <option value="10">������</option>
                  <option value="30">������</option>
                  <option value="50">������</option>
                  <option value="100">��������</option>
                </select>
              </label></td>
            </tr>
            <tr>
              <td height="25" align="right">Ĭ��ʱ��:</td>
              <td height="25"><select name="timezone">
<option value="-8" selected="selected">- ʹ��Ĭ�� -</option>
<option value="+12">(GMT -12:00) Eniwetok, Kwajalein</option>
<option value="+11">(GMT -11:00) Midway Island, Samoa</option>
<option value="+10">(GMT -10:00) Hawaii</option>
<option value="+9">(GMT -09:00) Alaska</option>
<option value="+8">(GMT -08:00) Pacific Time (US &amp; Canada)</option>
<option value="+7">(GMT -07:00) Mountain Time (US &amp; Canada)</option>
<option value="+6">(GMT -06:00) Central Time (US &amp; Canada)</option>
<option value="+5">(GMT -05:00) Eastern Time (US &amp; Canada)</option>
<option value="+4">(GMT -04:00) Atlantic Time (Canada), </option>
<option value="+3.5">(GMT -03:30) Newfoundland</option>
<option value="+3">(GMT -03:00) Brassila, Buenos Aires, </option>
<option value="+2">(GMT -02:00) Mid-Atlantic, Ascension Is.</option>
<option value="+1">(GMT -01:00) Azores, Cape Verde Islands</option>
<option value="0">(GMT) Casablanca, Dublin, Edinburgh</option>
<option value="-1">(GMT +01:00) Amsterdam, Berlin, Brussels</option>
<option value="-2">(GMT +02:00) Cairo, Helsinki, Kaliningrad</option>
<option value="-3">(GMT +03:00) Baghdad, Riyadh, Moscow</option>
<option value="-3.5">(GMT +03:30) Tehran</option>
<option value="-4">(GMT +04:00) Abu Dhabi, Baku, Muscat</option>
<option value="-4.5">(GMT +04:30) Kabul</option>
<option value="-5">(GMT +05:00) Ekaterinburg, Islamabad</option>
<option value="-5.5">(GMT +05:30) Bombay, Calcutta, Madras</option>
<option value="-5.75">(GMT +05:45) Katmandu</option>
<option value="-6">(GMT +06:00) Almaty, Colombo, Dhaka</option>
<option value="-6.5">(GMT +06:30) Rangoon</option>
<option value="-7">(GMT +07:00) Bangkok, Hanoi, Jakarta</option>
<option value="-8">(GMT +08:00) Beijing, Hong Kong, </option>
<option value="-9">(GMT +09:00) Osaka, Sapporo, Seoul</option>
<option value="-9.5">(GMT +09:30) Adelaide, Darwin</option>
<option value="-10">(GMT +10:00) Canberra, Guam, Melbourne</option>
<option value="-11">(GMT +11:00) Magadan, New Caledonia</option>
<option value="-12">(GMT +12:00) Auckland, Wellington, Fiji</option>
</select></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div align="center"> <br />
                <input name="step" type="hidden" id="step" value="3" />
                  <input name="Submit" type="submit" class="button" value="�ᡡ�����䡡��" />
              </div></td>
            </tr>
          </table>
        </form>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="18">&nbsp;</td>
    </tr>
  </tbody>
</table>
