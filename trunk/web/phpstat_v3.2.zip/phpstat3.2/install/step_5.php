<table cellspacing="2" cellpadding="1" width="670" align="center" border="0">
  <tbody>
    <tr>
      <td height="74"> <span class="heading">PHPStat Counter ��װ���ݿ�</span>
        <hr align="left" size="1" width="100%"/>
        
          <table width="100%" border="0" cellspacing="��" cellpadding="��">
            <tr>
              <td width="28%" rowspan="4"><table width="90%" height="200" border="0" cellpadding="5" cellspacing="3" style="border-right:2px solid #cccccc;">
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>1.���Ŀ¼����</td>
                </tr>
                <tr>
                  <td>2.����������</td>
                </tr>
                <tr>
                  <td>3.��װ���ݿ�</td>
                </tr>
                <tr>
                  <td><span class="heading">4.��װ���</span></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
              <td width="17%" height="25" align="right">&nbsp;</td>
              <td width="55%" height="25">&nbsp;</td>
            </tr>
            <tr>
              <td height="25" colspan="2" align="center"><div class=heading>��װ��ɣ��������һ������!</div></td>
            </tr>
            <tr>
              <td height="20" align="right">&nbsp;</td>
              <td height="20">&nbsp;</td>
            </tr>
            
            
            
            <tr>
              <td height="100">
		    <?
			$content = read_from_file( './install/count.js' );
			$content = str_replace( 'COUNTER_INSTALL_URL' , DOMAIN_NAME, $content );
	
			$content_com = read_from_file( './install/count.com.php' );
			$content_com = str_replace( 'COUNTER_INSTALL_URL' , DOMAIN_NAME, $content_com );
	
			write_to_file( './' . COUNT_DIRNAME . '/count.js', $content );
			copy( './install/count.php', './' . COUNT_DIRNAME . '/count.php' );
			write_to_file( './' . COUNT_DIRNAME . '/count.com.php', $content_com );

			copy( './install/bot.php', './' . COUNT_DIRNAME . '/bot.php' );
			copy( './install/sitename_bot.php', './' . COUNT_DIRNAME . '/sitename_bot.php' );

			@mkdir('./' . COUNT_DIRNAME . '/count');
			@mkdir('./' . COUNT_DIRNAME . '/bot');

			@rename('install.php','install.lock');	
	
			  ?>			  </td>
              <td><div align="center"> <br />
                  
                  <input name=Submit type=button class=button onclick=window.location='login.php' value=ɾ����װ�ļ�,����ת����¼����>
			
              </div></td>
            </tr>
          </table>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="18">&nbsp;</td>
    </tr>
  </tbody>
</table>
