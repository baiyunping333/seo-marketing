CREATE TABLE `PREFIX_adv` (
  `advid` int(10) unsigned NOT NULL auto_increment,
  `adv` varchar(32) NOT NULL default '',
  `website` varchar(20) NOT NULL default '',
  `times` int(11) NOT NULL default '0',
  `urls` varchar(255) NOT NULL default '',
  `link` char(2) NOT NULL default '&',
  `flag` int(1) NOT NULL default '0',
  `code` varchar(20) NOT NULL default '0',
  PRIMARY KEY  (`advid`),
  KEY `keyword` (`adv`,`times`,`flag`,`code`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
