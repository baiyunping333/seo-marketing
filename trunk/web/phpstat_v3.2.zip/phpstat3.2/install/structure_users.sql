CREATE TABLE `PREFIX_users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `manager` varchar(20) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `qq` varchar(16) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `msn` varchar(255) NOT NULL default '',
  `logincount` int(11) NOT NULL default '0',
  `lastlogin` int(11) NOT NULL default '0',
  `currentsitename` varchar(100) NOT NULL default '',
  `currentsitecode` varchar(100) NOT NULL default '',
  `groupname` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `phpstat_users_index` (`manager`,`password`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;