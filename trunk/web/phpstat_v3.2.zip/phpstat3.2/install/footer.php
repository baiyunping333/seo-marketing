<table width="692">
  <tr>
    <td width="223"><a 
      href="readme.html">����˵��</a></td>
    <td><div align="left"><a href="http://www.macromedia.com/go/dreamweaver_forum_cn">������̳</a></div></td>
    <td width="224"><a 
      href="http://www.phpstat.net/Article/2006/07/06/42.html">�ͻ�����</a><a href="http://www.macromedia.com/go/dreamweaver_devctr_cn"></a></td>
  </tr>
  <tr>
    <td width="223"><a href="http://www.phpstat.net/Article/Class_23_Time_1.html">�ĵ���Դ</a></td>
    <td width="223"><a href="http://bbs.phpstat.net/forumdisplay.php?fid=3">֧����Դ</a></td>
    <td width="224"><a 
      href="http://www.macromedia.com/go/dreamweaver_training_cn"></a></td>
  </tr>
  <tr>
    <td width="223"><a href="http://www.macromedia.com/go/dreamweaver8_whatsnew_cn"></a></td>
    <td><a 
      href="http://www.macromedia.com/go/dreamweaver_requests_cn"></a></td>
    <td><a 
      href="http://www.macromedia.com/go/dreamweaver_accessibility_cn"></a></td>
  </tr>
  <tr>
    <td><a href="./License.htm"></a></td>
    <td>&nbsp;</td>
    <td><a 
      href="http://www.macromedia.com/go/dreamweaver_cpp_cn"></a> </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><a 
      href="http://www.macromedia.com/go/dreamweaver_cs_cn"></a></td>
  </tr>
</table>
