CREATE TABLE `PREFIX_returner` (
  `returnerid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `returner` int(11) NOT NULL default '0',
  `times` int(11) NOT NULL default '0',
  `lastpage` varchar(255) NOT NULL default '',
  `counts` int(11) NOT NULL default '0',
  `types` int(11) NOT NULL default '0',
  PRIMARY KEY  (`returnerid`),
  KEY `keyword` (`returner`,`times`,`counts`,`types`,`website`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;