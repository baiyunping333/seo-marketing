CREATE TABLE `PREFIX_ip_data` (
  `ipid` int(10) unsigned NOT NULL auto_increment,
  `ipstart` bigint(20) NOT NULL default '0',
  `ipend` bigint(20) NOT NULL default '0',
  `country` varchar(255) NOT NULL default '',
  `address` varchar(100) NOT NULL default '',
  `province` varchar(32) NOT NULL default '',
  `city` varchar(32) NOT NULL default '',
  `area` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`ipid`),
  KEY `ipstart` (`ipstart`,`ipend`)
) TYPE=MyISAM AUTO_INCREMENT=63341 ;