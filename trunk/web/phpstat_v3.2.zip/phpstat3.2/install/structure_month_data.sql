CREATE TABLE `PREFIX_month_data` (
  `datamonthid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `times` int(11) NOT NULL default '0',
  `year` int(11) NOT NULL default '0',
  `month` int(11) NOT NULL default '0',
  `month_count` int(11) NOT NULL default '0',
  `month_count_ip` int(11) NOT NULL default '0',
  PRIMARY KEY  (`datamonthid`),
  KEY `times` (`times`),
  KEY `year` (`year`),
  KEY `month` (`month`),
  KEY `month_count` (`month_count`),
  KEY `month_phpstat_ip` (`month_count_ip`),
  KEY `website` (`website`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;