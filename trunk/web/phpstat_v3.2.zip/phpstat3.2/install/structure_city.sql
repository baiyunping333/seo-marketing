CREATE TABLE `PREFIX_city` (
  `cityid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `city` varchar(32) NOT NULL default '',
  `times` int(11) NOT NULL default '0',
  `lastpage` varchar(255) NOT NULL default '',
  `counts` int(11) NOT NULL default '0',
  `types` int(11) NOT NULL default '0',
  `province` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`cityid`),
  KEY `keyword` (`city`,`times`,`counts`,`types`,`website`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;