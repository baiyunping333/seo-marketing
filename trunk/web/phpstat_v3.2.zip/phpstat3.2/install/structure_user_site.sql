CREATE TABLE `PREFIX_user_site` (
`id` int( 4 ) NOT NULL AUTO_INCREMENT ,
`managerid` varchar( 20 ) NOT NULL default '',
`websiteid` varchar( 20 ) NOT NULL default '',
`code` varchar( 20 ) NOT NULL default '',
`groupname` varchar( 20 ) NOT NULL default '',
PRIMARY KEY ( `id` ) 
) TYPE = MYISAM ;
