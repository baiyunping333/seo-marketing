<table cellspacing="2" cellpadding="1" width="670" align="center" border="0">
  <tbody>
    <tr>
      <td height="74"> <span class="heading">PHPStat Counter ���Ŀ¼����</span>
        <hr align="left" size="1" width="100%"/>
        <form id="form1" name="form1" method="get" action="">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="28%" rowspan="5"><table width="90%" height="200" border="0" cellpadding="5" cellspacing="3" style="border-right:2px solid #cccccc;">
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>1.���Ŀ¼����</td>
                </tr>
                <tr>
                  <td><span class="heading">2.����������</span></td>
                </tr>
                <tr>
                  <td>3.��װ���ݿ�</td>
                </tr>
                <tr>
                  <td>4.��װ���</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
              <td></td>
            </tr>
            
            <tr>
              <td><? if($errors) {echo $errors;exit;}?></td>
            </tr>
            <tr>
              <td><? if($errors2) {echo $errors2;exit;}?></td>
            </tr>
			<tr>
              <td><? if($insert) {echo $insert;exit;}?></td>
            </tr>
            <tr>
              <td height="59">
		</td>
            </tr>
            <tr>
              <td height="59">&nbsp;</td>
            </tr>
          </table>
        </form>
        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="18">&nbsp;</td>
    </tr>
  </tbody>
</table>
