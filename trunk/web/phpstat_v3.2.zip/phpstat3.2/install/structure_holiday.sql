CREATE TABLE `PREFIX_holiday` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(250) default NULL,
  `typeid` varchar(250) default NULL,
  `datetime` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=103 ;
