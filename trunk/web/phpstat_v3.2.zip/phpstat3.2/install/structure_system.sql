CREATE TABLE `PREFIX_system` (
  `systemid` int(10) unsigned NOT NULL auto_increment,
  `website` varchar(50) NOT NULL default '',
  `system` varchar(32) NOT NULL default '0',
  `times` int(11) NOT NULL default '0',
  `lastpage` varchar(255) NOT NULL default '',
  `counts` int(11) NOT NULL default '0',
  `types` int(11) NOT NULL default '0',
  PRIMARY KEY  (`systemid`),
  KEY `keyword` (`system`,`times`,`counts`,`types`,`website`)
) TYPE=MyISAM AUTO_INCREMENT=1;