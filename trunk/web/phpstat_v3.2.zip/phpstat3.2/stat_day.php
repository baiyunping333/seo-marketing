<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';	
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'Date_Year'=>'intval', 'Date_Month'=>'intval', 'Date_Day'=>'intval','website'=>'strval' ) );
	$website = $_GET[website];
	include_once 'initmenu.php';
	if( isset( $_GET[Date_Year] ) )
	{
		$Year = isset( $_GET[Date_Year] ) ? intval( $_GET[Date_Year] ) : date(Y);
		$Month = isset( $_GET[Date_Month] ) ? intval( $_GET[Date_Month] ) : date(n);
		$Day = isset( $_GET[Date_Day] ) ? intval( $_GET[Date_Day] ) : date(d);
		$DataTime = mktime (0,0,0,$Month,$Day,$Year);
	}
	else
	{
		$DataTime = mktime (0,0,0,date("m"),date("d"),date("Y"));
		$Year = date( 'Y', $DataTime );
		$Month = date( 'm', $DataTime );
		$Day = date( 'd', $DataTime );
	}
	$Week = date( 'w', $DataTime );
 

	//��ȡ����ͳ����Ϣ
	$Res = $Conn->Execute( " select * from $TableList[day_data] where times = $DataTime and  website = '$website'" );
	$Row = $Res->FetchRow();
	
	for( $i = 0; $i < 24; $i++ )
	{
		$CountIp = $Row["hourip$i"] + rand(NUM1,NUM2);
		$Count = $Row["hour$i"] + rand(NUM1,NUM2);
		if( strlen( $i ) == 1 ) $j = '0'.$i;
		else $j = $i;
		$Tmp[] = $j.','.$CountIp.','.$Count;
		$SqlDatas[] = array('hours'=>date("Y-m-d",$Row[times])." ".$j.":00",'countIp'=>$CountIp,'count'=>$Count);
	}
	$Datas = implode( ';', $Tmp);
	$Tpl->assign( 'Data_time', date("Y-m-d",$DataTime) );
	$Tpl->assign( 'Data', $Datas );
	
	//����ͳ����Ϣ��������

	unset($Res);
	unset($Tmp);
	unset($Datas);
	//��ȡ����24Сʱ��¼
	$Res = $Conn->Execute( " select sum(hour0) as hour0, sum(hour1) as hour1, sum(hour2) as hour2, sum(hour3) as hour3, sum(hour4) as hour4, sum(hour5) as hour5, sum(hour6) as hour6, sum(hour7) as hour7, sum(hour8) as hour8, sum(hour9) as hour9, sum(hour10) as hour10, sum(hour11) as hour11, sum(hour12) as hour12, sum(hour13) as hour13, sum(hour14) as hour14, sum(hour15) as hour15, sum(hour16) as hour16, sum(hour17) as hour17, sum(hour18) as hour18, sum(hour19) as hour19, sum(hour20) as hour20, sum(hour21) as hour21, sum(hour22) as hour22, sum(hour23) as hour23, sum(hourip0) as hourip0, sum(hourip1) as hourip1, sum(hourip2) as hourip2, sum(hourip3) as hourip3, sum(hourip4) as hourip4, sum(hourip5) as hourip5, sum(hourip6) as hourip6, sum(hourip7) as hourip7, sum(hourip8) as hourip8, sum(hourip9) as hourip9, sum(hourip10) as hourip10, sum(hourip11) as hourip11, sum(hourip12) as hourip12, sum(hourip13) as hourip13, sum(hourip14) as hourip14, sum(hourip15) as hourip15, sum(hourip16) as hourip16, sum(hourip17) as hourip17, sum(hourip18) as hourip18, sum(hourip19) as hourip19, sum(hourip20) as hourip20, sum(hourip21) as hourip21, sum(hourip22) as hourip22, sum(hourip23) as hourip23 from $TableList[day_data]  where website = '$website'" );
	$Row = $Res->FetchRow();

	for( $i = 0; $i < 24; $i++ )
	{
		$CountIp = $Row["hourip$i"] + rand(NUM1,NUM2);
		$Count = $Row["hour$i"] + rand(NUM1,NUM2);
		if( strlen( $i ) == 1 ) $j = '0'.$i;
		else $j = $i;

		if($Count > 0)
			$HourList .= "[<a href=hour_history.php?website=$website&hour=$i title=\"�鿴ÿ�� $i ʱ����ʷ��¼\" class=titlefont_07>".$j."</a>]&nbsp;";
		else
			$HourList .= "[<font class=titlefont_06>".$j."</font>]&nbsp;";
		$Tmp[] = $j.','.$CountIp.','.$Count;

	}
	$Datas = implode( ';', $Tmp);	
	$Tpl->assign( 'Data_all', $Datas );
	$Tpl->assign( 'Hour_list', $HourList );	
	//��ȡ����24Сʱ��¼


	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'Day', $Day );	
	$Tpl->assign( 'Data_Time', date("Y-m-d",$DataTime) );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('��-��-�� ʱ','�������(IP)','�������(PV)')) ));
	$Tpl->assign( 'fname', 'page' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'Main', $Tpl->fetch( 'stat_day.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', 'ÿ��ͳ�� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', 'ÿ��ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=stat_day.php?website=$website>ÿ��ͳ��</a> <a href=stat_week.php?website=$website>ÿ��ͳ��</a> <a href=stat_month.php?website=$website>ÿ��ͳ��</a> <a href=stat_year.php?website=$website>ÿ��ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );

?> 
