<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';	
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval', 'engine'=>'strval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';	
	

	if( $Types == "1" )
	{	
		$Engines = array(
		'baidu.com',
		'google.com',
		'search.sohu.com',
		'search.sina.com.cn',
		'so.163.com',
		'websearch.yahoo.com',
		'search.lycos.com',
		'seek.3721.com',
		'search.qq.com',
		'search.tom.com',
		'sogou.com',
		'search.21cn.com',
		'search.aol.com'
		);
		$Where = ' and pagefromsite REGEXP "' . implode( '|', $Engines ) .'" ';
		//��¼����
		$Res = $Conn->Execute( " select id from $TableList[ip] where website = '$website' $Where group by pagefromsite" );
		$DataCount = $Res->RecordCount();
		
		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select count(*) as counts ,pagefromsite from $TableList[ip] where website = '$website' $Where group by pagefromsite ORDER BY `counts` DESC ", $PageSize ,$PageItems[Offset]);

		while( $Tmp = @$Res->FetchRow() )
		{
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$Tmp[referer] = $Tmp[pagefromsite];
			$CountAll += $Tmp[counts];
			$Datas[] = $Tmp;
			$SqlDatas[] = array('referer'=>$Tmp[referer],'pvcounts'=>$Tmp[counts]);
		}
	}

	if( $Types == '2' or $Types == '0')
	{
		unset($Datas);
		$Engines = array(
		'baidu.com',
		'google.com',
		'search.sohu.com',
		'search.sina.com.cn',
		'so.163.com',
		'websearch.yahoo.com',
		'search.lycos.com',
		'seek.3721.com',
		'search.qq.com',
		'search.tom.com',
		'sogou.com',
		'search.21cn.com',
		'search.aol.com'
		);
		$Where = ' and referer REGEXP "' . implode( '|', $Engines ) .'" ';
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where  .= " and times >= $StartTime and times < $EndTime ";
		}
		
		$Res = $Conn->Execute( " select count(*) as count  from $TableList[referer] where types = 4 $Where  and website = '$website'" );
		$Count = $Res->FetchRow();
		$DataCount = $Count[count];
		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select sum(counts) as counts ,referer from $TableList[referer] where types = 4 $Where and website = '$website' $Where group by  referer ORDER BY `counts` DESC ", $PageSize ,$PageItems[Offset]);


		while( $Tmp = @$Res->FetchRow() )
		{
			$Tmp[times] = date("Y-m-d H:i:s",$Tmp[times]);
			$CountAll += $Tmp[counts];
			$Datas[] = $Tmp;
			$SqlDatas[] = array('search'=>$Tmp[referer],'pvcounts'=>$Tmp[counts]);
		}

	}
	
	if( count( $Datas ) > 0 )
	{
		foreach( $Datas as $Key=>$Val )
		{		
			
			$Datas[$Key][Percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );
			$Datas[$Key][percent] = & $Datas[$Key][Percent];
		}
	}

	$Tpl->assign( 'Datas', $Datas );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('��Դ','����(PV)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode(" select referer,counts from $TableList[referer] where types = $Types $Where and website = '$website' ORDER BY `counts` DESC ") );
	$Tpl->assign( 'fname', 'referer' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	$Tpl->assign( 'Main', $Tpl->fetch( 'search.html' ) . $ScriptCode );
	
	$Tpl->assign( 'Title', '��������ͳ�� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '��������ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">��������</a> <a href=\"?website=$website&type=2\">��������</a> <a href=\"?website=$website&type=0\">��������</a>" );
		
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>