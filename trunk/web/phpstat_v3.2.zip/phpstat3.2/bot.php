<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './include.inc/function_bot.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ,'website'=>'strval') );
	$website = $_GET[website];
	include_once 'initmenu.php';


	if( $Types == "1" ) 
	{
		$Res = $Conn->Execute( " select counts ,bot from $TableList[bot] where website = '$website' and types = '1' ORDER BY counts desc " );
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$CountAll += $Tmp[counts];
			$Tmp[bot2] = $Tmp[bot];
			$Tmp[bot] = GetBot($Tmp[bot]);			
			$Datas[] = $Tmp;			
			$SqlDatas[] = array('returner'=>$Tmp[returner],'ipcounts'=>$Tmp[counts]);
		}

		if( count( $Datas ) > 0 )
		{
			foreach( $Datas as $Key=>$Val )
			{
				$Datas[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );
				$SqlDatas[] = array('bot'=>$Val[language],'ipcounts'=>$Val[counts],'precent'=>$Datas[$Key][percent]);
			}
		}
	}

	if( $Types == "2" or $Types == "0" ) 
	{
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where = " and times >= $StartTime and times < $EndTime ";
		}
		//��¼����
		$Res = $Conn->Execute( " select botid from $TableList[bot] where types = 3 and website = '$website' $Where GROUP BY bot" );
		$DataCount = $Res->RecordCount();

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}

		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->SelectLimit( " select sum(counts) as counts,bot from $TableList[bot] where types = 3 and website = '$website' $Where GROUP BY bot ORDER BY `counts` DESC ", $PageSize ,$PageItems[Offset] );

		while( $Tmp = @$Res->FetchRow() )
		{	
			$CountAll += $Tmp[counts];
			$Tmp[language2] = $Tmp[language];
			$Tmp[language] = GetLanguage( $Tmp[language] );				
			$Datas[] = $Tmp;
			//$SqlDatas[] = array('language'=>$Tmp[language],'ipcounts'=>$Tmp[counts]);
		}		
	}

	if( count( $Datas ) > 0 )
	{
		foreach( $Datas as $Key=>$Val )
		{
			$Datas[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );
			$SqlDatas[] = array('language'=>$Val[language],'ipcounts'=>$Val[counts],'precent'=>$Datas[$Key][percent]);
		}
	}
	$Tpl->assign( 'Datas', $Datas );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('����֩��','����')) ));
	$Tpl->assign( 'fname', 'bot' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	$Tpl->assign( 'Main', $Tpl->fetch( 'bot.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '����֩�� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '����֩��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>