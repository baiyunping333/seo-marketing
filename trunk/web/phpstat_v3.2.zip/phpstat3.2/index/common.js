function New(para_URL){
    var URL=new String(para_URL);
    window.open(URL,'','resizable,scrollbars')
}

function ShowJsPicture(){
    document.images.js_picture_style_1.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/1.gif";
    document.images.js_picture_style_2.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/2.gif";
    document.images.js_picture_style_3.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/3.gif";
    document.images.js_picture_style_4.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/4.gif";
    document.images.js_picture_style_5.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/5.gif";
    document.images.js_picture_style_6.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/6.gif";
    document.images.js_picture_style_7.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/7.gif";
    document.images.js_picture_style_8.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/8.gif";
    document.images.js_picture_style_9.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/9.gif";
    document.images.js_picture_style_0.src="images/js_picture/"+document.form.js_picture_style.options[document.form.js_picture_style.selectedIndex].value+"/0.gif";
}

function ShowJsIcon(){
    document.images.js_icon_style.src="images/js_icon/"+document.form.js_icon_style.options[document.form.js_icon_style.selectedIndex].value;
}

function ShowImageCustom(){
    document.images.image_custom_background.src="images/image_custom/"+document.form.image_custom_background.options[document.form.image_custom_background.selectedIndex].value;
}

function ToggleNode(nodeObject, imgObject,imgout,imgover){
    if(nodeObject.style.display == '' || nodeObject.style.display == 'inline'){
        nodeObject.style.display = 'none';
        imgObject.src=imgover;
    }else{
        nodeObject.style.display = 'inline';
        imgObject.src=imgout;
    }
}

function CopyTo(ob){
    var obj=FindObj(ob);
    if (obj){
        obj.select();js=obj.createTextRange();js.execCommand("Copy");
    }
}

function FindObj(n,d){
    var p,i,x;
    if(!d){d=document;}
    if((p=n.indexOf("?"))>0&&parent.frames.length){d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
    if(!(x=d[n])&&d.all){x=d.all[n];}
    for(i=0;!x&&i<d.forms.length;i++){x=d.forms[i][n];}
    for(i=0;!x&&d.layers&&i<d.layers.length;i++){x=FindObj(n,d.layers[i].document);}
    if(!x && document.getElementById){x=document.getElementById(n);}
    return x;
}


var save_color = "";
var TR_BG_COLOR = "#EAEAEA";
function Change_TR_Color(obj,flag)
{
	//document.all.save_color_text.value = "out:"+flag+"-"+obj.style.background;
	if(flag==1)  //move out
	{

		if(save_color!=TR_BG_COLOR && save_color!="")
		{
			//document.all.save_color_text.value = "out:"+save_color;
			obj.style.background = save_color;
			save_color = "";
		}
	}
	else if(flag==2)  //move over
	{
		if(obj.style.background!=TR_BG_COLOR && save_color=="")
		{
			//document.all.save_color_text.value = "in:"+obj.style.background;

			save_color = obj.style.background;
			obj.style.background=TR_BG_COLOR;
		}
	}
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}


function toogle_lan(obj)
{
	document.lanform.submit();
}


function set_tab_tag(ti,max_count){
	for(i=1;i<=max_count;i++){
		if(i==ti){

			document.getElementById('tl'+i).className='taglabel_active';
			document.getElementById('ts'+i).style.display='';
		}else{

			document.getElementById('tl'+i).className='taglabel';
			document.getElementById('ts'+i).style.display='none';
		}
	}
}



function check_client_upgrade()
{
	try{
		location.href= "app:upgrade";
	}
	catch(e)
	{
		alert("The online upgrade of your client is unsupported, please download latest version.");
	}
}

function generate_link(old_url)
{
	var obj = document.down_form.download_url;
	var url = obj.value;
	
	if(url=="")
	{
		alert("Please input full url path");
		obj.focus();
	}
	else
	{
		var obj2 = document.down_form.download_code;
		obj2.value = old_url+url;
	}
}