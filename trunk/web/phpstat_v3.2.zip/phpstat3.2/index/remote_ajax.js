<!--

function InitAjax() {

	var agt = navigator.userAgent.toLowerCase();
	var is_opera = (agt.indexOf("opera") != -1);
	var is_ie = (agt.indexOf("msie") != -1) && document.all && !is_opera;
	var is_ie5 = (agt.indexOf("msie 5") != -1) && document.all;

	if (is_ie) {    
		var control = (is_ie5) ? "Microsoft.XMLHTTP" : "Msxml2.XMLHTTP";
		try {      
			return new ActiveXObject(control);
		} catch(e) {
			alert("You need to enable active scripting and activeX controls");
			DumpException(e);
		}
	} else {
		return new XMLHttpRequest();
	}

}


function getLatestVersion(current_build)
{

	//获取新闻显示层的位置
	var div_show = document.getElementById("div_latest_version"); 

	//如果没有把参数newsID传进来
	if (typeof(current_build) == 'undefined')
	{
		div_show.innerHTML = "错误"; 
		return;
	}
	//需要进行Ajax的URL地址
	//var url = "http://demo.weamax.com/ads_version.php?current="+ current_version;
	//var url = "http://demo.weamax.com/ads_version.php?current="+ current_build;
	var url = "./get_ads_version.php?current="+ current_build;


	//实例化Ajax对象
	var ajax = InitAjax();

	//使用Get方式进行请求
	ajax.open("GET", url, true); 

	//获取执行状态
	ajax.onreadystatechange = function() { 
		//如果执行是状态正常，那么就把返回的内容赋值给上面指定的层
		if (ajax.readyState == 4 && ajax.status == 200) { 
			//div_show.innerHTML = ajax.responseText; 
			div_show.innerText = ajax.responseText; 
		} 
	}
	ajax.setRequestHeader("Content-Type","text/xml; charset=UTF-8");
	ajax.setRequestHeader("If-Modified-Since","0");
	//发送空
	ajax.send(null); 
}  


//document.domain="weamax.com";
function getServerSpeed(div_id,id)
{
	

	//获取新闻显示层的位置
	var div_show = document.getElementById(div_id); 

	//如果没有把参数newsID传进来
	if (typeof(id) == 'undefined')
	{
		div_show.innerHTML = "错误"; 
		return;
	}
	//需要进行Ajax的URL地址
	//var url = "http://demo.weamax.com/ads_version.php?current="+ current_version;
	//var url = "./get_file_content?id="+id;
	var url = "http://top.weamax.com/get_server_speed.php";


	//实例化Ajax对象
	var ajax = InitAjax();

	//使用Get方式进行请求
	ajax.open("GET", url, true); 

	//获取执行状态
	ajax.onreadystatechange = function() { 
		//如果执行是状态正常，那么就把返回的内容赋值给上面指定的层
		if (ajax.readyState == 4 && ajax.status == 200) { 
			//show.innerHTML = ajax.responseText; 
			div_show.innerText = ajax.responseText; 
		} 
	}
	ajax.setRequestHeader("Content-Type","text/xml; charset=UTF-8");
	ajax.setRequestHeader("If-Modified-Since","0");
	//发送空
	ajax.send(null); 
}  

function getNewsPageview(div_id,userpath,url)
{

	//获取新闻显示层的位置
	var div_show = document.getElementById(div_id); 

	//如果没有把参数newsID传进来
	if (typeof(url) == 'undefined')
	{
		div_show.innerHTML = "错误"; 
		return;
	}
	//需要进行Ajax的URL地址
	//var url = "http://demo.weamax.com/ads_version.php?current="+ current_version;
	var url = "./get_news_pageview?userpath="+userpath+"&sel_url="+url;

	//实例化Ajax对象
	var ajax = InitAjax();

	//使用Get方式进行请求
	ajax.open("GET", url, true); 

	//获取执行状态
	ajax.onreadystatechange = function() { 
		//如果执行是状态正常，那么就把返回的内容赋值给上面指定的层
		if (ajax.readyState == 4 && ajax.status == 200) { 
			//div_show.innerHTML = ajax.responseText; 
			div_show.innerText = ajax.responseText; 
		} 
	}
	ajax.setRequestHeader("Content-Type","text/xml; charset=UTF-8");
	ajax.setRequestHeader("If-Modified-Since","0");
	//发送空
	ajax.send(null); 
} 

function getDivContent(div_id,url)
{
	//如果没有把参数newsID传进来
	if (typeof(url) == 'undefined')
	{
		div_show.innerHTML = "错误"; 
		return;
	}

	if(url=="")
	{
		show_loading(0);
		return;

	}


	//获取新闻显示层的位置
	var div_show = document.getElementById(div_id); 
	div_show.style.visibility = "visible";
	var strdiv = "";



	//需要进行Ajax的URL地址

	//实例化Ajax对象
	var ajax = InitAjax();

	//使用Get方式进行请求
	ajax.open("GET", url, true); 

	//获取执行状态
	ajax.onreadystatechange = function() { 
		//如果执行是状态正常，那么就把返回的内容赋值给上面指定的层
		if (ajax.readyState == 4 && ajax.status == 200) { 
			
			strdiv = ajax.responseText;
			show_loading(0);
			if(strdiv=="NOLOGIN")
			{
				show_prompt();
			}
			else
			{
				div_show.innerHTML = "";
				div_show.innerHTML = strdiv; 

			}

		} 
	}
	ajax.setRequestHeader("Content-Type","text/html; charset=UTF-8");
	ajax.setRequestHeader("If-Modified-Since","0");
	//发送空
	ajax.send(null); 
} 



function show_loading(is_loading)
{
	if(is_loading==1)
	{
		start_loading();
		/*
		document.getElementById("ajax_div_loading").style.visibility = "visible";
		document.getElementById("ajax_div_loading").innerHTML = "Loading.... ";
		*/


	}
	else
	{
		stop_loading();
		/*
		document.getElementById("ajax_div_loading").style.visibility = "hidden";
		document.getElementById("ajax_div_loading").innerHTML = "";
		*/

	}
}

function getdata(url)
{
	if(url!=null)
	{
		show_loading(1);
		if(url.indexOf("opentop=1")>=0)
			location.href= url;
		else
			getDivContent('div_content',url);
	}
}


function show_prompt()
{

	getDivContent("div_prompt","login_box.php?act=login&mes=LOGIN");

}

function cancel_login()
{
	div_id = "div_prompt";
	var div_show = document.getElementById(div_id); 
	div_show.style.visibility = "hidden";
}

function submit_login()
{
	with(document.login)
	{
		if(username.value=="")
		{
			var obj = document.getElementById('login_username');
			obj.style.border = "#FF0000 solid 1px;";
			username.focus();
			return false;
		}

		if(password.value=="")
		{
			var obj = document.getElementById('login_password');
			obj.style.border = "#FF0000 solid 1px;";
			password.focus();
			return false;
		}

		var username_val = username.value;
		var password_val = password.value;
		var login_status_val = login_status.value;
		getDivContent("div_prompt","login_box.php?act=savelogin&username="+username_val+"&password="+password_val+"&login_status="+login_status_val);
		return false;
	}

}



function submit_feedback(field,obj)
{
	with(document.form1)
	{
		var val = obj.value;
		alert(val);
		if(val!="")
			getDivContent("status_"+field,"ajax_update.php?field="+field+"&val="+val);

		return false;
	}
}


/* aother progress bar */

var t_id = 0; //setInterval(animate,20);
var pos=0;
var dir=2;
var len=0;
function animate()
{

	var bar_width = 80;
	var bar_step = 30;
	var max_pos = bar_width - bar_step-3;

	var elem = document.getElementById('run_progress');
	if(elem != null) {
		if (pos==0) len += dir;
		if (len>bar_step || pos>max_pos) pos += dir;
		if (pos>max_pos) len -= dir;
		if (pos>max_pos && len==0) pos=0;
		elem.style.left = pos;
		elem.style.width = len;
	}
}

function start_loading() {
	document.getElementById("loader_bg").style.visibility = "visible";
	if(t_id==0)
		t_id = setInterval(animate,10);

}

function remove_loading() {

	document.getElementById("loader_bg").style.visibility = "hidden";

	this.clearInterval(t_id);
	
	var elem = document.getElementById('run_progress');
	if(elem != null) {
		elem.style.width = 0;
	}
	pos=0;
	dir=2;
	len=0;
	t_id = 0;
}


function stop_loading() {
	 setTimeout(remove_loading,800);
}


function open_userinfo_div(id,user,ip,hash)
{
	var trname = "tr_line"+id;
	var objname = "td_line"+id;

	var btnname = "user_button_"+id;

	var obj = document.getElementById(trname);
	var obj_btn = document.getElementById(btnname);

	if(obj.style.display == "")
	{
		obj_btn.src = "images/icons/open.gif";
		obj.style.display = "none";
	}
	else
	{
		obj_btn.src = "images/icons/close.gif";
		obj.style.display = "";
		getDivContent(objname,"ajax_getuserinfo.php?op=show&user="+user+"&ip="+ip+"&hash="+hash);
	}
	

}

//-->