<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/14	
*/
/*
	2006-10-14 ��PHP��mysql���ݿ�ת��Ϊxml�ļ�
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';	
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title> PHPStat Standard -- CSV��������</title>
<link href="./templates/business/imagefiles/style.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript" src="./templates/business/imagefiles/func.js"></SCRIPT>
</head>
<body topmargin="0">
<center>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      <td width="1%" height="">&nbsp; </td>
      <td width="99%" ><table width="99%"  border="0" align="left" cellpadding="0" cellspacing="0">
          <tr> 
            <td valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr class=titlefont_02> 
                  <td width="76%">&nbsp;&nbsp;���ڲ鿴 �� | TXT�������� 
                  </td>
                  <td width="24%" valign="middle"> <div align="center"></div></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td height="0" valign="top" class="cod"> <div class="mainbody">
                <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
                <SCRIPT LANGUAGE="JavaScript">
<!--
function killErrors()
{
  return true;
}

window.onerror = killErrors;
self.moveTo(100,120); 
self.resizeTo(700,500);
self.focus(); 
window.defaultStatus="��ҳ60���Ӻ��Զ��ر�"; 
setTimeout("window.close()",60000);
//-->
</SCRIPT>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
                    <td height="27" valign="top"> </td>
                  </tr>
                </table>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <TR> 
                    <TD height=40 class=pagelink>
<?  
	Initialize( $_POST, array( 'website'=>'strval','datas'=>'strval','datastitle'=>'strval' ,'fname'=>'strval','nowview'=>'strval','sql'=>'strval' ) );
	$website = $_POST[website];
	include_once './initmenu.php';
	include_once './parse_site.php';
	$sql   = urldecode($_POST[sql]);
	$datastitle   = unserialize(urldecode($_POST[datastitle]));
	if($sql != "")
	{
		$D = $Conn->Execute($sql);
		$records = 1;
		while( $Tmp = $D->FetchRow() )
		{
			$alldatas[] = $Tmp;
			$records = $records + 1;
		}

		$filestr .= "#".$_POST[nowview]."\n";
		foreach($datastitle as $valuearray)
		{	
		$filestr .= $valuearray."\t";
		}
	    //�г�һ�������еļ�¼ 
		foreach($alldatas as $valuearray)
		{	
			$filestr .= "\n";
			foreach($valuearray as $key=>$value) {
			$filestr .=$value."\t"; 
			}
		}  
		
		//����xml�ļ� 
		$filename="files/".$website."_".$_POST[fname].".txt"; 
		$fp=fopen("$filename","w"); 
		fwrite($fp,$filestr); 
		fclose($fp); 
	}

	$datas = unserialize(urldecode($_POST[datas]));
	$filestr = "#".$nowview."\n";
	foreach($datastitle as $valuearray)
    {	
		$filestr .= $valuearray."\t";
	}
    //�г�һ�������еļ�¼ 
    if(count($datas) > 0)
    foreach($datas as $valuearray)
    {	
		$filestr .= "\n";
		foreach($valuearray as $key=>$value) {
        $filestr .=$value."\t"; 
		}
	}    

	//����csv�ļ� 
	if($records > 1)
	{
		$filename_yulan="files/".$website."_".$_POST[fname]."_1.txt"; 
		$fp=fopen("$filename_yulan","w"); 
	}
	else			
	{
		$filename="files/".$website."_".$_POST[fname].".txt"; 
		$fp=fopen("$filename","w"); 
	}	
	fwrite($fp,$filestr); 
	fclose($fp); 

?>
                      <p>&nbsp;</p>
                      <p>&nbsp;</p></TD>
                  </TR>
                  <TR > 
                    <TD >&nbsp;</TD>
                  </TR>
                  <TR class=titlefont_02> 
                    <TD >&nbsp;&nbsp;������Ϣ</TD>
                  </TR>
                  <TR> 
                    <TD height=40 align=middle valign="middle">&nbsp;</TD>
                  </TR>
                  <TR> 
                    <TD height=40 align=middle valign="middle">&nbsp;</TD>
                  </TR>
                  <TR> 
                    <TD height=40 align=center valign="middle">
<p>&nbsp;</p>
                      <p> 
						 <input type="button" name="Submit" value="TXT����Ԥ��" onclick="window.open('<?if($records > 100)echo $filename_yulan;else echo $filename;?>','','')">
                        <input type="button" name="Submit" value="TXT��������" onclick="location.href='download.php?fname=<?=$website."_".$_POST[fname]?>.txt&fpath=<?=$filename?>'">
						<input type="button" name="Submit" value="�ر�����" onclick="window.close()">
                      </p>
                      <p>&nbsp;</p></TD>
                  </TR>
                </table>
              </div></td>
          </tr>
          <tr> 
            <td height="24" class=copyright> <p>Copyright &copy; 2005-2006 PHPStat.net 
                &nbsp;&nbsp;Power by <a href=http://www.phpstat.net target=_blank>PHPStat.net</a> 
                &nbsp;&nbsp;PHPStat&#8482; Build <a href="readme.htm" target="_blank">20060618</a> 
                inside </td>
          </tr>
        </table></td>
    </tr>
  </table>

</center>

</body>

</html>


