<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/09	
*/
/*
	2006-10-09 �����ӵ��ļ����޸��ˡ������������Ĳ鿴��ʽ
*/
	session_start();

	ini_set('max_execution_time',5000);
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'website'=>'strval','Date_Num'=>'intval','TotalDays'=>'intval','loop'=>'strval' ) );
	$website = strval($_GET[website]);
	include_once './initmenu.php';
	if($website != "" and $_GET[loop] == "")
	{	
		$SearchTime = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$Res	   = $Conn->Execute( "select max(time) as maxtime from $TableList[ip]  where website = '$website' and time < $SearchTime" );
		$Tmp       = $Res->FetchRow();
		$MaxTime   = $Tmp[maxtime];
		unset($Res);unset($Tmp);
		$Res	   = $Conn->Execute( "select min(time) as mintime from $TableList[ip] where website = '$website' and time < $SearchTime" );
		$Tmp       = $Res->FetchRow();
		$MinTime   = $Tmp[mintime] <= 0 ?mktime(0,0,0,date('m'),date('d'),date('Y')):$Tmp[mintime];

		$_GET[TotalDays] = ceil(($SearchTime-$MinTime)/86400);
		$_GET[Date_Num]  = 0;
		$_GET[loop]      = "do";
	}
	//echo $_GET[Date_Num];echo "&nbsp;";echo $_GET[TotalDays];
	//echo "URL=?website=".$website."&TotalDays=".$_GET[TotalDays]."&loop=do&Date_Num=".$_GET[Date_Num]."";
	if($website != "" and $_GET[loop] == "do" and ($_GET[TotalDays] > $_GET[Date_Num]))
	{	
		$StartTime = mktime(0,0,0,date('m'),date('d'),date('Y')) - $Date_Num * 86400;
		$EndTime   = mktime(0,0,0,date('m'),date('d'),date('Y')) - ($Date_Num+1) * 86400;
		//print "�������� ".date("Y-m-d",($StartTime-86400))." ����ʷ��¼<BR>";		
		//���ҳ����ʷ��¼
		$Sql = "SELECT count(id) as counts , pageurl,pagetitle from $TableList[ip] where time < $StartTime and time >= $EndTime and website = '$website' and pageurl != '' group by pageurl order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			//echo $Tmp[counts];
			$Sql = "INSERT INTO " . $TableList[page] . " ( `website`,`page`,`pagetitle`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[pageurl]}','{$Tmp[pagetitle]}','{$EndTime}', '{$Tmp[counts]}', '3');";
			@$Conn->Execute( $Sql );
		}

		//��·ҳ����ʷ��¼
		$Sql = "SELECT count(id) as counts , pagefrom from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and todayfirst = 1 group by pagefrom order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{			
			$Sql = "INSERT INTO " . $TableList[referer] . " ( `website`,`referer`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[pagefrom]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		
		//��·ҳ����ʷ��¼
		$Sql = "SELECT count(id) as counts , pagefromsite from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and todayfirst = 1 group by pagefromsite order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{			
			$Sql = "INSERT INTO " . $TableList[referer] . " ( `website`,`referer`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[pagefromsite]}','{$EndTime}', '{$Tmp[counts]}', '4' );";
			@$Conn->Execute( $Sql );
		}

		//���ҳ����ʷ��¼
		$Sql = "SELECT count(id) as counts , pageurl,pagetitle from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and pageurl != '' and todayfirst = 1 group by pageurl order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{			
			$Sql = "INSERT INTO " . $TableList[page] . " ( `website`,`page`,`pagetitle`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[pageurl]}','{$Tmp[pagetitle]}','{$EndTime}', '{$Tmp[counts]}', '4' );";
			@$Conn->Execute( $Sql );
		}
		//������ʷ��¼
		$Sql = "SELECT count(id) as counts , country from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and country != '' and todayfirst = 1 group by country order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[country] . " ( `website`,`country`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[country]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}

		//ʡ����ʷ��¼
		$Sql = "SELECT count(id) as counts , province,country from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and province != '' and todayfirst = 1 group by province order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[province] . " ( `website`,`province`, `times`, `counts`,`types`,`country` ) VALUES ( '{$website}','{$Tmp[province]}','{$EndTime}', '{$Tmp[counts]}', '3' , '{$Tmp[country]}');";
			@$Conn->Execute( $Sql );
		}


		//������ʷ��¼
		$Sql = "SELECT count(id) as counts , city ,province from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and city != '' and todayfirst = 1 group by city order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[city] . " ( `website`,`city`, `times`, `counts`,`types`,`province` ) VALUES ( '{$website}','{$Tmp[city]}','{$EndTime}', '{$Tmp[counts]}', '3','{$Tmp[province]}' );";
			@$Conn->Execute( $Sql );
		}

		//������ʷ��¼
		$Sql = "SELECT count(id) as counts , address ,city from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and address != '' and todayfirst = 1 group by address order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[area] . " ( `website`,`area`, `times`, `counts`,`types`,`city` ) VALUES ( '{$website}','{$Tmp[address]}','{$EndTime}', '{$Tmp[counts]}', '3','{$Tmp[city]}' );";
			@$Conn->Execute( $Sql );
		}

		//�ؼ�����ʷ��¼
		$Sql = "SELECT count(id) as counts , keyword ,pagefromsite,pagefrom from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and keyword != '' group by keyword ,pagefromsite order by counts desc;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{	
			
			$Sql = "INSERT INTO " . $TableList[keyword] . " ( `website`,`keyword`, `times`, `lastpage`,`fromsite`,`counts`,`types` ) VALUES ( '{$website}','{$Tmp[keyword]}','{$EndTime}','{$Tmp[pagefrom]}','{$Tmp[pagefromsite]}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}

		//����֩������ʷ��¼
		$Sql = "SELECT counts , bot from " . $TableList[bot] . " where times < $StartTime and times >= $EndTime and website = '$website' ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[bot] . " ( `website`,`bot`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[keyword]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}

		//��ͷ����ʷ��¼
		$Sql = "SELECT count(id) as counts , returner from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and returner != '0' and todayfirst = 1 group by returner  order by counts desc limit 50 ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[returner] . " ( `website`,`returner`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[returner]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		
		//�������½���
		$Sql = "SELECT count(id) as counts ,CEILING((lasttime-firsttime)/86400) as days from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and todayfirst = 1 and returner != '0' group by days  order by counts desc limit 50;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[returner] . " ( `website`,`returner`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[days]}','{$EndTime}', '{$Tmp[counts]}', '4' );";
			@$Conn->Execute( $Sql );
		}
		
		//�����������
		$Sql = "SELECT count(id) as counts ,browser from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and browser != '' and todayfirst = 1 group by browser ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[browser] . " ( `website`,`browser`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[browser]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//�������������ɫ
		$Sql = "SELECT count(id) as counts ,color from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and color != '' and todayfirst = 1 group by color ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[color] . " ( `website`,`color`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[color]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//���������������
		$Sql = "SELECT count(id) as counts ,language from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and language != '' and todayfirst = 1 group by language ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[language] . " ( `website`,`language`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[language]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//������ʱ��
		$Sql = "SELECT count(id) as counts ,timezone from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and timezone != '' and todayfirst = 1 group by timezone ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[timezone] . " ( `website`,`timezone`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[timezone]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//������ϵͳ
		$Sql = "SELECT count(id) as counts ,system from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and system != '' and todayfirst = 1 group by system ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[system] . " ( `website`,`system`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[system]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//��������Ļ�ߴ�
		$Sql = "SELECT count(id) as counts ,screensize from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and screensize != '' and todayfirst = 1 group by screensize ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[screen] . " ( `website`,`screen`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$Tmp[screensize]}','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//JAVA����
		$Sql = "SELECT count(id) as counts ,java from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and java != '0' and todayfirst = 1 group by java ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[plug] . " ( `website`,`plug`, `times`, `counts`,`types` ) VALUES ( '{$website}','java','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//JAVA����(δ��װ)
		$Sql = "SELECT count(id) as counts ,java from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and java = '0' and todayfirst = 1 group by java ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[plug] . " ( `website`,`plug`, `times`, `counts`,`types` ) VALUES ( '{$website}','java','{$EndTime}', '{$Tmp[counts]}', '4' );";
			@$Conn->Execute( $Sql );
		}
		//FLASH����
		$Sql = "SELECT count(id) as counts ,flash from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and flash != '0' and todayfirst = 1 group by flash ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[plug] . " ( `website`,`plug`, `times`, `counts`,`types` ) VALUES ( '{$website}','flash','{$EndTime}', '{$Tmp[counts]}', '3' );";
			@$Conn->Execute( $Sql );
		}
		//FLASH����(δ��װ)
		$Sql = "SELECT count(id) as counts ,flash from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and flash = '0' and todayfirst = 1 group by flash ;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "INSERT INTO " . $TableList[plug] . " ( `website`,`plug`, `times`, `counts`,`types` ) VALUES ( '{$website}','flash','{$EndTime}', '{$Tmp[counts]}', '4' );";
			@$Conn->Execute( $Sql );
		}
		//�����߷���ʱ��
		$Sql = "SELECT ip from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and todayfirst = 1 group by ip;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{		
			$Sql = "SELECT max(time) as maxtime,min(time) as mintime from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' and ip = '$Tmp[ip]';";
			$ResTime = @$Conn->Execute( $Sql );
			while($RowTime = $ResTime->FetchRow())
			{	
				if(($RowTime[maxtime] - $RowTime[mintime]) <= 10)
					$onLimeTime[0]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 30)
					$onLimeTime[1]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 60)
					$onLimeTime[2]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 180)
					$onLimeTime[3]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 600)
					$onLimeTime[4]++;
				elseif(($RowTime[maxtime] - $RowTime[mintime]) <= 1800)
					$onLimeTime[5]++;
				else
					$onLimeTime[6]++;

			}
			
		}
		$onLineTimes = array(10,30,60,180,600,1800,1801);
		if(count($onLimeTime) > 0)
		foreach($onLimeTime as $key => $value)
		{
			$Sql = "INSERT INTO " . $TableList[returner] . " ( `website`,`returner`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$onLineTimes[$key]}','{$EndTime}', '{$value}', '5' );";
			@$Conn->Execute( $Sql );
		}


		//�����߷������
		$Sql = "SELECT count(id) as counts from " . $TableList[ip] . " where time < $StartTime and time >= $EndTime and website = '$website' group by ip order by counts asc;";
		$Res = @$Conn->Execute( $Sql );
		unset($Tmp);
		while($Tmp = $Res->FetchRow())
		{				
				
				if($Tmp[counts] <= 1)
					$onLimeDepth[0]++;
				elseif($Tmp[counts] <= 2)
					$onLimeDepth[1]++;
				elseif($Tmp[counts] <= 3)
					$onLimeDepth[2]++;
				elseif($Tmp[counts] <= 4)
					$onLimeDepth[3]++;
				elseif($Tmp[counts] <= 5)
					$onLimeDepth[4]++;
				elseif($Tmp[counts] <= 6)
					$onLimeDepth[5]++;
				elseif($Tmp[counts] <= 7)
					$onLimeDepth[6]++;
				elseif($Tmp[counts] <= 8)
					$onLimeDepth[7]++;
				elseif($Tmp[counts] <= 9)
					$onLimeDepth[8]++;
				elseif($Tmp[counts] <= 10)
					$onLimeDepth[9]++;
				elseif($Tmp[counts] <= 11)
					$onLimeDepth[10]++;
				elseif($Tmp[counts] <= 12)
					$onLimeDepth[11]++;
				elseif($Tmp[counts] <= 13)
					$onLimeDepth[12]++;
				elseif($Tmp[counts] <= 14)
					$onLimeDepth[13]++;
				elseif($Tmp[counts] <= 15)
					$onLimeDepth[14]++;
				elseif($Tmp[counts] <= 16)
					$onLimeDepth[15]++;
				elseif($Tmp[counts] <= 17)
					$onLimeDepth[16]++;
				elseif($Tmp[counts] <= 18)
					$onLimeDepth[17]++;
				elseif($Tmp[counts] <= 19)
					$onLimeDepth[18]++;
				elseif($Tmp[counts] <= 20)
					$onLimeDepth[19]++;
				else
					$onLimeDepth[20]++;			
			
		}
		//$onLineTimes = array(10,30,60,180,600,1800,1801);
		//print_r($onLimeDepth);
		if(count($onLimeDepth) > 0)
		foreach($onLimeDepth as $key => $value)
		{	
			if($value > 0)
			{	
				$key1 = $key+1;
				$Sql = "INSERT INTO " . $TableList[returner] . " ( `website`,`returner`, `times`, `counts`,`types` ) VALUES ( '{$website}','{$key1}','{$EndTime}', '{$value}', '6' );";
				@$Conn->Execute( $Sql );
			}
		}


		//$StartTime = mktime(0,0,0,date('m'),date('d'),date('Y'));
		$Conn->Execute( "INSERT INTO $TableList[ip_history] select * from $TableList[ip] where website = '$website' and time < $StartTime and time >= $EndTime " );
		$Conn->Execute( "DELETE FROM  $TableList[ip] where website = '$website' and time < $StartTime and time >= $EndTime " );
		$_GET[Date_Num] = $_GET[Date_Num] + 1;
		echo "<meta http-equiv=\"refresh\" content=\"1;URL=?website=".$website."&TotalDays=".$_GET[TotalDays]."&loop=do&Date_Num=".$_GET[Date_Num]."\">";
		
	}
	if($_GET[TotalDays] <= $_GET[Date_Num])
	{	
		//$StartTime = mktime(0,0,0,date('m'),date('d'),date('Y')) - SAVE_OLD_DAYS * 86400;	
		//$Conn->Execute( "DELETE FROM  $TableList[ip_history] where website = '$website' and time < $StartTime" );
		//header("templates/business/top.php");
		echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--
			//if(confirm('�в�����ʷ������Ҫת��,�Ƿ����?������ʷ���ݿ��ܲ�̫׼ȷ')) 
			location='templates/business/top.php?website=$website'
			//-->
			</SCRIPT>";
	}
		
?>