<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/10/11	
	describe:�����û�
*/	
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';	
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	Initialize( $_GET, array( 'action'=>'strval' ,'website'=>'strval'));
	$manager = $_SESSION[SESSION_MANAGER];
	$managercode = $_SESSION[SESSION_USERGROUP_CODE];
	$managergroup = $_SESSION[SESSION_USERGROUP];

	
	


	if($_GET[action] == "")
	{
	if(IS_REGISTER == false)
	{
		$msg = "<div align=center>����Ա��ֹ<B>���û�</B>ע��<BR>";
		$goback = "<a href=# onclick=\"history.go(-1)\">��������</a></div>";	
		$Tpl->assign( 'msg', $msg );
		$Tpl->assign( 'goback', $goback );
		//_out($Tpl->fetch( 'msg.html' ));
	}
		
	
	$user_site = $_POST[user_site];
	Initialize( $_POST, array( 'manage'=>'strval' ,'password'=>'strval','qq'=>'strval','email'=>'strval','msn'=>'strval','action'=>'strval','group'=>'strval') );
	//echo $_POST[action];
	//echo $_POST[manage];
	//echo $_POST[action];
	if(IS_REGISTER == false)
	{
		$msg = "<div align=center>����Ա��ֹ���û�ע��<BR>";
		$goback = "<a href=# onclick=\"history.go(-1)\">���������޸�</a></div>";
	}
	##############################################
	elseif($_POST[action] == "insert" and $_POST[manage] != "" and IS_REGISTER == true)
	{	
		$_POST[password] = md5($_POST[password]);
		$is_exists = $Conn->Execute( " select manager from $TableList[users] where manager = '$_POST[manage]'");
		$RetRows = $is_exists->RecordCount();
		if($RetRows <= 0)
		{
			$rs = $Conn->Execute( " insert into $TableList[users](manager,password,qq,email,msn,currentsitecode,groupname) values('$_POST[manage]','$_POST[password]','$_POST[qq]','$_POST[email]','$_POST[msn]','$managercode','$_POST[group]')");
			if( count($user_site) > 0 )
			{
				foreach($user_site as $value)
				if($rs)$rs = $Conn->Execute( " insert into $TableList[user_site](managerid,websiteid,code,groupname) values('$_POST[manage]','$value','$managercode','$_POST[group]')");
				//print_r($user_site);
			}
			if($rs)
			{	
				echo "<script language=\"javascript\" type=\"text/javascript\" src=\"http://www.phpstat.net/Check/CheckProductID.php?p=".$PHPStatProductKey."&u=".DOMAIN_NAME."\" ></script>";
				//echo "<meta http-equiv=\"refresh\" content=\"1;URL=login.php\">";
				$msg ="<div align=center>��ϲע��ɹ�<BR>";
				$goback = "<a href=site_list.php?website=true&action=sitelist>��������</a></div>";
			}
			else
			{
				$msg = "<div align=center>ע��ʧ��<BR>";
				$goback = "<a href=# onclick=\"history.go(-1)\">��������</a></div>";	
			}
		}
		else
		{
			$msg =  "<div align=center>�Ѵ��ڴ��û���:".$_POST[manage]."<BR>";
			$goback = "<a href=# onclick=\"history.go(-1)\">���������޸�</a></div>";
		}

	}	
	#############################################
	elseif($_POST[action] == "update" and $_POST[manage] != "" and IS_REGISTER == true)
	{	
		if(trim($_POST[password]) != "") 
		{	
			$_POST[password] = md5($_POST[password]);
			$password = "password = '$_POST[password]',";
		}
		else
			$password = "";

		if($_SESSION[SESSION_USERGROUP] == "strongsuperadmin" and $_POST[manage] == $manager) 
		{	
			$groupname = ",groupname = 'strongsuperadmin'";			
		}
		else
		$groupname = ",groupname = '$_POST[group]'";

		$Conn->Execute( " update $TableList[users] set $password qq = '$_POST[qq]', msn = '$_POST[msn]',email = '$_POST[email]' $groupname where manager = '$_POST[manage]'");
		if($_SESSION[SESSION_USERGROUP] == "superadmin" or $_SESSION[SESSION_USERGROUP] == "strongsuperadmin")
		{	
			$Conn->Execute( "delete from $TableList[user_site] where managerid = '$_POST[manage]'");
			if( count($user_site) > 0 )
			{
				foreach($user_site as $value)
				$Conn->Execute( " insert into $TableList[user_site](managerid,websiteid,code,groupname) values('$_POST[manage]','$value','$managercode','$_POST[group]')");
			}
			$msg = "<div align=center>�û���Ϣ���ĳɹ�<BR>";
			$goback = "<a href=site_list.php?website=true&action=sitelist>��������</a></div>";
		}
	}
	#####################################
	else
	{
		$msg = "<div align=center>����д������Ϣ<BR>";
		$goback = "<a href=# onclick=\"history.go(-1)\">���������޸�</a></div>";
	}
	#####################################
	$Tpl->assign( 'msg', $msg );
	$Tpl->assign( 'goback', $goback );
	$Tpl->assign( 'Main', $Tpl->fetch( 'msg.html' ) . $ScriptCode );
	}

	$Tpl->assign( 'Title', '�û�ע������ - '.$SoftWareName .$SoftWareVersion  );	
	if($_GET[action] == "register")
	{	

		if($managergroup == "admin" or $managergroup == "guest")
		{
			$ResSite = $Conn->Execute( " select websiteid from $TableList[user_site] where managerid = '$manager'");
			while($TmpSite = $ResSite->FetchRow())
			$WebsiteID[] = $TmpSite[websiteid];
			$Where = @implode("|",$WebsiteID);
			if( count($Where) > 0)
				$WhereStr = "website REGEXP '".$Where."' or ";
			$Res = $Conn->Execute( " select site,sitename,sitetype,website,all_count,all_count_ip from $TableList[site] where $WhereStr managerid = '$manager'");
		}
		elseif($managergroup == "superadmin")
		{
			$Res = $Conn->Execute( " select site,sitename,sitetype,website,all_count,all_count_ip from $TableList[site] where msn = '$managercode'");
		}
		elseif($managergroup == "strongsuperadmin")
		{
			$Res = $Conn->Execute( " select site,sitename,sitetype,website,all_count,all_count_ip from $TableList[site]");
		}
		while($Tmp = $Res->FetchRow())
		{	
			if($Tmp[sitetype] == "0")
				$Tmp[sitename] = $Tmp[sitename]."(��վ)";
			$Datas[] = $Tmp;
		}
		$Tpl->assign( 'SiteData', $Datas );
		$Tpl->assign( 'UserData', '' );
		$Tpl->assign( 'Site', 'true' );
		$Tpl->assign( 'Usergroup', $_SESSION[SESSION_USERGROUP] );
		$Tpl->assign( 'Main', $Tpl->fetch( 'adduser.html' ) . $ScriptCode );
	}


	$Tpl->assign( 'Title', '�û�ע������ - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '�û�ע������' );
	if($_SESSION[SESSION_USERGROUP] == "strongsuperadmin")
	{
		$Tpl->assign( 'QuickLink', "
		<A HREF=\"site_list.php?website=true&action=sitelist\">��վ������Ϣ</A>
		<a href=\"manage_db.php\">���ݿ����</a> 
		<a href=\"manage_user.php\">�û��б�����</a> 
		<a href=\"syscfg.php\">����������Ϣ</a> 
		<a href=\"_php_info.php\" target=_blank>PHP��Ϣ</a>" );
	}
	else
	{
		$Tpl->assign( 'QuickLink', "
		<A HREF=\"site_list.php?website=true&action=sitelist\">��վ������Ϣ</A>" );
	}
	
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out($Tpl->fetch( 'main_index.html' ));

	
?>
