<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './include.inc/function_timezone.php';
	include_once './include.inc/function_language.php';
	include_once './include.inc/function_system.php';

	Initialize( $_GET, array( 'page'=>'intval','searchip'=>'strval' , 'website'=>'strval' ) );
	$website = $_GET[website];
	$Year = date( 'Y' );
	$Month = date( 'm' );
	$Day = date( 'd' );
	$StartTime = mktime (0,0,0,$Month,$Day,$Year ) - SAVE_OLD_DAYS * 24 * 3600;
	$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );
	$_GET[searchip] = trim($_GET[searchip]);
	IF($_GET[searchip] == "") $_GET[searchip] = '127.0.0.1';
	$Res = $Conn->SelectLimit( " select *   from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and  website = '$website' and ip = '$_GET[searchip]' and todayfirst = 1 order by time desc  ",'1','0' );
	$Datas[] =  $Res->FetchRow();
	$DataCount = $Res->RecordCount();
	
	if($DataCount > 0) 
	{
		$Tpl->assign( 'Show', "yes" );
		$Datas[0][language] = GetLanguage( $Datas[0][language] );
		 $Timezone = GetTimeZone( $Datas[0][timezone] );
		 $Datas[0][timezone] = $Timezone[0].$Timezone[1];
		$Datas[0][system] = GetSystem( $Datas[0][system] );
			$Datas[0][alexatool] =  $Datas[0][alexatool] == 1 ? "װ��Alexa������" : "û��Alexa������";		
		$Tpl->assign( 'Datas1', $Datas );
	}
	//��¼���� 
	//unset($Datas);
	unset($Count);
	unset($DataCount);
	$Res = $Conn->Execute( " select count(*) as count  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and  website = '$website' and ip = '$_GET[searchip]'" );
	$Count = $Res->FetchRow();
	$DataCount = $Count[count];

	$PageSize = 20;
	if( $DataCount > 0 )
	{
		include_once ( './include.inc/page.inc.php' );
		$PageItems = MakePageItems ( $DataCount, $PageSize );
		$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
		$Tpl->assign( 'PageLinks', $PageLinks );
	}
	if($PageItems[Offset] == "")$PageItems[Offset] = 0; 
	$Res = $Conn->SelectLimit( " select *  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' and ip = '$_GET[searchip]' ORDER BY `time` DESC " , $PageSize ,$PageItems[Offset] );	

	while( $Tmp = @$Res->FetchRow() )
	{
		$Tmp[language] = GetLanguage( $Tmp[language] );
		$Tmp[timezone] = GetTimeZone( $Tmp[timezone] );
		$Tmp[system] = GetSystem( $Tmp[system] );
		preg_match( "|http://[^/]+?(/.*)|is", $Tmp[pageurl], $Tmp1 );
		$Tmp[pagesite] = trim( $Tmp1[1] );		
		$Tmp[time] = date("Y-m-d H:i:s",$Tmp[time]);
		$Datas[] = $Tmp;
	}

	$Tpl->assign( 'Datas', $Datas );	
	$Tpl->assign( 'Title', '����ָ��IP - '.$SoftWareName .$SoftWareVersion);
	$Tpl->assign( 'Main', $Tpl->fetch( 'searchip.html' ) );
	$Tpl->assign( 'NowView', '����ָ��IP' );
	//$Tpl->assign( 'QuickLink', '' );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>
