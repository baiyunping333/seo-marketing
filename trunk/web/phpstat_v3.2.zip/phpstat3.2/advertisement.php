<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';	
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	initialize( $_GET, array( 'action'=>'strval','type'=>'intval', 'page'=>'intval', 'website'=>'strval','value'=>'intval','advid'=>'intval') );
	$website = $_GET[website];
	include_once 'initmenu.php';
	
	if( $Types == "1" )
	{
		//��¼����
		$Res = $Conn->Execute( " select count(*) as count from $TableList[adv] where website = '$website' and flag = 1 group by urls" );
		$Count = $Res->FetchRow();
		$DataCount = $Count[count];

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->Execute( " select *  from $TableList[adv] where website = '$website' and flag = 1  ORDER BY `advid` DESC ",$PageSize , $PageItems[Offset]  );

		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[urls1] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
			$Res_adv = $Conn->Execute( " select count(id) as counts from $TableList[ip] where website = '$website' and pageurl = '$Tmp[urls1]'");
			$Tmp_adv = @$Res_adv->FetchRow();
			$Tmp[counts_adv] = $Tmp_adv[counts]; 		

			$Res_common = $Conn->Execute( " select count(id) as counts from $TableList[ip] where website = '$website' and pageurl = '$Tmp[urls]'");
			$Tmp_common = @$Res_common->FetchRow();		
			$Tmp[counts_common] = $Tmp_common[counts]; 

			$Tmp[urls2] = $Tmp[link]."phpstatfrom=".$Tmp[code];
			$Tmp[urls3] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
			$Datas[] = $Tmp;
		}
	}

	if( $Types == "2" or $Types == "0" )
	{
		//��¼����
		$Res = $Conn->Execute( " select count(*) as count from $TableList[adv] where website = '$website' and flag = 1 group by urls" );
		$Count = $Res->FetchRow();
		$DataCount = $Count[count];

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}
		if($PageItems[Offset] == "")$PageItems[Offset] = 0;
		$Res = $Conn->Execute( " select *  from $TableList[adv] where website = '$website' and flag = 1  ORDER BY `advid` DESC ",$PageSize , $PageItems[Offset]  );

		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[urls1] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
			$Res_adv = $Conn->Execute( " select sum(counts) as counts from $TableList[page] where types = $Types and website = '$website' and page = '$Tmp[urls1]'");
			$Tmp_adv = @$Res_adv->FetchRow();
			$Tmp[counts_adv] = $Tmp_adv[counts]; 		

			$Res_common = $Conn->Execute( " select sum(counts) as counts from $TableList[page] where types = $Types and website = '$website' and page = '$Tmp[urls]'");
			$Tmp_common = @$Res_common->FetchRow();		
			$Tmp[counts_common] = $Tmp_common[counts]; 

			$Tmp[urls2] = $Tmp[link]."phpstatfrom=".$Tmp[code];
			$Tmp[urls3] = $Tmp[urls].$Tmp[link]."phpstatfrom=".$Tmp[code];
			$Datas[] = $Tmp;
		}
	}

	$Tpl->assign( 'Datas', $Datas );
	
	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'Main', $Tpl->fetch( 'advertisement.html' ) . $scriptCode );	
	$Tpl->assign( 'Title', '���ͳ�� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '���ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"advertisement.php?website=$website&type=1\">����ͳ��</a> <a href=\"advertisement.php?website=$website&type=2\">����ͳ��</a> <a href=\"advertisement.php?website=$website&type=0\">����ͳ��</a>  | <a href=\"manage_advertisement.php?website=$website\">������" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>