<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';

	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval','website'=>'strval' ) );
	$website = $_GET[website];
	include_once 'initmenu.php';
	
	
	if( $Types == "1" ) 
	{
		$Res = $Conn->Execute( " select count(id) as counts ,screensize from $TableList[ip_limit] where website = '$website' group by screensize ORDER BY counts desc ");
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[screen] = $Tmp[screensize];
			$ScreenSize[] = $Tmp;
		}
		unset($Res);unset($Tmp);
		$Res = $Conn->Execute( " select count(id) as counts ,color from $TableList[ip_limit] where website = '$website' group by color ORDER BY counts desc ");
		
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[color] = $Tmp[color]."λ";
			$Color[] = $Tmp;
		}
	}

	if( $Types == "2" or $Types == "0" ) 
	{	
		unset($Datas);
		if( $Types == "2" )
		{	
			$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
			$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
			$Where .= " and times >= $StartTime and times < $EndTime ";
		}
		//��ȡ��Ļ��С
		$Res = $Conn->Execute( " select sum(counts) as counts ,screen from $TableList[screen] where types = 3 and website = '$website' $Where Group by screen ORDER BY `counts` DESC " );
		while( $Tmp = @$Res->FetchRow() )
		{
			$ScreenSize[] = $Tmp;
		}
		
		

		//��ȡ��Ļ��ɫ
		$Res = $Conn->Execute( " select sum(counts) as counts ,color from $TableList[color] where types = 3 and website = '$website' $Where Group by color ORDER BY `counts` DESC " );
		while( $Tmp = @$Res->FetchRow() )
		{	
			$Tmp[color] = $Tmp[color]."λ";
			$Color[] = $Tmp;
		}
	}

	if( count( $ScreenSize ) > 0 )
	{
		foreach( $ScreenSize as $Key=>$Val )
		{
			$ScreenSizeCountAll += $Val[counts];
		}
		foreach( $ScreenSize as $Key=>$Val )
		{
			$ScreenSize[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$ScreenSizeCountAll ) * 100 );
			$SqlDatas[] = array('screen'=>$ScreenSize[$Key][screen],'ipcounts'=>$Val[counts],'precent'=>$ScreenSize[$Key][percent]);
		}
	}
	$Tpl->assign( 'ScreenSize', $ScreenSize );

	if( count( $Color ) > 0 )
	{
		foreach( $Color as $Key=>$Val )
		{
			$ColorCountAll += $Val[counts];
		}
		foreach( $Color as $Key=>$Val )
		{
			$Color[$Key][percent] = sprintf("%01.2f", ( $Val[counts]/$ColorCountAll ) * 100 );
			$SqlDatas[] = array('color'=>$Color[$Key][color],'ipcounts'=>$Val[counts],'precent'=>$Color[$Key][percent]);
		}
	}
	$Tpl->assign( 'Color', $Color );

	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('��ʾ��','���ʴ���(IP)','�ٷֱ�')) ));	
	$Tpl->assign( 'fname', 'country' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'Main', $Tpl->fetch( 'screen.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '��Ļͳ�� - '.$SoftWareName .$SoftWareVersion  );
	$Tpl->assign( 'NowView', '��Ļͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">����ͳ��</a> <a href=\"?website=$website&type=2\">����ͳ��</a> <a href=\"?website=$website&type=0\">����ͳ��</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>