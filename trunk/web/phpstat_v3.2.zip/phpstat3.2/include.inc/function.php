<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
	describe:���ܺ���
*/	


	function _out ( $Content, $type = 'html', $exit = true, $Ret = false )
	{
		global $TPL_IMGURL;
		
		$type = strtolower ( $type );
		$type = $type == 'js' ? 'js' : 'html';

		$Content = str_replace ( TPL_IMGDIR, $TPL_IMGURL, $Content );

		if ( $type == 'js' )
		{
			$Content = preg_replace ( "/\/\/(.+)/", '', $Content );
			$Content = str_replace ( "\n", '', $Content );
			$Content = str_replace ( "\r", '', $Content );
			$Content = str_replace ( '\'', '\\\'', $Content );
			$Content = "document.write ( '" . $Content . "' )";
		}

		//$conn->close ();

		if( $Ret )
		{
			return $Content;
		}
		else
		{
			echo $Content;
		}

		if( $exit == true )
		{
			ob_end_flush();
			exit;
		}
	}

	function Initialize( &$VarArray, $VarNames )
	{
		if( is_array( $VarArray ) && count( $VarArray ) > 0 )
		{
			foreach( $VarArray as $Key=>$VarValue )
			{
				if( isset( $VarNames[$Key] ) )
				{
					$VarArray[$Key] = $VarNames[$Key] ( $VarValue );
				}
				else
				{
					unset( $VarArray[$Key] );
				}
			}
		}
	}

	function _d( $content )
	{
		echo "<pre>";
		print_r( $content );
		echo "</pre>";
	}

	function echojs( $Content )
	{
		echo 'document.write( "' . addslashes( $Content ) . "\" );\n";
	}



	//UTF8 to GB2312
	function utf82gb2312( $SourceText )
	{
				$Out = "";
				$Len = strlen($SourceText);
				$i = 0;
				while($i < $Len) {
					$c = ord( substr( $SourceText, $i++, 1 ) );
					switch($c >> 4)
					{ 
						case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
							$Out .= substr( $SourceText, $i-1, 1 );
						break;
						case 12: case 13:
							$Char2 = ord( substr( $SourceText, $i++, 1 ) );
							$Key = (($c & 0x0F) << 12) | (($Char2 & 0x3F) << 6) | (($Char3 & 0x3F) << 0);
							$Char3 = GetGb2312('0x'.dechex($Key));
							$Out .= _hex2bin( dechex(  $Char3 + 0x8080 ) );

						break;
						case 14:
							$Char2 = ord( substr( $SourceText, $i++, 1 ) );
							$Char3 = ord( substr( $SourceText, $i++, 1 ) );
							$Key = (($c & 0x0F) << 12) | (($Char2 & 0x3F) << 6) | (($Char3 & 0x3F) << 0);
							$Char4 = GetGb2312('0x'.dechex($Key));
							$Out .= _hex2bin( dechex ( $Char4 + 0x8080 ) );
						break;
					}
				}
				return $Out;
	}
	function GetGb2312($Key)
	{	
		global $Conn,$TableList;
		if( $Key == '' )
		{
			return '';
		}
		$Res = $Conn->Execute( " select gb from $TableList[unicode2gb] where unicode = '$Key'" );
		$Ret = $Res->FetchRow();
		return $Ret[gb];
	}
	function _hex2bin( $hexdata )
	{
		for ( $i=0; $i<strlen($hexdata); $i+=2 )
			$bindata.=chr(hexdec(substr($hexdata,$i,2)));

		return $bindata;
	}


	function _RmDir($dirName)
	{
		$result = false;
		if(!is_dir($dirName))
		{
			return false;
		}

		$handle = opendir($dirName);
		while(($file = readdir($handle)) !== false)
		{
			if($file != '.' && $file != '..')
			{
				$dir = $dirName . DIRECTORY_SEPARATOR . $file;
				is_dir($dir) ? _RmDir($dir) : unlink($dir);
			}
		}
		closedir($handle);

		$result = rmdir($dirName) ? true : false;

		return $result;
	}

	##################��ʽ���ռ�����##################
	function format_size ( $in )
	{
		if ( $in >= 1024 * 1024 * 1024 )
		{
			$out = sprintf ( "%01.2f", $in / ( 1024 * 1024 * 1024 ) ) . " GB";
		}
		elseif ( $in >= 1024 * 1024 )
		{
			$out = sprintf ( "%01.2f", $in / ( 1024 * 1024 ) ) . " MB";
		}
		elseif ( $in >= 1024 )
		{
			$out = sprintf ( "%01.2f", $in / 1024 ) . " KB";
		}
		else
		{
			$out = $in . " Bytes";
		}
		return ( $out );
	}

	##################д���ļ�###################
	function write_to_file ($filename, $data, $method = "w")
	{
		$fp = @fopen($filename, $method);
		if(!$fp)
		{
			return 0;
		}
		flock($fp, LOCK_EX);
		$opt = @fwrite($fp, $data);
		fclose($fp);
		return $opt;
	}

	##################��ȡ�ļ�###################
	function read_from_file ( $file )
	{
		if ( ! file_exists ( $file ) )
		{			
			return ( FALSE );
		}

		$fp = fopen ( $file, "r" );
		if ( ! $fp )
		{			
			return ( FALSE );
		}

		flock ( $fp, LOCK_SH );
		$data = fread ( $fp, filesize ( $file ) );
		fclose ( $fp );
		return ( $data );
	}
	##################ϵͳ��Ϣ��ʾ###################
	function showMsg ( $msg , $action )
	{
		global $Tpl;
		$Tpl->assign( 'msg', $msg );
		$Tpl->assign( 'goback', $action );
		$Tpl->assign( 'Title', 'ϵͳ��Ϣ��ʾ - '.$SoftWareName .$SoftWareVersion  );
		$Tpl->assign( 'NowView', 'ϵͳ��Ϣ��ʾ' );
		$Tpl->assign( 'Main', $Tpl->fetch( 'msg.html' ). $ScriptCode);
		_out($Tpl->fetch( 'main.html' ));
	}
?>