<?
	function getHost($ip)
	{
		return trim(strtolower(@getHostbyaddr($ip)));
	}


	function getIp() 
	{
		if(isset($_SERVER['HTTP_CLIENT_IP']) 
			&& ($ip = getFirstIpFromList($_SERVER['HTTP_CLIENT_IP']))
			&& strpos($ip, "unknown")===false 
			&& getHost($ip) != $ip)
		{
			return $ip;
		}
		elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
			&& $ip = getFirstIpFromList($_SERVER['HTTP_X_FORWARDED_FOR'])
			&& isset($ip) && !empty($ip)
			&& strpos($ip, "unknown")===false 
			&& getHost($ip) != $ip)
		{
			return $ip;
		}
		elseif( isset($_SERVER['HTTP_CLIENT_IP'])
			&& strlen( getFirstIpFromList($_SERVER['HTTP_CLIENT_IP']) ) != 0 )
		{
			return getFirstIpFromList($_SERVER['HTTP_CLIENT_IP']);
		}
		else if( isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
			&& strlen (getFirstIpFromList($_SERVER['HTTP_X_FORWARDED_FOR'])) != 0)
		{
			return getFirstIpFromList($_SERVER['HTTP_X_FORWARDED_FOR']);
		}
		else
		{
			return getFirstIpFromList($_SERVER['REMOTE_ADDR']);
		}
	}

	function getFirstIpFromList($ip)
	{
		$p = strpos($ip, ',');
		if($p!==false)
		{
			return (substr($ip, 0, $p));
		}
		else
		{
			return ($ip);
		}
	}

	$SERVERHOST = $_SERVER[SERVER_NAME] == '' ? $_SERVER[SERVER_ADDR] : $_SERVER[SERVER_NAME];

	$DRes = $Conn->Execute( " select min(times) as times from $TableList[day_data]" );
	$DRet = $DRes->FetchRow();

?>