<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
	describe:ͳ�Ƹſ�
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	$website = strval($_GET[website]);
	$Tpl->assign( 'UserId', $UserId );
	include_once 'initmenu.php';
	$Res = $Conn->Execute( " select * from $TableList[site]  where website = '$website'" );
	$SiteInfo = $Res->FetchRow();
	$Tpl->assign( 'SiteInfo', $SiteInfo );
	
	//���������
	$Times = date("Y");
	$Res = $Conn->Execute( " select * from $TableList[year_data] where year = $Times and website = '$website'" );
	$YearInfo = $Res->FetchRow();
	$Tpl->assign( 'YearInfo', $YearInfo );

	//���������С����
	$Res = $Conn->Execute( "SELECT max( day_count ) as maxcount , max( day_count_ip ) as maxcountip , min( day_count ) as mincount, min( day_count_ip ) as mincountip FROM $TableList[day_data] where website = '$website'" );
	$MaxMin = $Res->FetchRow();
	$Tpl->assign( 'MaxMin', $MaxMin );

	//ͳ�ƿ�ʼ��ͳ������
	$Res = $Conn->Execute( " select times  from $TableList[day_data] where website = '$website' order by times asc" );
	$FirstDay = $Res->FetchRow();
	$FirstDay[times] = intval( $FirstDay[times] ) == 0 ? time() - 1 : 
	$FirstDay[times];
	$Tpl->assign( 'FirstDay', date("Y-m-d",$FirstDay[times]) );
	$Tpl->assign( 'CountDays', ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 ) );

	//ƽ���շ�����
	$Tpl->assign( 'AverageDayIp', ceil($SiteInfo[all_count_ip]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 )) );
	$Tpl->assign( 'AverageDay', ceil($SiteInfo[all_count]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 )) );

	//ƽ���ܷ�����
	$Tpl->assign( 'AverageWeekIp', ceil($SiteInfo[all_count_ip]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 / 7 )) );
	$Tpl->assign( 'AverageWeek', ceil($SiteInfo[all_count]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 / 7  )) );

	//ƽ���·�����
	$Tpl->assign( 'AverageMonthIp', ceil($SiteInfo[all_count_ip]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 / 30 )) );
	$Tpl->assign( 'AverageMonth', ceil($SiteInfo[all_count]/ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 / 30  )) );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),date("d")-1,date("Y") );
	$Res = $Conn->Execute( " select day_count, day_count_ip  from $TableList[day_data] where times = $Times and website = '$website'" );
	$YesterdayInfo = $Res->FetchRow();
	$Tpl->assign( 'YesterdayInfo', $YesterdayInfo );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),date("d"),date("Y") );
	$Res = $Conn->Execute( " select day_count, day_count_ip  from $TableList[day_data] where times = $Times and website = '$website'" );
	$TodayInfo = $Res->FetchRow();
	$Tpl->assign( 'TodayInfo', $TodayInfo );
	
	//���ܷ�����
	$Times = mktime (0,0,0,date("m"),date("d"),date("Y") );
	if(date("w") == 0) $Current = 7;
	else $Current = date("w");		
	$WeekStart = --$Current ;
	$StartTime = $Times - 24 * 60 * 60 * $WeekStart;
	$EndTime = $Times;
	$Res = $Conn->Execute( " select sum(day_count) as day_count, sum(day_count_ip) as day_count_ip from $TableList[day_data] where times >= $StartTime and times <= $EndTime and website = '$website'" );
	$WeekInfo = $Res->FetchRow();
	$Tpl->assign( 'WeekInfo', $WeekInfo );

	//���ܷ�����
	$Times = mktime (0,0,0,date("m"),date("d"),date("Y") );
	if(date("w") == 0) $Current = 7;
	else $Current = date("w");		
	$WeekStart = $Current + 6 ;
	$StartTime = $Times - 24 * 60 * 60 * $WeekStart;
	$EndTime = $Times - 24 * 60 * 60 * $Current;
	$Res = $Conn->Execute( " select sum(day_count) as day_count, sum(day_count_ip) as day_count_ip from $TableList[day_data] where times >= $StartTime and times <= $EndTime and website = '$website'" );
	$PreWeekInfo = $Res->FetchRow();
	$Tpl->assign( 'PreWeekInfo', $PreWeekInfo );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),1,date("Y") );
	$Res = $Conn->Execute( " select * from $TableList[month_data] where times = $Times and website = '$website'" );
	$MonthInfo = $Res->FetchRow();
	$Tpl->assign( 'MonthInfo', $MonthInfo );

	//����ͳ��
	$Times = mktime (0,0,0,date("m")-1,1,date("Y") );
	$Res = $Conn->Execute( " select * from $TableList[month_data] where times = $Times and website = '$website'" );
	$PreMonthInfo = $Res->FetchRow();
	$Tpl->assign( 'PreMonthInfo', $PreMonthInfo );

	//����ͳ��ͼ
	$WeekList[1] = "��һ";
	$WeekList[2] = "�ܶ�";
	$WeekList[3] = "����";
	$WeekList[4] = "����";
	$WeekList[5] = "����";
	$WeekList[6] = "<B>����</B>";
	$WeekList[0] = "<B>����</B>";
	
	//ͳ����������
	$OnlineTime = 20;
	$Time = time() - $OnlineTime * 60;
	$Res = $Conn->Execute( "SELECT * FROM $TableList[ip] WHERE time >= $Time GROUP BY ip" );
	$OnlineCount = intval( $Res->RecordCount() );
	

	

	//���18�����ͳ��ͼ
	unset($DTmp);
	unset($Datas);
	$StartTimes = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 18 * 24* 3600;
	$EndTimes = mktime (0,0,0,date("m"),date("d"),date("Y") );
	//echo date("Y-m-d",$Times);
	$Res = $Conn->Execute( " select sum(day_count) as day_count,sum(day_count_ip) as day_count_ip,times from $TableList[day_data] where times >= $StartTimes and times <= $EndTimes and  website = '$website' group by times order by times asc limit 18" );
	//$Row = $Res->FetchRow();
	while( $Row = $Res->FetchRow() )
	{	
		$d = date("d",$Row[times]);
		$m = date("m",$Row[times]);
		$y = date("Y",$Row[times]);
		$w = date("w",$Row[times]);
		$timestm = $Row[times];
		$Row[times] = date("Y-m-d",$Row[times]);
		$CountIp = $Row["day_count_ip"] + rand(NUM1,NUM2);
		$Count = $Row["day_count"] + rand(NUM1,NUM2);
		
		unset( $ReturnRow );
		
		$ReturnRes = $Conn->Execute( " select sum(counts) as day_count_return_ip from $TableList[returner] where times = $timestm and website = '$website' and types = 3" );
		$ReturnRow = $ReturnRes->FetchRow();
		$CountReturnIp = $ReturnRow["day_count_return_ip"] == "" ? 0 : $ReturnRow["day_count_return_ip"];

		$SqlDatas[] = array('datetime'=>$Row[times],'IP'=>$CountIp,'PV'=>$Count);

		if($w ==0 or $w == 6 ) 
		{
			$m_d = $m .". <B>". $d."</B>";
			$Row[day_count_ip] = "<B>$CountIp IP</B>";
			$Row[day_count] = "<B>$Count PV</B>";
			$Row[day_count_return_ip] = "<B>$CountReturnIp IP</B>";
			$Row[day_count_page_pre_ip] = "<B>".sprintf("%01.2f",$Count/$CountIp)." ��</B>";
		}
		else
		{	
			$m_d = $m .". ". $d."";
			$Row[day_count_ip] = "$CountIp IP";
			$Row[day_count] = "$Count PV";
			$Row[day_count_return_ip] = "$CountReturnIp IP";
			$Row[day_count_page_pre_ip] = sprintf("%01.2f",$Count/$CountIp)." ��";
		}
		$d = date("d",$timestm+86400);
		$m = date("m",$timestm+86400);
		$y = date("Y",$timestm+86400);

		$Row[old_link] = "show_old.php?website=$website&Date_Month=$m&Date_Day=$d&Date_Year=$y";
		$Tmp[] = $m_d.','.$CountIp.','.$Count;
		$Row[week] = $WeekList[$w];		
		$Datas[] = $Row;
		
	}
	for( $i = count($Tmp); $i < 18; $i++ )
	{	
		$timestm = $timestm+24*3600;
		$d = date("d",$timestm);
		$m = date("m",$timestm);
		$Tmp[] = $m.' . '.$d.',0,0';
	}
	$Data = implode( ';', $Tmp);
	$Tpl->assign( 'WIDTH_NUM3', WIDTH_NUM3 );
	$Tpl->assign( 'WIDTH_NUM4', WIDTH_NUM4 );
	$Tpl->assign( 'Data', $Data );
	krsort( $Datas );	
	$Tpl->assign( 'Datas', $Datas );
	    
	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('����','Ψһ�ÿ�IP','����')) ));
	$Tpl->assign( 'fname', 'main' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );
	$Tpl->assign( 'website', $website );
	

	$Tpl->assign( 'OnlineTime', $OnlineTime );
	$Tpl->assign( 'OnlineCount', $OnlineCount );
	$Tpl->assign( 'Main', $Tpl->fetch( 'main_info.html' ) );

	$Tpl->assign( 'Title', '�ſ� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '�ſ�' );
	$Tpl->assign( 'QuickLink', "<a href=\"stat_day.php?website=$website\">ÿ��ͳ��</a> <a href=\"stat_month.php?website=$website\">ÿ��ͳ��</a> <a href=\"stat_year.php?website=$website\">ÿ��ͳ��</a> <a href=\"stat_alexa.php?website=$website\">Alexa������</a>" );
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>