<?
/*
 
 ��������Ȩ����������,��Ͷ��ʹ��֮ǰע���ȡ����
 ���ߣ�������wiwiboy��
 ��Ŀ��PHPStat����ͳ�� 3.2
 �绰��13553166317
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
 ��ַ��http://www.phpstat.net
 phpstat.net����ȫ��Ȩ��������ط��ɺ͹���		  		
		��Լ����������Ƿ��޸ġ�ת�ء�ɢ��������������Ӯ����Ϊ��		
		������ɾ����Ȩ������
*/
/*	
	verson:v3.2 20060618
	author:wiwiboy
	last update:2006/06/10	
*/
	session_start();
	include_once './include.inc/config.inc.php';	
	include_once './include.inc/global.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval', 'engine'=>'strval' ,'website'=>'strval','keyword'=>'strval','keywordstat'=>'strval','Date_Day'=>'intval','Date_Month'=>'intval','Date_Year'=>'intval') );
	$website = $_GET[website];
	include_once 'initmenu.php';

	
	##############################################################################
	if(!$_GET[keyword] and !$_GET[keywordstat])
	{	
		if( $Types == "1" ) 
		{	
			$Engines = array(
			'baidu.com',
			'google.com',
			'search.sohu.com',
			'search.sina.com.cn',
			'so.163.com',
			'www.yahoo.com',
			'search.lycos.com',
			'seek.3721.com',
			'search.qq.com',
			'search.tom.com',
			'sogou.com',
			'search.21cn.com',
			'search.aol.com'
			);
		$Where = ' and pagefromsite REGEXP "' . implode( '|', $Engines ) .'" ';	

		$Res = $Conn->Execute( "select count(id) as counts,pagefromsite from $TableList[ip] where website = '$website' $Where group by pagefromsite ORDER BY counts desc ");	
		while( $Tmp = @$Res->FetchRow() )
		{				
			$ResR = $Conn->Execute( " select count(id) as counts ,keyword,pagefrom from $TableList[ip] where website = '$website' and pagefromsite = '$Tmp[pagefromsite]' group by keyword ORDER BY counts desc ");
			unset($Keyword);unset($CountAll);
			while( $TmpR = @$ResR->FetchRow() )
			{					
				$TmpR[lastpage]	= $TmpR[pagefrom];
				$TmpR[keyword2] = urlencode($TmpR[keyword]);
				$fromsite		= $Tmp[pagefromsite];
				$CountAll	   += $TmpR[counts];
				$AllCountAll   += $TmpR[counts];
				$Keyword[]		= $TmpR;
			}
				
			if( count($Keyword) > 0)
			{	//print_r($Datas);
				foreach( $Keyword as $Key=>$Val )
				{					
					$Keyword[$Key][Percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );				
					$Keyword[$Key][percent] = & $Keyword[$Key][Percent];	
					
				}
			}
			$Tmp[fromsite]	  = $fromsite;
			$Tmp[sub]		  = $Keyword;
			$Tmp[allcounts]	  = $CountAll;
			$Datas[] = $Tmp;
		}
		}
		if( $Types == "2" or $Types == "0" ) 
		{	
			unset($Datas);
			if( $Types == "2" )
			{	
				$StartTime = mktime (0,0,0,date("m"),date("d"),date("Y") ) - 24 * 3600;
				$EndTime = mktime (0,0,0,date("m"),date("d"),date("Y") );
				$Where = " and times >= $StartTime and times < $EndTime ";
			}
	
			$Res = $Conn->Execute( " select fromsite from $TableList[keyword] where types = 3 and fromsite != '' and website = '$website' $Where Group by fromsite");	

			while( $Tmp = @$Res->FetchRow() )
			{	
				$ResR = $Conn->Execute( " select sum(counts) as counts,keyword,times,fromsite,lastpage from $TableList[keyword] where types = 3 and website = '$website' and fromsite = '$Tmp[fromsite]' $Where Group by keyword ORDER BY `counts` DESC ");
				
				preg_match("/^(http:\/\/)?([^\/]+)/i",$Tmp[fromsite],$DomainMatches);
				$fromsite  = $DomainMatches[2];	
				unset($Keyword);unset($CountAll);
				while( $TmpR = @$ResR->FetchRow() )
				{				
					$TmpR[times]	= date("Y-m-d H:i:s",$TmpR[times]);
					$TmpR[keyword]	= $TmpR[keyword];
					$TmpR[keyword2] = urlencode($TmpR[keyword]);
					$TmpR[fromsite] = $fromsite;
					$CountAll	   += $TmpR[counts];
					$AllCountAll   += $TmpR[counts];
					$Keyword[]		= $TmpR;
				}
				
				if( count($Keyword) > 0)
				{	//print_r($Datas);
					foreach( $Keyword as $Key=>$Val )
					{					
						$Keyword[$Key][Percent] = sprintf("%01.2f", ( $Val[counts]/$CountAll ) * 100 );				
						$Keyword[$Key][percent] = & $Keyword[$Key][Percent];	
					
					}
				}
				$Tmp[sub]		  = $Keyword;
				$Tmp[allcounts]	  = $CountAll;
				$Datas[] = $Tmp;			
				//$SqlDatas[] = array('referer'=>$Tmp[referer],'pvcounts'=>$Tmp[counts]);
			}
		}
			//ͳ�ưٷֱ�
			/*if( count($Datas) > 0)
			{	//print_r($Datas);
				foreach( $Datas as $Key=>$Val )
				{	
					
					foreach( $Val[sub] as $Key2=>$Val2 )
					{	
					$Datas[$Key][sub][$Key2][Percent] = sprintf("%01.2f", ( $Val2[counts]/$AllCountAll ) * 100 );				
					$Datas[$Key][sub][$Key2][percent] = & $Datas[$Key][sub][$Key2][Percent];	
					}
				}
			}
			*/
	@krsort($Datas);
	}
	##############################################################################
	elseif($_GET[keyword])
	{
		$ResR = $Conn->Execute( " select sum(counts) as counts,keyword,times,fromsite,lastpage from $TableList[keyword] where types = 3 and website = '$website' and keyword = '$_GET[keyword]' Group by fromsite ORDER BY `counts` DESC ");
			
		
		while( $TmpR = @$ResR->FetchRow() )
		{	
			preg_match("/^(http:\/\/)?([^\/]+)/i",$TmpR[fromsite],$DomainMatches);
			$fromsite  = $DomainMatches[2];	
			unset($Keyword);unset($CountAll);
			$TmpR[times]	= date("Y-m-d H:i:s",$TmpR[times]);
			$TmpR[fromsite] = $fromsite;
			$TmpR[keyword]	= $TmpR[keyword];
			$TmpR[keyword2] = urlencode($TmpR[keyword]);	
			$CountAll	   += $TmpR[counts];
			$AllCountAll   += $TmpR[counts];
			$Keyword[]		= $TmpR;
			$Tmp[sub]		  = $Keyword;
			$Tmp[fromsite]	  = $fromsite;
			$Tmp[allcounts]	  = $CountAll;			
			$Datas[] = $Tmp;
		}	
		
		//$SqlDatas[] = array('referer'=>$Tmp[referer],'pvcounts'=>$Tmp[counts]);
		

		//ͳ�ưٷֱ�
		if( count($Datas) > 0)
		{
			foreach( $Datas as $Key=>$Val )
			{		
				//print_r($Val[sub][0]);
				$Datas[$Key][sub][0][Percent] = sprintf("%01.2f", ( $Val[sub][0][counts]/$AllCountAll ) * 100 );
				$Datas[$Key][sub][0][percent] = & $Datas[$Key][sub][0][Percent];
			}
		}
	@krsort($Datas);
	}
	##############################################################################
	elseif($_GET[keywordstat])
	{	
		$Year  = $_GET[Date_Year]  == 0?date( 'Y' ):$_GET[Date_Year];
		$Month = $_GET[Date_Month] == 0?date( 'm' ):$_GET[Date_Month];			
		$StartTime = mktime (0,0,0,$Month,1,$Year );
		$MonthDayCount = date( 't', $StartTime );
		$EndTime = mktime (0,0,0,$Month,$MonthDayCount,$Year );
		$Where = " and times >= $StartTime and times < $EndTime ";
		
		$Res = $Conn->Execute( " select sum(counts) as counts,times from $TableList[keyword] where types = 3 and website = '$website' and keyword = '$_GET[keywordstat]' $Where Group by times ORDER BY `counts` DESC ");

		while( $Tmp = $Res->FetchRow() )
		{				
			$TmpDay = intval( date( 'd', $Tmp[times] ) );
			$MTmp[$TmpDay] = $Tmp;		
			//$SqlDatas[] = array('days'=>date("Y-m-d",$Tmp[times]),'countIp'=>$Tmp[day_count_ip],'count'=>$Tmp[day_count]);
		}
		for( $i = 1; $i <= $MonthDayCount; $i++ )
		{	
			if( strlen( $i ) == 1 ) $j = '0'.$i;
			else $j = $i;

			$WeekNum = date( 'w', mktime (0,0,0,$Month,$i,$Year) );
			if( $WeekNum == 0 || $WeekNum == 6 )
			{
				$j = "<B>".$j."</B>";
			}
			else
			{
				$j = $j;
			}


			if(count($MTmp[$i]) == 0) 
			{					
				$DTmp[] = $j.',0,0';
			}
			else
			{
				//$CountIp = $MTmp[$i][day_count_ip] + rand(NUM1,NUM2);
				$Count   = $MTmp[$i][counts] + rand(NUM1,NUM2);					
				$DTmp[]	  = $j.','.$Count.','.$Count;
			}
		}
		$Datas = implode( ';', $DTmp);

		#######################################################
		$Res = $Conn->Execute( " select counts,times from $TableList[keyword] where types = 3 and website = '$website' and keyword = '$_GET[keywordstat]' and  fromsite REGEXP 'google' $Where ORDER BY `counts` DESC ");
		UNSET($DTmp);UNSET($MTmp);
		while( $Tmp = $Res->FetchRow() )
		{				
			$TmpDay = intval( date( 'd', $Tmp[times] ) );
			$MTmp[$TmpDay] = $Tmp;		
			//$SqlDatas[] = array('days'=>date("Y-m-d",$Tmp[times]),'countIp'=>$Tmp[day_count_ip],'count'=>$Tmp[day_count]);
		}
		for( $i = 1; $i <= $MonthDayCount; $i++ )
		{	
			if( strlen( $i ) == 1 ) $j = '0'.$i;
			else $j = $i;

			$WeekNum = date( 'w', mktime (0,0,0,$Month,$i,$Year) );
			if( $WeekNum == 0 || $WeekNum == 6 )
			{
				$j = "<B>".$j."</B>";
			}
			else
			{
				$j = $j;
			}


			if(count($MTmp[$i]) == 0) 
			{					
				$DTmp[] = $j.',0,0';
			}
			else
			{
				//$CountIp = $MTmp[$i][day_count_ip] + rand(NUM1,NUM2);
				$Count   = $MTmp[$i][counts] + rand(NUM1,NUM2);					
				$DTmp[]	  = $j.','.$Count.','.$Count;
			}
		}
		$GOOGLEDatas = implode( ';', $DTmp);
		$Tpl->assign( 'GOOGLEDatas', $GOOGLEDatas );

		######################################################

		$Res = $Conn->Execute( " select counts,times from $TableList[keyword] where types = 3 and website = '$website' and keyword = '$_GET[keywordstat]' and  fromsite REGEXP 'baidu.com' $Where ORDER BY `counts` DESC ");
		UNSET($DTmp);UNSET($MTmp);
		while( $Tmp = $Res->FetchRow() )
		{				
			$TmpDay = intval( date( 'd', $Tmp[times] ) );
			$MTmp[$TmpDay] = $Tmp;		
			//$SqlDatas[] = array('days'=>date("Y-m-d",$Tmp[times]),'countIp'=>$Tmp[day_count_ip],'count'=>$Tmp[day_count]);
		}
		for( $i = 1; $i <= $MonthDayCount; $i++ )
		{	
			if( strlen( $i ) == 1 ) $j = '0'.$i;
			else $j = $i;

			$WeekNum = date( 'w', mktime (0,0,0,$Month,$i,$Year) );
			if( $WeekNum == 0 || $WeekNum == 6 )
			{
				$j = "<B>".$j."</B>";
			}
			else
			{
				$j = $j;
			}


			if(count($MTmp[$i]) == 0) 
			{					
				$DTmp[] = $j.',0,0';
			}
			else
			{
				//$CountIp = $MTmp[$i][day_count_ip] + rand(NUM1,NUM2);
				$Count   = $MTmp[$i][counts] + rand(NUM1,NUM2);					
				$DTmp[]	  = $j.','.$Count.','.$Count;
			}
		}
		$BAIDUDatas = implode( ';', $DTmp);
		$Tpl->assign( 'BAIDUDatas', $BAIDUDatas );
		############################################################
		$Tpl->assign( 'Year', $Year );
		$Tpl->assign( 'Month', $Month );
		$Tpl->assign( 'DataTime', $StartTime );
		$Tpl->assign( 'keywordstatshow', 'true' );
		$Tpl->assign( 'keywordstat', $_GET[keywordstat]);	
		
	}
	
	
	$Tpl->assign( 'Datas', $Datas );

	$Tpl->assign( 'SqlDatas', urlencode(serialize ($SqlDatas) ));
	$Tpl->assign( 'SqlDatasTitle', urlencode(serialize (array('��Դ','����(PV)')) ));
	if($DataCount > $PageSize)
	$Tpl->assign( 'Sql', urlencode(" select referer,counts from $TableList[referer] where types = $Types $Where and website = '$website' ORDER BY `counts` DESC ") );
	$Tpl->assign( 'fname', 'referer' );
	$Tpl->assign( 'textexport', 'true' );
	$Tpl->assign( 'xmlexport', 'true' );
	$Tpl->assign( 'cvsexport', 'true' );

	$Tpl->assign( 'website', $website );
	$Tpl->assign( 'Main', $Tpl->fetch( 'keyword_kinds.html' ) . $ScriptCode );
	
	$Tpl->assign( 'Title', '����&�ؼ���ͳ�� - '.$SoftWareName .$SoftWareVersion );
	$Tpl->assign( 'NowView', '����&�ؼ���ͳ��' );
	$Tpl->assign( 'QuickLink', "<a href=\"?website=$website&type=1\">��������</a> <a href=\"?website=$website&type=2\">��������</a> <a href=\"?website=$website&type=0\">��������</a>" );
	
	$Tpl->assign( 'CopyRight', $PHPStatBottomRight );
	_out( $Tpl->fetch( 'main.html' )  );
?>