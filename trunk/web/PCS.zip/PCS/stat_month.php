<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	global $website;
	Initialize( $_GET, array( 'Date_Year'=>'intval', 'Date_Month'=>'intval' ) );
	include_once 'initmenu.php';
	if( isset( $_GET[Date_Year] ) )
	{
		$MonthTime = mktime (0,0,0, isset( $_GET[Date_Month] ) ? intval( $_GET[Date_Month] ) : date('n'),1, isset( $_GET[Date_Year] ) ? intval( $_GET[Date_Year] ) : date('Y') );
	}
	else
	{
		$MonthTime = mktime (0,0,0,date("m"),1,date("Y"));

	}
	$Year = date( 'Y', $MonthTime );
	$Month = date( 'm', $MonthTime );

	//��ȡ����ͳ����Ϣ

	$EndTime = mktime (0,0,0,$Month+1,0,$Year );
	$Res = mysql_query( " select day_count, day_count_ip, times  from $TableList[day_data] where times <= $EndTime and times >= $MonthTime and website = '$website'" );
	while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
	{
		$TmpDay = intval( date( 'd', $Tmp[times] ) );
		$StatIp[$TmpDay] = intval( $Tmp[day_count_ip] );
		$Stat[$TmpDay] = intval( $Tmp[day_count] );

		$CountIpAll += $StatIp[$TmpDay];
		$CountAll += $Stat[$TmpDay];
		$MaxCount = $Stat[$TmpDay] > $MaxCount ? $Stat[$TmpDay] : $MaxCount;
	}

	$CountIpAll = $CountIpAll > 0 ? $CountIpAll : 0;
	$CountAll = $CountAll > 0 ? $CountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$DayLineCount = intval( $MaxCount / 5 );

	// 
	$MonthDayCount = date( 't', $MonthTime );
	for( $i = 1; $i <= $MonthDayCount; $i++ )
	{

		$DayIpPercent = $CountIpAll == 0 ? 0 : sprintf("%01.2f", ( $StatIp[$i]/$CountIpAll ) * 100 );
		$DayIpPillarHeight = $Quotiety * $StatIp[$i];
		$DayIpPillarHeight = $DayIpPillarHeight < 1 ? 1 : $DayIpPillarHeight;

		$DayPercent = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Stat[$i]/$CountAll ) * 100 );
		$DayPillarHeight = ( $Quotiety * $Stat[$i] ) - $DayIpPillarHeight;
		$DayPillarHeight = $DayPillarHeight < 1 ? 1 : $DayPillarHeight;


		$DayData[$i] = array(
									'DayIpPercent' => $DayIpPercent,
									'DayIpPillarHeight' => $DayIpPillarHeight,
									'DayPercent' => $DayPercent,
									'DayPillarHeight' => $DayPillarHeight,
									'DayIpCount' => intval( $StatIp[$i] ),
									'DayCount' => intval( $Stat[$i] ),
								);

		$WeekNum = date( 'w', mktime (0,0,0,date("m"),$i,date("Y")) );
		if( $WeekNum == 0 || $WeekNum == 6 )
		{
			$MonthDay[$i] = 1;
		}
		else
		{
			$MonthDay[$i] = 0;
		}
	}

	
	$Tpl->assign( 'PillarTdWidth', PILLAR_WIDTH/count($MonthDay)  );
	$Tpl->assign( 'PillarWidth', ( PILLAR_WIDTH/count($MonthDay) ) - 4  );
	$Tpl->assign( 'MonthDay', $MonthDay );
	$Tpl->assign( 'DayData', $DayData );
	$Tpl->assign( 'DayLineCount', $DayLineCount );

	$Tpl->assign( 'CountIpAll', $CountIpAll );
	$Tpl->assign( 'CountAll', $CountAll );
	//����ͳ����Ϣ��������


	//ͳ�������·�

	$Res = mysql_query( " select * from $TableList[users]  where website = '$website'" );
	$Row = mysql_fetch_array( $Res, MYSQL_ASSOC );

	$MaxCount = 0;
	$MonthDayCount = 31;
	for( $i = 1; $i <= $MonthDayCount; $i++ )
	{
		$StatIp[$i] = intval( $Row["dayip$i"] );
		$Stat[$i] = intval( $Row["day$i"] );

		$AllCountIpAll += $StatIp[$i];
		$AllCountAll += $Stat[$i];
		$MaxCount = $Stat[$i] > $MaxCount ? $Stat[$i] : $MaxCount;
	}

	$AllCountIpAll = $AllCountIpAll > 0 ? $AllCountIpAll : 0;
	$AllCountAll = $AllCountAll > 0 ? $AllCountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$AllDayLineCount = intval( $MaxCount / 5 );

	// 
	
	for( $i = 1; $i <= $MonthDayCount; $i++ )
	{

		$DayIpPercent = $AllCountAll == 0 ? 0 : sprintf("%01.2f", ( $StatIp[$i]/$AllCountAll ) * 100 );
		$DayIpPillarHeight = $Quotiety * $StatIp[$i];
		$DayIpPillarHeight = $DayIpPillarHeight < 1 ? 1 : $DayIpPillarHeight;

		$DayPercent = $AllCountIpAll == 0 ? 0 : sprintf("%01.2f", ( $Stat[$i]/$AllCountIpAll ) * 100 );
		$DayPillarHeight = ( $Quotiety * $Stat[$i] ) - $DayIpPillarHeight;
		$DayPillarHeight = $DayPillarHeight < 1 ? 1 : $DayPillarHeight;


		$AllDayData[$i] = array(
									'DayIpPercent' => $DayIpPercent,
									'DayIpPillarHeight' => $DayIpPillarHeight,
									'DayPercent' => $DayPercent,
									'DayPillarHeight' => $DayPillarHeight,
									'DayIpCount' => intval( $StatIp[$i] ),
									'DayCount' => intval( $Stat[$i] ),
								);
		$AllMonthDay[$i] = $i;

	}

	
	$Tpl->assign( 'AllMonthDay', $AllMonthDay );
	$Tpl->assign( 'AllDayData', $AllDayData );
	$Tpl->assign( 'AllDayLineCount', $AllDayLineCount );

	$Tpl->assign( 'AllCountIpAll', $AllCountIpAll );
	$Tpl->assign( 'AllCountAll', $AllCountAll );
	//ͳ�������·ݽ���

	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'DataTime', $MonthTime );	

	$Tpl->assign( 'Main', $Tpl->fetch( 'stat_month.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '�նη��� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', '�նη���' );
	$Tpl->assign( 'QuickLink', '<a href="stat_day.php">ʱ�η���</a> <a href="stat_month.php">�նη���</a> <a href="stat_year.php">�·��� </a>' );
	_out( $Tpl->fetch( 'main.html' )  );

?> 
