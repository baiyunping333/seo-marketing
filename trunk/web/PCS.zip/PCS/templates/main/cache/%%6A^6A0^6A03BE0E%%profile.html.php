<?php /* Smarty version 2.6.6, created on 2006-01-12 15:01:00
         compiled from profile.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'profile.html', 145, false),)), $this); ?>

<script language="javascript1.2">

function checkform( Obj )
{
	if( Obj.oldpassword.value == '' )
	{
		alert('�޸����ϱ�����������!');
		Obj.oldpassword.focus();
		return false
	}
	if( Obj.password.value != Obj.repassword.value )
	{
		alert('�޸����룬���������������һ��!');
		Obj.password.focus();
		return false
	}
}

</script>
<body bgcolor="#6699CC">

  
<table width="600" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr class=line_title>
    <td><strong>�����˻���Ϣ</strong></td>
  </tr>
  <tr> 
    <td><form name="form1" method="post" action="" onSubmit="return checkform( this );">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td colspan="2"><font color="#FFFFFF"><strong>�޸�����</strong></font><font color="#FFFFFF">&nbsp;</font></td>
          </tr>
          <tr> 
            <td width="20%"><font color="#FFFFFF">������</font></td>
            <td width="80%"><font color="#FFFFFF"> 
              <input name="password" type="password" id="password2">
              ���޸�������</font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">�ظ�����</font></td>
            <td><font color="#FFFFFF"> 
              <input name="repassword" type="password" id="repassword2">
              </font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><div align="right"><font color="#FFFFFF"> 
                <input type="submit" name="Submit" value="ȷ��" class=pagebutton>
                <input name="action" type="hidden" id="action5" value="save">
                </font></div></td>
          </tr>
        </table>
      </form></td>
  </tr>
  <tr class=line_title> 
    <td><strong>�޸�һ��վ�����Ϣ</strong></td>
  </tr>
  <tr valign="top"> 
    <td> <form name="form2" method="post" action="">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="20%"><strong><font color="#FFFFFF">վ����Ϣ</font></strong></td>
            <td width="80%">&nbsp;</td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">ԭ����</font></td>
            <td><font color="#FFFFFF"> 
              <input name="oldpassword" type="password" id="oldpassword2" maxlength="50">
              ��������ԭ����������޸�����</font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">վ������*</font></td>
            <td><font color="#FFFFFF"> 
              <input name="sitename" type="text" id="sitename2" value="<?php echo $this->_tpl_vars['UserData']['sitename']; ?>
" maxlength="10">
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">վ�����*</font></td>
            <td><font color="#FFFFFF"> 
              <input name="website" type="text" id="sitename2" value="<?php echo $this->_tpl_vars['UserData']['website']; ?>
" maxlength="10">
              վ��ͳ�ƴ���,һ��ȷ����Ҫ�����޸�</font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">վ�����*</font></td>
            <td><font color="#FFFFFF"> 
              <input name="sitedes" type="text" id="sitedes2" value="<?php echo $this->_tpl_vars['UserData']['sitedes']; ?>
" size="50" maxlength="125">
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">վ���ַ*</font></td>
            <td><font color="#FFFFFF"> 
              <input name="site" type="text" id="site2" value="<?php echo $this->_tpl_vars['UserData']['site']; ?>
" size="50" maxlength="125">
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">��վ����*</font></td>
            <td><font color="#FFFFFF"> 
              <select name="sitetype">
                <option selected><?php echo $this->_tpl_vars['UserData']['sitetype']; ?>
</option>
                <option>Ӱ��</option>
                <option>����</option>
                <option>���Ӿ���</option>
                <option>��ѧ����</option>
                <option>��������</option>
                <option>��ַ��ȫ</option>
                <option>��̳������</option>
                <option>Ӳ��������</option>
                <option>��������</option>
                <option>ҽ�ƽ���</option>
                <option>�����˶�</option>
                <option>����Ļ�</option>
                <option>�������ҵ</option>
                <option>���������</option>
                <option>ý��������</option>
                <option>������ҳ</option>
                <option>��ҵ����</option>
                <option>���߷���</option>
                <option>����</option>
                <!--FIXME-->
              </select>
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">Email*</font></td>
            <td><font color="#FFFFFF"> 
              <input name="email" type="text" id="email2" value="<?php echo $this->_tpl_vars['UserData']['email']; ?>
">
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">QQ</font></td>
            <td><font color="#FFFFFF"> 
              <input name="qq" type="text" id="qq2" value="<?php echo $this->_tpl_vars['UserData']['qq']; ?>
">
              </font></td>
          </tr>
          <tr> 
            <td><font color="#FFFFFF">MSN</font></td>
            <td><font color="#FFFFFF"> 
              <input name="msn" type="text" id="msn2" value="<?php echo $this->_tpl_vars['UserData']['msn']; ?>
">
              </font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><div align="right"><font color="#FFFFFF"> 
                <input name="action" type="hidden" id="action6" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['actionnew'])) ? $this->_run_mod_handler('default', true, $_tmp, 'save') : smarty_modifier_default($_tmp, 'save')); ?>
">
                </font> 
                <input type="submit" name="editsite" value="ȷ��" class=pagebutton>
                <input type="submit" name="newsite" value="�½�" class=pagebutton>
              </div></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</form>