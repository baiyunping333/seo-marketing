<?php /* Smarty version 2.6.6, created on 2005-11-29 17:38:39
         compiled from stat_year.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_select_date', 'stat_year.html', 5, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><form name="form1" method="get" action="">
        <?php echo smarty_function_html_select_date(array('time' => $this->_tpl_vars['DataTime'],'end_year' => "+5",'start_year' => "-2",'display_days' => false,'display_months' => false,'month_format' => "%m"), $this);?>
<font color="#FFFFFF">��</font> 
        <input type="submit" name="Submit" value="�鿴" class=pagebutton>
        <input type="button" name="Submit" value="��һ��"  class=pagebutton onClick="location='stat_year.php?Date_Year=<?php echo $this->_tpl_vars['Year']-1; ?>
';">
        <input type="button" name="Submit" value="��һ��"  class=pagebutton onClick="location='stat_year.php?Date_Year=<?php echo $this->_tpl_vars['Year']+1; ?>
';">
      </form>
        
      <table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" >
        <tr class=line_title> 
          <td colspan="2" valign="bottom">ͳ������:<?php echo $this->_tpl_vars['Year']; ?>
 �ܼ�IP��:<?php echo $this->_tpl_vars['CountIpAll']; ?>
�� 
            �������:<?php echo $this->_tpl_vars['CountAll']; ?>
��</td>
        </tr>
        <tr class=line_title> 
          <td width="10%" valign="bottom" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="line-text" style="text-align:right;">
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['MonthLineCount']*4; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['MonthLineCount']*3; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['MonthLineCount']*2; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['MonthLineCount']*1; ?>
</td>
              </tr>
              <tr> 
                <td height="30">0</td>
              </tr>
              <tr> 
                <td height="5"></td>
              </tr>
            </table></td>
          <td width="90%" align="left"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" style="text-align:center;border-left: 1px solid #000000;">
              <tr bgcolor="#FFFFFF" style="background-image:url(imagefiles/pillartrbg.gif);"> 
                <?php if (count($_from = (array)$this->_tpl_vars['MonthData'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td height="160" style="vertical-align:bottom;"><div class="pillar1" style="height:<?php echo $this->_tpl_vars['Item']['MonthPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['MonthIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['MonthIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['MonthCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['MonthPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['MonthCount']; ?>
</span></div>
                  <div class="pillar2" style="height:<?php echo $this->_tpl_vars['Item']['MonthIpPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['MonthIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['MonthIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['MonthCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['MonthPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['MonthIpCount']; ?>
</span></div></td>
                <?php endforeach; unset($_from); endif; ?> </tr>
              <tr bgcolor="#FFFFFF"> <?php if (count($_from = (array)$this->_tpl_vars['YearMonth'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td width="<?php echo $this->_tpl_vars['PillarTdWidth']; ?>
" height="20" bgcolor="#FFFFFF"><?php echo $this->_tpl_vars['Key']; ?>
</td>
                <?php endforeach; unset($_from); endif; ?> </tr>
            </table></td>
        </tr>
      </table>
      
    </td>
  </tr>
</table>