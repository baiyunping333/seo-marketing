<?php /* Smarty version 2.6.6, created on 2005-11-29 22:01:15
         compiled from referer.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'referer.html', 20, false),array('modifier', 'date_format', 'referer.html', 26, false),array('modifier', 'truncate', 'referer.html', 28, false),)), $this); ?>
<body topmargin="0">
<?php if ($this->_tpl_vars['Engine'] != true): ?> 
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr class=line_title align="center">

    <td align="center"><strong>��Դ</strong></td>

    <td align="center"><strong>���ʴ���</strong></td>

    <td align="center"><strong>������ʱ��</strong></td>

    <td align="center"><strong>��������Դ</strong></td>

  </tr>

  <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?>

  <?php if ($this->_tpl_vars['Item']['referer'] != ''): ?>

  <tr bgcolor="<?php echo smarty_function_cycle(array('values' => "#F8FCFC,#EEF7F7"), $this);?>
">

    <td height="22"><span title="<?php echo $this->_tpl_vars['Item']['keyword']; ?>
">&nbsp;<?php echo $this->_tpl_vars['Item']['referer']; ?>
</span></td>

    <td height="22" align="center">&nbsp;<?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['Percent']; ?>
%)</td>

    <td height="22" align="center">&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['times'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%M:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%M:%S")); ?>
</td>

    <td height="22"><a href="<?php echo $this->_tpl_vars['Item']['lastpage']; ?>
" target="_blank" title="<?php echo $this->_tpl_vars['Item']['lastpage']; ?>
">&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['lastpage'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 43, "...", true) : smarty_modifier_truncate($_tmp, 43, "...", true)); ?>
</a></td>

  </tr>

  <?php else: ?>

  <tr bgcolor="<?php echo smarty_function_cycle(array('values' => "#E6F2FF,#FDFDFD"), $this);?>
" onMouseOut=bgColor='#FDFDFD'  onMouseOver=bgColor='#E6F2FF'>

    <td height="22"><span title="<?php echo $this->_tpl_vars['Item']['keyword']; ?>
">&nbsp;ֱ��������ַ</span></td>

    <td height="22" align="center">&nbsp;<?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['Percent']; ?>
%)</td>

    <td height="22" align="center">&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['times'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%M:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%M:%S")); ?>
</td>

    <td height="22">&nbsp;</td>

  </tr>

  <?php endif; ?>

  <?php endforeach; unset($_from); endif; ?>

  <tr bgcolor="#FFFFFF">

    <td colspan="4" align="center"><?php echo $this->_tpl_vars['PageLinks']; ?>
</td>

  </tr>

</table>

<?php else: ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>

    <td valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
        <tr class=line_title>

        <td align="center"><strong><span >��������ͳ��</span></strong><strong></strong></td>

      </tr>

      <tr bgcolor="#FFFFFF">

        <td><table width="100%" border="0" cellpadding="0" cellspacing="1">
              <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
              <tr>

              <td width="100" style="background-color:#EEF7F7;border-bottom:1px solid #ffffff;" title="<?php echo $this->_tpl_vars['Item']['referer']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><a href="<?php echo $this->_tpl_vars['Item']['referer']; ?>
" target="_blank"><?php echo $this->_tpl_vars['Item']['referer']; ?>
</a></td>

              <td bgcolor="#F8FCFC" title="<?php echo $this->_tpl_vars['Item']['referer']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><div class="pillar2" nowrap style="border-top:1px solid #000000;border-bottom:1px solid #000000;width:<?php echo $this->_tpl_vars['Item']['percent']; ?>
%;"><span style="cursor: default;"><?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)</span></div></td>

            </tr>

        <?php endforeach; unset($_from); endif; ?>

        </table></td>

      </tr>

    </table></td>

  </tr>

</table>

<?php endif; ?>