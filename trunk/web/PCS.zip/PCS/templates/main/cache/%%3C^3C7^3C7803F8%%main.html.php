<?php /* Smarty version 2.6.6, created on 2006-01-12 14:54:05
         compiled from main.html */ ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=gb2312">

<title><?php echo $this->_tpl_vars['Title']; ?>
</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body topmargin="0">
<center>
  <table width="100%" border="0" cellpadding="0" cellspacing="0" >
    <tr>

      <td height="383"> 
        <table width="100%"  border="0" cellspacing="0" cellpadding="0">

      <tr>

            <td height="363" valign="top" class="cod"> 
              <table width="100%"  border="0" cellspacing="0" cellpadding="3">

            <tr>

                  <td width="99%" bgcolor="#FFFFFF">���ڲ鿴 <span class="nowp"><?php echo $this->_tpl_vars['NowView']; ?>
</span> 
                    | <?php echo $this->_tpl_vars['QuickLink']; ?>
</td>

              <td width="1%" style="text-align:right; "><marquee behavior="scroll" scrollDelay="250" onmouseover="this.stop()" onmouseout="this.start()">

              

              </marquee></td>

            </tr>

          </table>

          <div class="mainbody"><?php echo $this->_tpl_vars['Main']; ?>
</div></td>

      </tr>

      <tr>

            <td height="20" align="center"> <strong><font color="#FFFFFF">PCS��վ����ͳ�Ʒ���ϵͳ 
              </font></strong></td>

      </tr>

    </table></td>

  </tr>

</table>

</center>

</body>

</html>
