<?php /* Smarty version 2.6.6, created on 2006-01-11 20:16:05
         compiled from pagelinks.html */ ?>

���� <?php echo $this->_tpl_vars['PageItems']['RecordCount']; ?>
 <?php echo $this->_tpl_vars['PageItems']['RecordUnit'];  echo $this->_tpl_vars['PageItems']['RecordName']; ?>
 ÿҳ��ʾ <?php echo $this->_tpl_vars['PageItems']['PageSize']; ?>
 <?php echo $this->_tpl_vars['PageItems']['RecordUnit']; ?>
 | �� <?php echo $this->_tpl_vars['PageItems']['PageCount']; ?>
 ҳ

ҳ��:
<?php if (count($_from = (array)$this->_tpl_vars['PageItems']['Links'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?>
	<?php if ($this->_tpl_vars['Item']['type'] == 'LINK'): ?>
		<a href="<?php echo $this->_tpl_vars['Item']['link']; ?>
">[<?php echo $this->_tpl_vars['Item']['text']; ?>
]</a>
	<?php else: ?>
		<?php echo $this->_tpl_vars['Item']['text']; ?>

	<?php endif; ?>
<?php endforeach; unset($_from); endif; ?>
|
<br>
<!-- ��ҳ -->
<?php if ($this->_tpl_vars['PageItems']['Before']['0']['type'] == 'LINK'): ?>
	<a href="<?php echo $this->_tpl_vars['PageItems']['Before']['0']['link']; ?>
"><?php echo $this->_tpl_vars['PageItems']['Before']['0']['text']; ?>
</a>
<?php else: ?>
	<font color="#BBBBBB"><?php echo $this->_tpl_vars['PageItems']['Before']['0']['text']; ?>
</font>
<?php endif; ?>

<!-- ǰҳ -->
<?php if ($this->_tpl_vars['PageItems']['Before']['1']['type'] == 'LINK'): ?>
	<a href="<?php echo $this->_tpl_vars['PageItems']['Before']['1']['link']; ?>
"><?php echo $this->_tpl_vars['PageItems']['Before']['1']['text']; ?>
</a>
<?php else: ?>
	<font color="#BBBBBB"><?php echo $this->_tpl_vars['PageItems']['Before']['1']['text']; ?>
</font>
<?php endif; ?>

<!-- ��ҳ -->
<?php if ($this->_tpl_vars['PageItems']['After']['0']['type'] == 'LINK'): ?>
	<a href="<?php echo $this->_tpl_vars['PageItems']['After']['0']['link']; ?>
"><?php echo $this->_tpl_vars['PageItems']['After']['0']['text']; ?>
</a>
<?php else: ?>
	<font color="#BBBBBB"><?php echo $this->_tpl_vars['PageItems']['After']['0']['text']; ?>
</font>
<?php endif; ?>

<!-- βҳ -->
<?php if ($this->_tpl_vars['PageItems']['After']['1']['type'] == 'LINK'): ?>
	<a href="<?php echo $this->_tpl_vars['PageItems']['After']['1']['link']; ?>
"><?php echo $this->_tpl_vars['PageItems']['After']['1']['text']; ?>
</a>
<?php else: ?>
	<font color="#BBBBBB"><?php echo $this->_tpl_vars['PageItems']['After']['1']['text']; ?>
</font>
<?php endif; ?>