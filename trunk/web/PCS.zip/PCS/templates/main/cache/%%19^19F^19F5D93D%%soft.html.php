<?php /* Smarty version 2.6.6, created on 2005-11-27 20:47:11
         compiled from soft.html */ ?>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1">
  <tr class=line_title> 
    <td align="center"><strong>�ͻ��������</strong><strong>ͳ��</strong></td>
    <td align="center"><strong>�ͻ��˲���ϵͳͳ��</strong></td>
  </tr>
  <tr bgcolor="#FFFFFF"> 
    <td> <table width="100%" border="0" cellpadding="0" cellspacing="1">
        <?php if (count($_from = (array)$this->_tpl_vars['Browser'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
        <tr> 
          <td width="100" style="background-color:#EEF7F7;border-bottom:1px solid #ffffff;" title="<?php echo $this->_tpl_vars['Item']['browser']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><?php echo $this->_tpl_vars['Item']['browser']; ?>
</td>
          <td bgcolor="#F8FCFC" title="<?php echo $this->_tpl_vars['Item']['browser']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><div class="pillar2" nowrap style="border-top:1px solid #000000;border-bottom:1px solid #000000;width:<?php echo $this->_tpl_vars['Item']['percent']; ?>
%;"><span style="cursor: default;"><?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)</span></div></td>
        </tr>
        <?php endforeach; unset($_from); endif; ?> </table></td>
    <td><table width="100%"  border="0" cellspacing="1" cellpadding="0">
        <?php if (count($_from = (array)$this->_tpl_vars['System'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
        <tr> 
          <td width="100" style="background-color:#EEF7F7;border-bottom:1px solid #ffffff;" title="<?php echo $this->_tpl_vars['Item']['system']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><?php echo $this->_tpl_vars['Item']['system']; ?>
</td>
          <td bgcolor="#F8FCFC" title="<?php echo $this->_tpl_vars['Item']['system']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><div class="pillar2" nowrap style="border-top:1px solid #000000;border-bottom:1px solid #000000;width:<?php echo $this->_tpl_vars['Item']['percent']; ?>
%;"><span style="cursor: default;"><?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)</span></div></td>
        </tr>
        <?php endforeach; unset($_from); endif; ?> </table></td>
  </tr>
</table>