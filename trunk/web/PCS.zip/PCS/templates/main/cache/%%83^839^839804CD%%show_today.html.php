<?php /* Smarty version 2.6.6, created on 2006-01-12 21:44:19
         compiled from show_today.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'show_today.html', 11, false),array('modifier', 'date_format', 'show_today.html', 13, false),array('modifier', 'default', 'show_today.html', 25, false),array('modifier', 'truncate', 'show_today.html', 26, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1">
  <tr class=line_title>
    <td width="18%" style="font-weight:bold;">����ʱ��</td>
    <td width="15%" style="font-weight:bold;">����IP</td>
    <td width="15%" style="font-weight:bold;">����</td>
    <td width="31%" style="font-weight:bold;">����ҳ</td>
    <td width="31%" style="font-weight:bold;">��·ҳ</td>
  </tr>
  <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?>
     <tr bgcolor="<?php echo smarty_function_cycle(array('values' => "#E6F2FF,#FDFDFD"), $this);?>
" onMouseOut=bgColor='#FDFDFD'  onMouseOver=bgColor='#E6F2FF' title="IP��ַ:   <?php echo $this->_tpl_vars['Item']['ip']; ?>
 
����:     <?php echo $this->_tpl_vars['Item']['country']; ?>
&nbsp;&nbsp;<?php echo $this->_tpl_vars['Item']['address']; ?>
 
�״η���: <?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['firsttime'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S')); ?>
 
���η���: <?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['lasttime'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S')); ?>
 
����ϵͳ: <?php echo $this->_tpl_vars['Item']['system']; ?>
 
�����:   <?php echo $this->_tpl_vars['Item']['browser']; ?>
 
��Ļ��С: <?php echo $this->_tpl_vars['Item']['screensize']; ?>
 
��ɫ���: <?php echo $this->_tpl_vars['Item']['color']; ?>
λɫ
����:     <?php echo $this->_tpl_vars['Item']['language']; ?>
 
ʱ��:     <?php echo $this->_tpl_vars['Item']['timezone']['0']; ?>
(<?php echo $this->_tpl_vars['Item']['timezone']['1']; ?>
)
<?php if ($this->_tpl_vars['Item']['todayfirst'] == 1): ?>���η���Ϊ24Сʱ�ڵ�һ�η���<?php endif; ?>" >
    <td nowrap>&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%M:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%M:%S")); ?>
&nbsp;</td>
    <td nowrap class="<?php if ($this->_tpl_vars['Item']['todayfirst'] == 1): ?>todayfirst<?php endif; ?>">&nbsp;<?php echo $this->_tpl_vars['Item']['ip']; ?>
&nbsp;
    </td>
    <td nowrap>&nbsp;<?php echo ((is_array($_tmp=@$this->_tpl_vars['Item']['country'])) ? $this->_run_mod_handler('default', true, $_tmp, "δ֪") : smarty_modifier_default($_tmp, "δ֪")); ?>
&nbsp;<?php echo $this->_tpl_vars['Item']['address']; ?>
&nbsp;</td>
    <td ><a href="<?php echo $this->_tpl_vars['Item']['pageurl']; ?>
" target="_blank" title="�ܷ�:<?php echo $this->_tpl_vars['Item']['pageurl']; ?>
">&nbsp;<?php echo ((is_array($_tmp=((is_array($_tmp=@$this->_tpl_vars['Item']['pagesite'])) ? $this->_run_mod_handler('default', true, $_tmp, "/") : smarty_modifier_default($_tmp, "/")))) ? $this->_run_mod_handler('truncate', true, $_tmp, 35, "...", true) : smarty_modifier_truncate($_tmp, 35, "...", true)); ?>
&nbsp;</a></td>
    <td nowrap >&nbsp;<?php if ($this->_tpl_vars['Item']['pagefrom'] != ''): ?>
	<a href="<?php echo $this->_tpl_vars['Item']['pagefrom']; ?>
" target="_blank" title="����:<?php echo $this->_tpl_vars['Item']['pagefrom']; ?>
 ">&nbsp;<?php echo $this->_tpl_vars['Item']['pagefromsite']; ?>
&nbsp;</a>
	<?php else: ?>
	&nbsp;ֱ�������ַ&nbsp;
	<?php endif; ?>
	</td>
  </tr>
  <?php endforeach; unset($_from); endif; ?>
  <tr align="center">
    <td colspan="5" bgcolor="#FFFFFF">&nbsp;<?php echo $this->_tpl_vars['PageLinks']; ?>
</td>
  </tr>
  <tr>
    <td colspan="5" bgcolor="#FFFFFF">&nbsp;С��ʾ:<span class='todayfirst'>IP��ɫ</span>��ʾ24Сʱ�ڵ�һ������</td>
  </tr>
</table>