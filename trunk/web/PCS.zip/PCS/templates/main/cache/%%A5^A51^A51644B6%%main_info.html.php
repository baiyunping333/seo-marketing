<?php /* Smarty version 2.6.6, created on 2006-01-12 14:04:41
         compiled from main_info.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'main_info.html', 96, false),array('modifier', 'date_format', 'main_info.html', 115, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr>

    <td width="50%" valign="top">
<table width="100%" border="0" align="center" cellpadding="2" cellspacing="1">
        <tr>

          <td width="60" height="28" bgcolor="#EEF7F7">վ������</td>

        <td width="206" bgcolor="#F8FCFC" class=td_black><?php echo $this->_tpl_vars['SiteInfo']['sitename']; ?>
</td>

      </tr>

      <tr>

          <td height="31" bgcolor="#EEF7F7">վ���ַ</td>

        <td bgcolor="#F8FCFC"  class=td_black><a href="<?php echo $this->_tpl_vars['SiteInfo']['site']; ?>
" target="_blank"><?php echo $this->_tpl_vars['SiteInfo']['site']; ?>
</a></td>

      </tr>

      <tr>

          <td height="31" bgcolor="#EEF7F7">վ�����</td>

        <td bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['SiteInfo']['sitedes']; ?>
</td>

      </tr>

      <tr>

          <td height="36" bgcolor="#EEF7F7">PageRank</td>

        <td bgcolor="#F8FCFC"><script language="javascript" type="text/javascript">

	rankPage = '<?php echo $this->_tpl_vars['SiteInfo']['site']; ?>
';

	</script>

            <script language="javascript" type="text/javascript" src="http://stat.ourplus.com/getpagerank/pagerank.js"></script></td>

      </tr>

      <tr>

          <td height="27" bgcolor="#EEF7F7">&nbsp;</td>

        <td bgcolor="#F8FCFC">&nbsp;</td>

      </tr>

      <tr>

          <td height="28" bgcolor="#EEF7F7">վ��</td>

        <td bgcolor="#F8FCFC" class=td_black><?php echo $this->_tpl_vars['SiteInfo']['manager']; ?>
</td>

      </tr>

      <tr>

          <td height="30" bgcolor="#EEF7F7">վ������</td>

        <td bgcolor="#F8FCFC" class=td_black><?php echo $this->_tpl_vars['SiteInfo']['email']; ?>
</td>

      </tr>

    </table>
    </td>

    <td width="50%" valign="top"> <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1">
        <tr align="center" bgcolor="#EEF7F7"> 
          <td height="23">&nbsp;</td>
          <td height="23">IP������</td>
          <td height="23">�����</td>
        </tr>
        <tr align="center"> 
          <td height="23" bgcolor="#EEF7F7">����</td>
          <td height="23" bgcolor="#F8FCFC">
<p><?php echo $this->_tpl_vars['SiteInfo']['all_count_ip']; ?>
</p></td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['SiteInfo']['all_count']; ?>
</td>
        </tr>
        <tr align="center" style="color:#FF0000;"> 
          <td height="23" bgcolor="#EEF7F7">����</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['TodayInfo']['day_count_ip']; ?>
</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['TodayInfo']['day_count']; ?>
</td>
        </tr>
        <tr align="center"> 
          <td height="23" bgcolor="#EEF7F7">����</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['YesterdayInfo']['day_count_ip']; ?>
</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['YesterdayInfo']['day_count']; ?>
</td>
        </tr>
        <tr align="center"> 
          <td height="23" bgcolor="#EEF7F7">����</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo ((is_array($_tmp=@$this->_tpl_vars['MonthInfo']['month_count_ip'])) ? $this->_run_mod_handler('default', true, $_tmp, '0') : smarty_modifier_default($_tmp, '0')); ?>
</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo ((is_array($_tmp=@$this->_tpl_vars['MonthInfo']['month_count'])) ? $this->_run_mod_handler('default', true, $_tmp, '0') : smarty_modifier_default($_tmp, '0')); ?>
</td>
        </tr>
        <tr align="center"> 
          <td height="23" bgcolor="#EEF7F7">���</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['MaxMin']['maxcountip']; ?>
</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['MaxMin']['maxcount']; ?>
</td>
        </tr>
        <tr align="center"> 
          <td height="23" bgcolor="#EEF7F7">��С</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['MaxMin']['mincountip']; ?>
</td>
          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['MaxMin']['mincount']; ?>
</td>
        </tr>
      </table>
      <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1">
        <tr>

          <td width="70" height="23" bgcolor="#EEF7F7">��ʼͳ����</td>

          <td height="23" bgcolor="#F8FCFC"><?php echo ((is_array($_tmp=$this->_tpl_vars['FirstDay'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d") : smarty_modifier_date_format($_tmp, "%Y-%m-%d")); ?>
</td>

        </tr>

        <tr>

          <td height="23" bgcolor="#EEF7F7">��ͳ������</td>

          <td height="23" bgcolor="#F8FCFC"><?php echo $this->_tpl_vars['CountDays']; ?>
</td>

        </tr>

      </table>
    </td>

  </tr>

  <tr align="center">

    <td colspan="2"><input type="button" name="Submit" value="ͳ�ƴ���߼�ģʽ" onClick="location='getcode.php'" class=pagebutton>

    &nbsp;

    <input type="button" name="Submit" value="�޸�����" onClick="location='profile.php';" class=pagebutton>

     </td>

  </tr>

  <tr align="center">

    <td colspan="2"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" >
        <tr class=line_title> 
          <td valign="top"><strong><a href="#jd">��ģʽ</a></strong><strong></strong></td>
        </tr>
        <tr align="center"> 
          <td  ><table width="600" border="0" align="center" cellpadding="3" cellspacing="1">
              <tr> 
                <td><font color="#FFFFFF">ͳ�ƴ���:</font></td>
              </tr>
              <tr> 
                <td><textarea name="textarea" onFocus="this.select()" readonly cols="80" rows="5" >
<script language=javascript>
 var _OurplusWebSite="<?php echo $this->_tpl_vars['website']; ?>
";
</script>
<script language="javascript" type="text/javascript" src="<?php echo $this->_tpl_vars['Countlink']; ?>
" ></script></textarea></td>
              </tr>
              <tr> 
                <td><font color="#FFFFFF">�����ϴ��븴�Ʋ�������Ҫͳ�Ƶ�ҳ��.������ʾ������Ϣ,�����߼�ģʽ��������</font>.</td>
              </tr>
            </table></td>
        </tr>
        <tr class=line_title> 
          <td valign="top"><strong><a href="getcode.php#gj">�߼�ģʽ</a></strong></td>
        </tr>
      </table></td>

  </tr>

</table>
