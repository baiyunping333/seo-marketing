<?php /* Smarty version 2.6.6, created on 2006-01-12 21:30:33
         compiled from all_site_code.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'all_site_code.html', 47, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr align="center"> 
    <td width="100%">&nbsp;  </td>
  </tr>
  <tr align="center"> 
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td> <?php if ($this->_tpl_vars['switch'] == 'code'): ?> <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
            <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" >
              <tr class=line_title> 
                <td valign="top"><strong><a href="#"><?php echo $this->_tpl_vars['Item']['sitename']; ?>
--��ģʽ</a></strong><strong></strong></td>
              </tr>
              <tr align="center"> 
                <td  ><table width="600" border="0" align="center" cellpadding="3" cellspacing="1">
                    <tr> 
                      <td><font color="#FFFFFF">ͳ�ƴ���:</font></td>
                    </tr>
                    <tr> 
                      <td><textarea name="textarea" onFocus="this.select()" readonly cols="80" rows="6" >
<script language=javascript>
 var _OurplusWebSite="<?php echo $this->_tpl_vars['Item']['website']; ?>
";
</script>
<script language="javascript" type="text/javascript" src="<?php echo $this->_tpl_vars['Item']['Countlink']; ?>
" ></script></textarea></td>
                    </tr>
                    <tr> 
                      <td><font color="#FFFFFF">�����ϴ��븴�Ʋ�������Ҫͳ�Ƶ�ҳ��.������ʾ������Ϣ,�����߼�ģʽ��������.</font></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
            <?php endforeach; unset($_from); endif; ?> <?php endif; ?> </td>
        </tr>
			
        <tr>
	
          <td><?php if ($this->_tpl_vars['switch'] == 'manage'): ?> 
		  <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" >
              <tr class=line_title> 
                <td valign="top"><strong><a href="#"><?php echo $this->_tpl_vars['Item']['sitename']; ?>
--ͳ����Ϣ</a></strong></td>
              </tr>
              <tr align="center"> 
                <td  ><table width="600" border="0" align="center" cellpadding="3" cellspacing="1">
                    <tr> 
                      <td><textarea name="textarea2" onFocus="this.select()" readonly cols="80" rows="5" >
վ�����:<?php echo $this->_tpl_vars['Item']['website']; ?>

��ʼͳ��ʱ��:<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['fristday'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d") : smarty_modifier_date_format($_tmp, "%Y-%m-%d")); ?>

�Ѿ�ͳ������:<?php echo $this->_tpl_vars['Item']['countday']; ?>
 </textarea></td>
                    </tr>
                    <tr> 
                      <td><div align="right"><a href="javascript:if(confirm('ȷʵҪ��ո�վ��[<?php echo $this->_tpl_vars['Item']['sitename']; ?>
]��ͳ����Ϣ��?�ò���������ת!')) location='manage_all_site.php?website=<?php echo $this->_tpl_vars['Item']['website']; ?>
&ac=truncate'"><font color="#FFFFFF">[���]</font> </a>&nbsp;<a href="javascript:if(confirm('ȷʵҪɾ����վ��[<?php echo $this->_tpl_vars['Item']['sitename']; ?>
]�Լ�ͳ����Ϣ��?�ò���������ת!')) location='manage_all_site.php?website=<?php echo $this->_tpl_vars['Item']['website']; ?>
&ac=del'"><font color="#FFFFFF">[ɾ��]</font></a></font></div></td>
                    </tr>
                  </table></td>
              </tr>
            </table><?php endforeach; unset($_from); endif;  endif; ?></td>
        </tr>
      </table>
</td>
  </tr>
</table>
