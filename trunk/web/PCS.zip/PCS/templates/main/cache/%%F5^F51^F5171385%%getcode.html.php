<?php /* Smarty version 2.6.6, created on 2006-01-12 01:48:50
         compiled from getcode.html */ ?>

<table width="600" border="0" align="center" cellpadding="3" cellspacing="0" >
  <tr class=line_title>

    <td valign="top"><strong><a href="#jd">��ģʽ</a><a name="jd"></a></strong></td>

    <td valign="top"><strong><a href="#gj">�߼�ģʽ</a></strong></td>

  </tr>

  <tr align="center">

    <td colspan="2" ><table width="600" border="0" align="center" cellpadding="3" cellspacing="1">

      <tr>

          <td><font color="#FFFFFF">ͳ�ƴ���:</font></td>

      </tr>

      <tr>

        <td><textarea name="textarea" onFocus="this.select()" readonly cols="80" rows="5" >
<script language=javascript>
 var _OurplusWebSite="<?php echo $this->_tpl_vars['website']; ?>
";
</script>
<script language="javascript" type="text/javascript" src="<?php echo $this->_tpl_vars['Countlink']; ?>
" ></script></textarea></td>

      </tr>

      <tr>

          <td><font color="#FFFFFF">�����ϴ��븴�Ʋ�������Ҫͳ�Ƶ�ҳ��.</font></td>

      </tr>

    </table>

      <table width="600" border="0" align="center" cellpadding="3" cellspacing="1">

        <tr>

          <td><font color="#FFFFFF">�������ͳ�ƴ�����js��ʹ��document.write���������Ҳ��������ʺ��㡣�����������������ʹ�ã��벻Ҫʹ��������롣</font></td>

        </tr>

        <tr>

          <td><textarea name="textarea" onFocus="this.select()" readonly cols="80" rows="5"><script language="javascript" type="text/javascript">
var _OurplusType = 2;
var _OurplusWebSite="<?php echo $this->_tpl_vars['website']; ?>
";
</script>
<span id="OurplusCount" name="OurplusCount"></span>
<script language="javascript" src="<?php echo $this->_tpl_vars['Countlink']; ?>
" ></script></textarea></td>

        </tr>

        <tr>

          <td><font color="#FFFFFF">�����ϴ��븴�Ʋ�������Ҫͳ�Ƶ�ҳ��.</font></td>

        </tr>

      </table></td>

  </tr>

  <tr>

    <td colspan="2" valign="top" class=line_title><strong><a href="#gj">�߼�ģʽ</a><a name="gj"></a></strong></td>

  </tr>

  <tr>

    <td colspan="2" valign="top"><font color="#FFFFFF">�����Զ�����ͳ�ƴ�����ʾһ������,��������˳�� 
      ͼ��:</font><br>

    <img name="" src="imagefiles/yl.gif" alt="" ></td>

  </tr>

  <tr>

    <td colspan="2" valign="top"><table width="600" border="0" align="center" cellpadding="3" cellspacing="1">

      <tr>

          <td> <font color="#FFFFFF">��ʾ����:<br>
            <label for="DayCount"> 
            <input name="DayCount" type="checkbox" id="DayCount" value="DayCount" onclick="ChSel();">
            ���շ�����</label>
            <br>
            <label for="DayIpCount"> 
            <input name="DayIpCount" type="checkbox" id="DayIpCount" value="DayIpCount" onclick="ChSel();">
            ����IP������</label>
            <br>
            <label for="HourCount"> 
            <input name="HourCount" type="checkbox" id="HourCount" value="HourCount" onclick="ChSel();">
            ��Сʱ������</label>
            <br>
            <label for="HourIpCount"> 
            <input name="HourIpCount" type="checkbox" id="HourIpCount" value="HourIpCount" onclick="ChSel();">
            ��СʱIP������</label>
            </font> </td>

        <td align="right"><select name="SelItem" size="5" id="SelItem" style="width:120;">

        </select>

          

		</td>

        <td><input type="submit" name="Submit" value="����" onclick="ChUp();" class=pagebutton>

          <br>

          <input type="submit" name="Submit" value="����" onclick="ChDown();" class=pagebutton></td>

      </tr>

    </table>      

      <table width="600" border="0" align="center" cellpadding="3" cellspacing="1">

        <tr>

          <td><div align="center">

            <input type="submit" name="Submit" value="���´���" onclick="ChangeCode();" class=pagebutton>

&nbsp;

          </div></td>

        </tr>

        <tr>

          <td><textarea name="codearea" cols="80" rows="5" readonly id="codearea" onFocus="this.select()"></textarea></td>

        </tr>

        <tr>

          <td><font color="#FFFFFF">�����ϴ��븴�Ʋ�������Ҫͳ�Ƶ�ҳ��.</font></td>

        </tr>

        <tr>

          <td></td>

        </tr>

      </table></td>

  </tr>

</table>

<script language="javascript" type="text/javascript">

ObjArr = new Array();

ObjArr[0] = new Array(DayCount,"���շ�����");

ObjArr[1] = new Array(DayIpCount,"����IP������");

ObjArr[2] = new Array(HourCount,"��Сʱ������");

ObjArr[3] = new Array(HourIpCount,"��СʱIP������");



function ChSel()

{

	SelItem.length = 0; 

	for( i=0; i < ObjArr.length; i++ )

	{

		if( ObjArr[i][0].checked )

		{

			SelItem.options[SelItem.length] = new Option(ObjArr[i][1],ObjArr[i][0].name);

		}

	}

	ChangeCode();

}



function ChUp()

{

	if( SelItem.selectedIndex > 0 )

	{

		ChItem = SelItem.options[SelItem.selectedIndex-1];

		ChItemValue = ChItem.value;

		ChItemText = ChItem.text;

		

		ChItem.value = SelItem.options[SelItem.selectedIndex].value;

		ChItem.text = SelItem.options[SelItem.selectedIndex].text;

		SelItem.options[SelItem.selectedIndex].value = ChItemValue;

		SelItem.options[SelItem.selectedIndex].text = ChItemText;

		SelItem.selectedIndex--;

	}

	ChangeCode();

}



function ChDown()

{

	if( SelItem.selectedIndex < SelItem.length -1 )

	{

		ChItem = SelItem.options[SelItem.selectedIndex+1];

		ChItemValue = ChItem.value;

		ChItemText = ChItem.text;

		

		ChItem.value = SelItem.options[SelItem.selectedIndex].value;

		ChItem.text = SelItem.options[SelItem.selectedIndex].text;

		SelItem.options[SelItem.selectedIndex].value = ChItemValue;

		SelItem.options[SelItem.selectedIndex].text = ChItemText;

		SelItem.selectedIndex++;

	}

	ChangeCode();

}



function ChangeCode()

{

	Code1='';

	Code='';

	Code = "\<\script\>\n";

	//Code += "var _Debug = false;\n";

	for( i=0; i<SelItem.length; i++)

	{

		if( Code1 == '' )

		{

			Code1 = "'" + SelItem.options[i].value + "'";

		}

		else

		{

			Code1 += ", '" + SelItem.options[i].value + "'";

		}

	}

	if( Code1 != '' )	Code += "var _OurplusShow = [ " + Code1 + " ];\n";

	Code += "\var _OurplusWebSite=\"<?php echo $this->_tpl_vars['website']; ?>
\";\n</script\>\n";

	Code += "\<script language=\"javascript\" type=\"text/javascript\" src=\"<?php echo $this->_tpl_vars['Countlink']; ?>
\" \>\</script\>";

	codearea.value=Code;

}



function yulan()

{

  var code=codearea.value;//��Ҫ���еĴ��롣

  var newwin=window.open('/_temp/none.html','','');  //��һ�����ڲ���������newwin��

  newwin.opener = null // ��ֹ�������̸ҳ���޸�

  newwin.document.write('<html><body>\<script\>alert("a");\</script\>ddd' + code + 'ddd</body></html>');  //������򿪵Ĵ�����д�����code��������ʵ�������д��빦�ܡ�

  

  newwin.document.close();

}



ChangeCode();

</script>