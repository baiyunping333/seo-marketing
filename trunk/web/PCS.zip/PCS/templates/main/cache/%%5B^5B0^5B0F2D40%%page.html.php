<?php /* Smarty version 2.6.6, created on 2005-11-30 00:17:32
         compiled from page.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'page.html', 17, false),array('modifier', 'default', 'page.html', 19, false),array('modifier', 'truncate', 'page.html', 19, false),array('modifier', 'date_format', 'page.html', 23, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr class=line_title>

    <td align="center" width="35%"><strong>�ܷ�ҳ��</strong></td>

    <td align="center" width="10%"><strong>&nbsp;���ʴ���</strong></td>

    <td align="center" width="20%"><strong>������ʱ��</strong></td>

    <td align="center" width="35%"><strong>��������Դ</strong></td>

  </tr>

  <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?>

   <tr bgcolor="<?php echo smarty_function_cycle(array('values' => "#E6F2FF,#FDFDFD"), $this);?>
" onMouseOut=bgColor='#FDFDFD'  onMouseOver=bgColor='#E6F2FF'>

    <td>&nbsp;<a href="<?php echo $this->_tpl_vars['Item']['page']; ?>
" target="_blank" title="<?php echo $this->_tpl_vars['Item']['page']; ?>
"><?php echo ((is_array($_tmp=((is_array($_tmp=@$this->_tpl_vars['Item']['page'])) ? $this->_run_mod_handler('default', true, $_tmp, "/") : smarty_modifier_default($_tmp, "/")))) ? $this->_run_mod_handler('truncate', true, $_tmp, 35, "...", true) : smarty_modifier_truncate($_tmp, 35, "...", true)); ?>
</a></td>

    <td align="center">&nbsp;<?php echo $this->_tpl_vars['Item']['counts']; ?>
</td>

    <td align="center">&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['times'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%M:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%M:%S")); ?>
</td>

    <td><a href="<?php echo $this->_tpl_vars['Item']['lastpage']; ?>
" target="_blank" title="<?php echo $this->_tpl_vars['Item']['lastpage']; ?>
">&nbsp;<?php echo $this->_tpl_vars['Item']['lastsite']; ?>
</a></td>

  </tr>

  <?php endforeach; unset($_from); endif; ?>

  <tr bgcolor="#FFFFFF">

    <td colspan="4" align="center"><?php echo $this->_tpl_vars['PageLinks']; ?>
</td>

  </tr>

</table>
