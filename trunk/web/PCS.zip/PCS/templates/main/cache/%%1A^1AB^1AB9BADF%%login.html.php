<?php /* Smarty version 2.6.6, created on 2005-11-28 21:59:28
         compiled from login.html */ ?>
<SCRIPT LANGUAGE="JavaScript"> 

function defaultset()
{
	document.form1.manager.focus();
}
function checknull()
{
	if(document.form1.manager.value=='')
		{
		alert("�������û���");
		document.form1.manager.focus();
		return false;
		}
    else if(document.form1.password.value=='')
		{
		alert("����������");
		document.form1.password.focus();
		return false;
		}
	else{
		window.form1.submit();
		}

}
function onkeypressed()
{
	if(event.keyCode==13) //�س���
	{
		checknull();
	}
}
</SCRIPT>
<body bgcolor="#006699" leftmargin="0" topmargin="0" onload="defaultset()" onkeypress="onkeypressed()">
<form name="form1" method="post" action="">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="38%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td height="253"> <div align="center"> 
          <table width="416" height="254" border="0" cellpadding="0" cellspacing="0" background="imagefiles/2004.jpg">
            <tr> 
              <td width="32%">&nbsp;</td>
              <td width="68%">&nbsp;</td>
            </tr>
            <tr> 
              <td height="138">&nbsp;</td>
              <td valign="bottom"> <table width="265"  border="0" align="center" cellpadding="3" cellspacing="0">
                  <tr> 
                    <td width="56"><strong><font color="#FFFFFF">�ʺ�:</font></strong></td>
                    <td width="112"><strong><font color="#FFFFFF"> 
                      <input name="manager" type="text" id="manager" size="16" maxlength="16" style="width=120px;height=22px;">
                      </font></strong></td>
                    <td width="71" rowspan="2"><div align="center"><img src="imagefiles/login.gif" width="54" onclick="checknull()" height="44" style="CURSOR: hand"></div></td>
                  </tr>
                  <tr> 
                    <td><strong><font color="#FFFFFF">����:</font></strong></td>
                    <td><strong><font color="#FFFFFF"> 
                      <input name="password" type="password" id="password" size="16" maxlength="32" style="width=120px;height=22px;">
                      </font></strong></td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
</form>