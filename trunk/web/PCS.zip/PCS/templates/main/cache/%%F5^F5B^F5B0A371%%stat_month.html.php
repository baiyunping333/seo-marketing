<?php /* Smarty version 2.6.6, created on 2005-11-29 17:39:14
         compiled from stat_month.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_select_date', 'stat_month.html', 5, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><form name="form1" method="get" action="">
        <?php echo smarty_function_html_select_date(array('time' => $this->_tpl_vars['DataTime'],'end_year' => "+5",'start_year' => "-2",'display_days' => false,'month_format' => "%m"), $this);?>
<font color="#FFFFFF">��/��</font> 
        <input type="submit" name="Submit" value="�鿴" class=pagebutton>
<input type="button" name="Submit" value="�ϸ���"  class=pagebutton onClick="location='stat_month.php?Date_Month=<?php echo $this->_tpl_vars['Month']-1; ?>
&Date_Year=<?php echo $this->_tpl_vars['Year']; ?>
';" >
        <input type="button" name="Submit" value="�¸���"  class=pagebutton onClick="location='stat_month.php?Date_Month=<?php echo $this->_tpl_vars['Month']+1; ?>
&Date_Year=<?php echo $this->_tpl_vars['Year']; ?>
';">
      </form>
        
      <table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" >
        <tr class=line_title> 
          <td colspan="2" style="border-bottom:1px solid #000;padding:2px;"><strong>ÿ������ͳ��</strong>-----ͳ������:<?php echo $this->_tpl_vars['Year']; ?>
/<?php echo $this->_tpl_vars['Month']; ?>
 
            �ܼ�IP��:<?php echo $this->_tpl_vars['CountIpAll']; ?>
�� �������:<?php echo $this->_tpl_vars['CountAll']; ?>
��</td>
        </tr>
        <tr> 
          <td width="10%" valign="bottom" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="line-text" style="text-align:right;">
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['DayLineCount']*4; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['DayLineCount']*3; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['DayLineCount']*2; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['DayLineCount']*1; ?>
</td>
              </tr>
              <tr> 
                <td height="30">0</td>
              </tr>
              <tr> 
                <td height="5"></td>
              </tr>
            </table></td>
          <td width="90%" align="left"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" style="text-align:center;border-left: 1px solid #000000;">
              <tr bgcolor="#FFFFFF" style="background-image:url(imagefiles/pillartrbg.gif);"> 
                <?php if (count($_from = (array)$this->_tpl_vars['DayData'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td height="160" style="vertical-align:bottom;"><div class="pillar1" style="height:<?php echo $this->_tpl_vars['Item']['DayPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['DayCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['DayCount']; ?>
</span></div>
                  <div class="pillar2" style="height:<?php echo $this->_tpl_vars['Item']['DayIpPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['DayCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
</span></div></td>
                <?php endforeach; unset($_from); endif; ?> </tr>
              <tr bgcolor="#FFFFFF"> <?php if (count($_from = (array)$this->_tpl_vars['MonthDay'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td width="<?php echo $this->_tpl_vars['PillarTdWidth']; ?>
" height="20" bgcolor="<?php if ($this->_tpl_vars['Item'] == 1): ?>#EAEAEA<?php else: ?>#FFFFFF<?php endif; ?>"><?php echo $this->_tpl_vars['Key']; ?>
</td>
                <?php endforeach; unset($_from); endif; ?> </tr>
            </table></td>
        </tr>
      </table>
        
    </td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" >
        <tr class=line_title> 
          <td colspan="2" style="border-bottom:1px solid #000;padding:2px;"><strong>��������ͳ��</strong>-----�ܼ�IP��:<?php echo $this->_tpl_vars['AllCountIpAll']; ?>
�� 
            �������:<?php echo $this->_tpl_vars['AllCountAll']; ?>
��</td>
        </tr>
        <tr> 
          <td width="10%" valign="bottom" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="line-text" style="text-align:right;">
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllDayLineCount']*4; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllDayLineCount']*3; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllDayLineCount']*2; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllDayLineCount']*1; ?>
</td>
              </tr>
              <tr> 
                <td height="30">0</td>
              </tr>
              <tr> 
                <td height="5"></td>
              </tr>
            </table></td>
          <td width="90%" align="left"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" style="text-align:center;border-left: 1px solid #000000;">
              <tr bgcolor="#FFFFFF" style="background-image:url(imagefiles/pillartrbg.gif);"> 
                <?php if (count($_from = (array)$this->_tpl_vars['AllDayData'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td height="160" style="vertical-align:bottom;"><div class="pillar1" style="height:<?php echo $this->_tpl_vars['Item']['DayPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['DayCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['DayCount']; ?>
</span></div>
                  <div class="pillar2" style="height:<?php echo $this->_tpl_vars['Item']['DayIpPillarHeight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="����: <?php echo $this->_tpl_vars['Key']; ?>
 ��
  IP: <?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayIpPercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['DayCount']; ?>
��(<?php echo $this->_tpl_vars['Item']['DayPercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['DayIpCount']; ?>
</span></div></td>
                <?php endforeach; unset($_from); endif; ?> </tr>
              <tr bgcolor="#FFFFFF"> <?php if (count($_from = (array)$this->_tpl_vars['AllMonthDay'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td width="<?php echo $this->_tpl_vars['PillarTdWidth']; ?>
" height="20" class=td_black><?php echo $this->_tpl_vars['Key']; ?>
</td>
                <?php endforeach; unset($_from); endif; ?> </tr>
            </table></td>
        </tr>
      </table>
        
    </td>
  </tr>
</table>