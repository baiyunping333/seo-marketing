<?php /* Smarty version 2.6.6, created on 2005-11-27 20:29:36
         compiled from return.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'return.html', 9, false),array('modifier', 'date_format', 'return.html', 12, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr  class=line_title>
    <td width="119" align="center"><strong>��ͷ����</strong></td>
    <td width="124" align="center"><strong>����</strong></td>
    <td width="435" align="center"><strong>������ʱ��</strong></td>
  </tr>
  <?php if (count($_from = (array)$this->_tpl_vars['Datas'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?>
  <tr bgcolor="<?php echo smarty_function_cycle(array('values' => "#E6F2FF,#FDFDFD"), $this);?>
" onMouseOut=bgColor='#FDFDFD'  onMouseOver=bgColor='#E6F2FF'>
    <td align="center">&nbsp;<?php echo $this->_tpl_vars['Item']['return']; ?>
</td>
    <td align="center">&nbsp;<?php echo $this->_tpl_vars['Item']['counts']; ?>
</td>
    <td align="center">&nbsp;<?php echo ((is_array($_tmp=$this->_tpl_vars['Item']['times'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%M:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%M:%S")); ?>
</td>
  </tr>
  <?php endforeach; unset($_from); endif; ?>
  <tr bgcolor="#FFFFFF">
    <td colspan="3" align="center"><?php echo $this->_tpl_vars['PageLinks']; ?>
</td>
  </tr>
</table>