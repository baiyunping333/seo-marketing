<?php /* Smarty version 2.6.6, created on 2005-11-27 20:35:46
         compiled from stat_day.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_select_date', 'stat_day.html', 9, false),)), $this); ?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center">
<table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" >
        <tr valign="middle" bgcolor="#FFFFFF"> 
          <td colspan="2" > 
            <form name="form1" method="get" action="">
              <div align="center"><?php echo smarty_function_html_select_date(array('time' => $this->_tpl_vars['DataTime'],'end_year' => "+5",'start_year' => "-2",'month_format' => "%m"), $this);?>
��/��/�� 
                <input type="submit" name="Submit" value="�鿴" class=pagebutton >
                <input type="button" name="Submit2" value="��һ��" class=pagebutton onClick="location='stat_day.php?Date_Month=<?php echo $this->_tpl_vars['Month']; ?>
&Date_Day=<?php echo $this->_tpl_vars['Day']-1; ?>
&Date_Year=<?php echo $this->_tpl_vars['Year']; ?>
';">
                <input type="button" name="Submit2" value="��һ��" class=pagebutton onClick="location='stat_day.php?Date_Month=<?php echo $this->_tpl_vars['Month']; ?>
&Date_Day=<?php echo $this->_tpl_vars['Day']+1; ?>
&Date_Year=<?php echo $this->_tpl_vars['Year']; ?>
';">
              </div>
            </form></td>
        </tr>
        <tr> 
          <td colspan="2" class=line_title><strong>ÿ��24Сʱͳ��</strong>------ͳ������:<?php echo $this->_tpl_vars['Year']; ?>
/<?php echo $this->_tpl_vars['Month']; ?>
/<?php echo $this->_tpl_vars['Day']; ?>
 
            �ܼ�IP��:<?php echo $this->_tpl_vars['CountIpAll']; ?>
�� �������:<?php echo $this->_tpl_vars['CountAll']; ?>
��</td>
        </tr>
        <tr> 
          <td width="10%" valign="bottom" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="line-text" style="text-align:right;">
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['HourLineCount']*4; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['HourLineCount']*3; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['HourLineCount']*2; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['HourLineCount']*1; ?>
</td>
              </tr>
              <tr> 
                <td height="30">0</td>
              </tr>
              <tr> 
                <td height="5"></td>
              </tr>
            </table></td>
          <td width="90%" align="left"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" style="text-align:center;border-left: 1px solid #000000;">
              <tr bgcolor="#FFFFFF" style="background-image:url(imagefiles/pillartrbg.gif);"> 
                <?php if (count($_from = (array)$this->_tpl_vars['HourData'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td height="160" style="vertical-align:bottom;"><div class="pillar1" style="height:<?php echo $this->_tpl_vars['Item']['hourpillarheight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="ʱ��: <?php echo $this->_tpl_vars['Key']; ?>
��-<?php echo $this->_tpl_vars['Key']+1; ?>
��
  IP: <?php echo $this->_tpl_vars['Item']['hourip']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourippercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['hour']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourpercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['hour']; ?>
</span></div>
                  <div class="pillar2" style="height:<?php echo $this->_tpl_vars['Item']['hourippillarheight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="ʱ��: <?php echo $this->_tpl_vars['Key']; ?>
��-<?php echo $this->_tpl_vars['Key']+1; ?>
��
  IP: <?php echo $this->_tpl_vars['Item']['hourip']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourippercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['hour']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourpercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['hourip']; ?>
</span></div></td>
                <?php endforeach; unset($_from); endif; ?> </tr>
              <tr bgcolor="#FFFFFF"> <?php if (count($_from = (array)$this->_tpl_vars['DayHour'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td width="<?php echo $this->_tpl_vars['PillarTdWidth']; ?>
" height="20" bgcolor="#FFFFFF" class=td_black><?php echo $this->_tpl_vars['Key']; ?>
</td>
                <?php endforeach; unset($_from); endif; ?> </tr>
            </table></td>
        </tr>
      </table>
      
    </td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td colspan="2" class=line_title><strong>����24Сʱͳ��</strong>-----�ܼ�IP��:<?php echo $this->_tpl_vars['AllCountIpAll']; ?>
�� 
            �������:<?php echo $this->_tpl_vars['AllCountAll']; ?>
��</td>
        </tr>
        <tr> 
          <td width="10%" valign="bottom" bgcolor="#FFFFFF"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="line-text" style="text-align:right;">
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllHourLineCount']*4; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllHourLineCount']*3; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllHourLineCount']*2; ?>
</td>
              </tr>
              <tr> 
                <td height="30"><?php echo $this->_tpl_vars['AllHourLineCount']*1; ?>
</td>
              </tr>
              <tr> 
                <td height="30">0</td>
              </tr>
              <tr> 
                <td height="5"></td>
              </tr>
            </table></td>
          <td width="90%" align="left"><table width="100%" height="180" border="0" cellpadding="0" cellspacing="0" style="text-align:center;border-left: 1px solid #000000;">
              <tr bgcolor="#FFFFFF" style="background-image:url(imagefiles/pillartrbg.gif);"> 
                <?php if (count($_from = (array)$this->_tpl_vars['AllHourData'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td height="160" style="vertical-align:bottom;"><div class="pillar1" style="height:<?php echo $this->_tpl_vars['Item']['hourpillarheight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="ʱ��: <?php echo $this->_tpl_vars['Key']; ?>
��-<?php echo $this->_tpl_vars['Key']+1; ?>
��
  IP: <?php echo $this->_tpl_vars['Item']['hourip']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourippercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['hour']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourpercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['hour']; ?>
</span></div>
                  <div class="pillar2" style="height:<?php echo $this->_tpl_vars['Item']['hourippillarheight']; ?>
px;width:<?php echo $this->_tpl_vars['PillarWidth']; ?>
px;" title="ʱ��: <?php echo $this->_tpl_vars['Key']; ?>
��-<?php echo $this->_tpl_vars['Key']+1; ?>
��
  IP: <?php echo $this->_tpl_vars['Item']['hourip']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourippercent']; ?>
%)
���: <?php echo $this->_tpl_vars['Item']['hour']; ?>
��(<?php echo $this->_tpl_vars['Item']['hourpercent']; ?>
%)"><span class="pillar-text"><?php echo $this->_tpl_vars['Item']['hourip']; ?>
</span></div></td>
                <?php endforeach; unset($_from); endif; ?> </tr>
              <tr bgcolor="#FFFFFF"> <?php if (count($_from = (array)$this->_tpl_vars['AllDayHour'])):
    foreach ($_from as $this->_tpl_vars['Key'] => $this->_tpl_vars['Item']):
?> 
                <td width="<?php echo $this->_tpl_vars['PillarTdWidth']; ?>
"  class=td_black><?php echo $this->_tpl_vars['Key']; ?>
</td>
                <?php endforeach; unset($_from); endif; ?> </tr>
            </table></td>
        </tr>
      </table>
        
    </td>
  </tr>
</table>