<?php /* Smarty version 2.6.6, created on 2005-11-29 17:34:45
         compiled from screen.html */ ?>
<link href="style.css" rel="stylesheet" type="text/css"> 
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" >
  <tr  class=line_title> 
    <td width="50%" align="center" class=td_black><strong>��Ļ�ֱ���</strong><strong></strong></td>
    <td width="50%" align="center" class=td_black><strong>��Ļ��ɫλ��</strong></td>
  </tr>
  <tr bgcolor="#E6F2FF" onMouseOut=bgColor='#FDFDFD'  onMouseOver=bgColor='#E6F2FF' class=tr_bg> 
    <td><table width="100%" border="0" cellpadding="0" cellspacing="1">
        <?php if (count($_from = (array)$this->_tpl_vars['ScreenSize'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
        <tr> 
          <td width="80" class=td_black title="<?php echo $this->_tpl_vars['Item']['screen']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><?php echo $this->_tpl_vars['Item']['screen']; ?>
</td>
          <td bgcolor="#F8FCFC" title="<?php echo $this->_tpl_vars['Item']['screen']; ?>
 <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><div class="pillar2" nowrap style="border-top:1px solid #000000;border-bottom:1px solid #000000;width:<?php echo $this->_tpl_vars['Item']['percent']; ?>
%;"><span style="cursor: default;"><?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)</span></div></td>
        </tr>
        <?php endforeach; unset($_from); endif; ?> </table></td>
    <td><table width="100%"  border="0" cellspacing="1" cellpadding="0">
        <?php if (count($_from = (array)$this->_tpl_vars['Color'])):
    foreach ($_from as $this->_tpl_vars['Item']):
?> 
        <tr> 
          <td width="40" class=td_black title="<?php echo $this->_tpl_vars['Item']['color']; ?>
λ <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><?php echo $this->_tpl_vars['Item']['color']; ?>
</td>
          <td bgcolor="#F8FCFC" title="<?php echo $this->_tpl_vars['Item']['color']; ?>
λ <?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)"><div class="pillar2" nowrap style="border-top:1px solid #000000;border-bottom:1px solid #000000;width:<?php echo $this->_tpl_vars['Item']['percent']; ?>
%;"><span style="cursor: default;"><?php echo $this->_tpl_vars['Item']['counts']; ?>
(<?php echo $this->_tpl_vars['Item']['percent']; ?>
%)</span></div></td>
        </tr>
        <?php endforeach; unset($_from); endif; ?> </table></td>
  </tr>
</table>