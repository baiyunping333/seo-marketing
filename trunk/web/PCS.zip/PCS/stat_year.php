<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once 'parse_site.php';
	global $website;
	Initialize( $_GET, array( 'Date_Year'=>'intval' ) );
	include_once 'initmenu.php';
	$UserId = intval( $_SESSION[ourplus_userid] );

	if( isset( $_GET[Date_Year] ) )
	{
		$Year = isset( $_GET[Date_Year] ) ? intval( $_GET[Date_Year] ) : date('Y');
		$YearTime = mktime (0,0,0,1,1,$Year);
	}
	else
	{
		$YearTime = mktime (0,0,0,1,1,date("Y"));
		$Year = date( 'Y', $YearTime );
	}

	//��ͳ����Ϣ����
	$EndTime = mktime (0,0,0,1,0,$Year+1 );
	$Res = mysql_query( " select * from $TableList[month_data] where times <= $EndTime and times >= $YearTime and website = '$website'" );

	while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
	{
		$TmpMonth = intval( date( 'm', $Tmp[times] ) );
		$StatIp[$TmpMonth] = intval( $Tmp[month_count_ip] );
		$Stat[$TmpMonth] = intval( $Tmp[month_count] );

		$CountIpAll += $StatIp[$TmpMonth];
		$CountAll += $Stat[$TmpMonth];
		$MaxCount = $Stat[$TmpMonth] > $MaxCount ? $Stat[$TmpMonth] : $MaxCount;
	}

	$CountIpAll = $CountIpAll > 0 ? $CountIpAll : 0;
	$CountAll = $CountAll > 0 ? $CountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$MonthLineCount = intval( $MaxCount / 5 );

	for( $i = 1; $i <= 12; $i++ )
	{

		$MonthIpPercent = $CountIpAll == 0 ? 0 : sprintf("%01.2f", ( $StatIp[$i]/$CountIpAll ) * 100 );
		$MonthIpPillarHeight = $Quotiety * $StatIp[$i];
		$MonthIpPillarHeight = $MonthIpPillarHeight < 1 ? 1 : $MonthIpPillarHeight;

		$MonthPercent = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Stat[$i]/$CountAll ) * 100 );
		$MonthPillarHeight = ( $Quotiety * $Stat[$i] ) - $MonthIpPillarHeight;
		$MonthPillarHeight = $MonthPillarHeight < 1 ? 1 : $MonthPillarHeight;


		$MonthData[$i] = array(
									'MonthIpPercent' => $MonthIpPercent,
									'MonthIpPillarHeight' => $MonthIpPillarHeight,
									'MonthPercent' => $MonthPercent,
									'MonthPillarHeight' => $MonthPillarHeight,
									'MonthIpCount' => intval( $StatIp[$i] ),
									'MonthCount' => intval( $Stat[$i] ),
								);

		$YearMonth[$i] = $i;

	}

	$Tpl->assign( 'PillarTdWidth', PILLAR_WIDTH/count($MonthData)  );
	$Tpl->assign( 'PillarWidth', ( PILLAR_WIDTH/count($MonthData) ) - 20  );
	$Tpl->assign( 'YearMonth', $YearMonth );
	$Tpl->assign( 'MonthData', $MonthData );
	$Tpl->assign( 'MonthLineCount', $MonthLineCount );

	$Tpl->assign( 'CountIpAll', $CountIpAll );
	$Tpl->assign( 'CountAll', $CountAll );

	//����ͳ����Ϣ��������

	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'DataTime', $YearTime );

	$Tpl->assign( 'Main', $Tpl->fetch( 'stat_year.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', '�·��� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', '�·���' );
	$Tpl->assign( 'QuickLink', '<a href="stat_day.php">ʱ�η���</a> <a href="stat_month.php">�նη���</a> <a href="stat_year.php">�·��� </a>' );
	_out( $Tpl->fetch( 'main.html' )  );

?>