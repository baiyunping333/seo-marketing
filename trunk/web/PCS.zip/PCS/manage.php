<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';

	$UserId = intval( $_SESSION[SESSION_USERID] );
	if( ADMIN_ID != $UserId )
	{
		echo "<SCRIPT LANGUAGE=\"JavaScript\">
		<!--
			alert( '�����ǹ���Ա' );
			history.back();
		//-->
		</SCRIPT>";
		exit;
	}
	//Initialize( $_GET, array( 'type'=>'intval', 'page'=>'intval' ) );


	//��ȡ��Ա��Ϣ
	if( $_GET[ac] == 'getuser' )
	{
		Initialize( $_GET, array( 'userid'=>'intval') );

		if( ! $_GET[userid] > 0 )
		{
			exit( 'UserId Error Line At ' . __line__ );
		}

		$Year = date( 'Y' );
		$Month = date( 'm' );
		$Day = date( 'j' );
		$DayStartTime = mktime(0, 0, 0, $Month, $Day, $Year);
		$DayStartTime1 = mktime(0, 0, 0, $Month, $Day-1, $Year);
		$DayStartTime2 = mktime(0, 0, 0, $Month, $Day-2, $Year);
		$Res = mysql_query( " select cu.userid, cu.logincount, cu.lastlogin, cu.manager, cu.password, cu.site, cu.sitename, cu.sitedes, cu.sitetype, cu.qq, cu.email, cu.msn, cu.all_count, cu.all_count_ip, cdd.day_count as day_count, cdd.day_count_ip as day_count_ip, cdd1.day_count as day_count1, cdd1.day_count_ip as day_count_ip1, cdd2.day_count as day_count2, cdd2.day_count_ip as day_count_ip2   from " . $TableList[users] . " as cu
														left join " . $TableList[day_data] . " as cdd on cu.userid = cdd.userid and cdd.times = $DayStartTime
														left join " . $TableList[day_data] . " as cdd1 on cu.userid = cdd1.userid and cdd1.times = $DayStartTime1
														left join " . $TableList[day_data] . " as cdd2 on cu.userid = cdd2.userid and cdd2.times = $DayStartTime2
														where cu.userid = $_GET[userid] " );
		$UserData = mysql_fetch_array( $Res, MYSQL_ASSOC );
		echo "<SCRIPT LANGUAGE=\"JavaScript\">
		<!--
			var Strs = '';
			Strs += '<table width=\"98%\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td>QQ:{$UserData[qq]}</td>' + \"\\\n\";
			Strs+= '  <td>MSN:{$UserData[msn]}</td>' + \"\\\n\";
			Strs+= '  <td>Email:<a href=\"mailto:{$UserData[email]}\">{$UserData[email]}</a></td>' + \"\\\n\";
			Strs+= '  <td><a href=\"manage.php?ac=deluser&userid={$UserData[userid]}\" target=\"ac\" onClick=\"return confirm(\'��ȷ��Ҫɾ����?\');\">[<u><strong>ɾ�����û�</strong></u>]</a></td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td nowrap>��IP������:{$UserData[all_count_ip]}</td>' + \"\\\n\";
			Strs+= '  <td nowrap>�������:{$UserData[all_count]}</td>' + \"\\\n\";
			Strs+= '  <td colspan=\"2\" rowspan=\"4\" width=300>����:{$UserData[sitedes]}</td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td nowrap>����IP������:{$UserData[day_count_ip]}</td>' + \"\\\n\";
			Strs+= '  <td nowrap>���������:{$UserData[day_count]}</td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td nowrap>����IP������:{$UserData[day_count_ip1]}</td>' + \"\\\n\";
			Strs+= '  <td nowrap>���������:{$UserData[day_count1]}</td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td nowrap>ǰ��IP������:{$UserData[day_count_ip2]}</td>' + \"\\\n\";
			Strs+= '  <td nowrap>ǰ�������:{$UserData[day_count2]}</td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '<tr>' + \"\\\n\";
			Strs+= '  <td nowrap>��¼����:{$UserData[logincount]}</td>' + \"\\\n\";
			Strs+= '  <td nowrap>����¼:" . date( "Y-m-d H:i:s", $UserData[lastlogin] ) . "</td>' + \"\\\n\";
			Strs+= '</tr>' + \"\\\n\";
			Strs+= '</table>' + \"\\\n\";
			top.site{$_GET[userid]}.innerHTML = Strs;
		//-->
		</SCRIPT>";

		/*$yesterday|date_format:"%A, %B %e, %Y"}


*/
		exit;
	}	
	else if( $_GET[ac] == 'deluser' )//ɾ����Ա
	{
		Initialize( $_GET, array( 'userid'=>'intval') );

		if( $_GET[userid] > 0 )
		{

			$TmpUserId = $_GET[userid];
			$UserDataDir = TMPDIR;

			while( $TmpUserId > 0 )
			{
				$UserDataDir .= '/' . strval( $TmpUserId%10 );
				$TmpUserId = intval( $TmpUserId/10 );
			}
			$UserDataDir .= '/data_' . $_GET[userid];
		}
		else
		{
			exit( 'UserId Error Line At ' . __line__ );
		}
echo $UserDataDir;
		//ɾ���û�Ŀ¼
		if( !is_dir( $UserDataDir ) ||  _RmDir( $UserDataDir ) )
		{
			foreach( $TableList as $Val )
			{
				mysql_query( 'delete from ' . $Val . ' where userid = ' . $_GET[userid] );
			}
			echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--
				alert('ɾ���ɹ�');
				top.ac.location='';
				top.location.reload();
			//-->
			</SCRIPT>";
			exit;
		}
		else
		{
			echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--
				alert('ɾ��ʧ��');
				top.ac.location='';
			//-->
			</SCRIPT>";
			exit;
		}


	}
	else if( $_GET[ac] == 'optimize' )//�Ż����ݿ�
	{
		Initialize( $_GET, array( 'table'=>'strval') );
		if( $_GET[table] != '' )
		{
			mysql_query( " OPTIMIZE TABLE `$_GET[table]` " );
		}
		else
		{
			foreach( $TableList as $Val )
			{
				mysql_query( " OPTIMIZE TABLE `$Val` " );
			}
		}

		echo "<SCRIPT LANGUAGE=\"JavaScript\">
		<!--
			//alert('���ݿ��Ż����!');
			history.back();
		//-->
		</SCRIPT>";
		exit;
	}
	else if( $_GET[ac] == 'tables' )
	{
		$Res = mysql_query( 'SHOW TABLE STATUS FROM `test`' );
		while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
		{
			$Tmp[All_Data_Length] = $Tmp[Data_length] + $Tmp[Data_free] + $Tmp[Index_length];

			$CountAll[Rows] += $Tmp[Rows];
			$CountAll[Data_free] += $Tmp[Data_free];
			$CountAll[All_Data_Length] += $Tmp[All_Data_Length];
			$CountAll[Index_length] += $Tmp[Index_length];

			if( $Tmp[Data_free] > 1024*1024*10 )
			{
				$Tmp[Data_free_underline] = 1;
			}

			$Tmp[Data_length] = format_size( $Tmp[Data_length] );
			$Tmp[Max_data_length] = format_size( $Tmp[Max_data_length] );
			$Tmp[Data_free] = format_size( $Tmp[Data_free] );
			$Tmp[Index_length] = format_size( $Tmp[Index_length] );
			$Tmp[All_Data_Length] = format_size( $Tmp[All_Data_Length] );

			$Tables[] = $Tmp;
		}

		$CountAll[Data_free] = format_size( $CountAll[Data_free] );
		$CountAll[Index_length] = format_size( $CountAll[Index_length] );
		$CountAll[All_Data_Length] = format_size( $CountAll[All_Data_Length] );

		$Tpl->assign( 'Datas', $Tables );
		$Tpl->assign( 'CountAll', $CountAll );
		$Tpl->assign( 'Main', $Tpl->fetch( 'manage_tables.html' ) );
	}
	else if( $_GET[ac] == 'userlist' || $_GET[ac] == '' )
	{
		$Res = mysql_query( " select count(*) as count  from " . $TableList[users] );
		$Count = mysql_fetch_array( $Res, MYSQL_ASSOC );
		$DataCount = $Count[count];

		$PageSize = 20;
		if( $DataCount > 0 )
		{
			include_once ( './include.inc/page.inc.php' );
			$PageItems = MakePageItems ( $DataCount, $PageSize );
			$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
			$Tpl->assign( 'PageLinks', $PageLinks );
		}

		$Year = date( 'Y' );
		$Month = date( 'm' );
		$Day = date( 'j' );
		$DayStartTime = mktime(0, 0, 0, $Month, $Day, $Year);
		$Res = mysql_query( " select cu.logincount, cu.userid, cu.manager, cu.password, cu.site, cu.sitename, cu.sitedes, cu.sitetype, cu.qq, cu.email, cu.msn, cu.all_count, cu.all_count_ip, cdd.day_count as day_count, cdd.day_count_ip as day_count_ip   from " . $TableList[users] . " as cu
														left join " . $TableList[day_data] . " as cdd on cu.userid = cdd.userid and cdd.times = $DayStartTime
																			ORDER BY userid DESC LIMIT $PageItems[Offset], $PageSize " );

		while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
		{
			$Users[] = $Tmp;

		}

		$Tpl->assign( 'Datas', $Users );

		$Tpl->assign( 'Main', $Tpl->fetch( 'manage_userlist.html' ) );

	}
	else if( $_GET[ac] == 'delip' )
	{
			$Time = time();
			$Year = date( 'Y', $Time );
			$Month = date( 'm', $Time );
			$Day = date( 'j', $Time );
			$Week = date( 'w', $Time );
			$Hour = date('G', $Time );
			$DayStartTime = mktime(0, 0, 0, $Month, $Day, $Year);
			
			
			$Sql = "select count(*) as count from count_ip where time < $DayStartTime";
			$Res = mysql_query( $Sql );
			$Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC );
			$DelCount = $Tmp[count];

			
			
			$Sql = "delete from count_ip where time < $DayStartTime";
			$Res = mysql_query( $Sql );
			echo "<script>alert('ɾ�����({$DelCount})');location='manage.php';</script>";
	}





	$Tpl->assign( 'Title', '���� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', '����' );
	$Tpl->assign( 'QuickLink', "<a href=\"manage.php?ac=tables\">���ݿ�</a> <a href=\"manage.php?ac=userlist\">�û��б�</a> <a href=\"manage.php?ac=delip\">ɾ��������ϸ��¼</a>" );
	_out( $Tpl->fetch( 'main.html' )  );
?>