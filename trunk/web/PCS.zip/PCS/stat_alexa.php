<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once 'parse_site.php';
	global $website;
	Initialize( $_GET, array( 'Date_Year'=>'intval', 'Date_Month'=>'intval' ) );

	if( isset( $_GET[Date_Year] ) )
	{
		$MonthTime = mktime (0,0,0, isset( $_GET[Date_Month] ) ? intval( $_GET[Date_Month] ) : date('n'),1, isset( $_GET[Date_Year] ) ? intval( $_GET[Date_Year] ) : date('Y') );
	}
	else
	{
		$MonthTime = mktime (0,0,0,date("m"),1,date("Y"));

	}
	$Year = date( 'Y', $MonthTime );
	$Month = date( 'm', $MonthTime );

	//��ȡ����ͳ����Ϣ
	$EndTime = mktime (0,0,0,$Month+1,0,$Year );
	$Res = mysql_query( " select counts, times  from $TableList[alexa] where times <= $EndTime and times >= $MonthTime and website = '$website'"  );
	while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
	{
		$TmpDay = intval( date( 'd', $Tmp[times] ) );
		$Stat[$TmpDay] = intval( $Tmp[counts] );

		$CountAll += $Stat[$TmpDay];
		$MaxCount = $Stat[$TmpDay] > $MaxCount ? $Stat[$TmpDay] : $MaxCount;
	}

	$CountAll = $CountAll > 0 ? $CountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$DayLineCount = intval( $MaxCount / 5 );

	// 
	$MonthDayCount = date( 't', $MonthTime );
	for( $i = 1; $i <= $MonthDayCount; $i++ )
	{

		$DayPercent = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Stat[$i]/$CountAll ) * 100 );
		$DayPillarHeight = $Quotiety * $Stat[$i];
		$DayPillarHeight = $DayPillarHeight < 1 ? 1 : $DayPillarHeight;


		$AlexaData[$i] = array(
									'DayPercent' => $DayPercent,
									'DayPillarHeight' => $DayPillarHeight,
									'DayCount' => intval( $Stat[$i] ),
								);

		$WeekNum = date( 'w', mktime (0,0,0,date("m"),$i,date("Y")) );
		if( $WeekNum == 0 || $WeekNum == 6 )
		{
			$MonthDay[$i] = 1;
		}
		else
		{
			$MonthDay[$i] = 0;
		}
	}

	
	$Tpl->assign( 'PillarTdWidth', PILLAR_WIDTH/count($MonthDay)  );
	$Tpl->assign( 'PillarWidth', ( PILLAR_WIDTH/count($MonthDay) ) - 4  );
	$Tpl->assign( 'MonthDay', $MonthDay );
	$Tpl->assign( 'AlexaData', $AlexaData );
	$Tpl->assign( 'DayLineCount', $DayLineCount );

	$Tpl->assign( 'CountIpAll', $CountIpAll );
	$Tpl->assign( 'CountAll', $CountAll );
	//����ͳ����Ϣ��������

	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'DataTime', $MonthTime );

	$Tpl->assign( 'Main', $Tpl->fetch( 'stat_alexa.html' ) );

	$Tpl->assign( 'Title', 'Alexa������ - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', 'Alexa������' );
	_out( $Tpl->fetch( 'main.html' )  );

?> 
