<?
ob_start(); 
if(function_exists(session_cache_limiter))
{
	session_cache_limiter("private, must-revalidate"); 
}
?>
<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();

	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once 'parse_site.php';
	global $website;
	Initialize( $_POST, array( 'oldpassword'=>'strval', 'action'=>'strval', 'manager'=>'strval', 'password'=>'strval', 'repassword'=>'strval', 'sitename'=>'strval', 'website'=>'strval','site'=>'strval', 'sitetype'=>'strval', 'sitedes'=>'strval', 'email'=>'strval', 'qq'=>'strval', 'msn'=>'strval', 'register'=>'strval','newsite'=>'strval','id'=>'strval','actionp'=>'strval') );

	if( $_POST[action] == 'save' and  $_POST[newsite] == '')
	{
		$Res = mysql_query( "select manager, password from $TableList[users] where password !=''");
		$Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC );
		
		if( $_POST[oldpassword] == $Tmp[password] || md5( $_POST[oldpassword] ) == $Tmp[password] )
		{
		}
		else
		{
			echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--
				alert( '�������ԭ���벻��ȷ!' );
				history.back();
			//-->
			</SCRIPT>
			";
			exit;
		}
		if($_POST[actionp] != 'true')
		{
		if( $_POST[sitename] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ�����ֲ���Ϊ��\\n";
		}

		if( $_POST[website] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ����벻��Ϊ��\\n";
		}

		if( $_POST[site] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ����ַ����Ϊ��\\n";
		}

		if( $_POST[email] == '' )
		{
			$Error = true;
			$ErrMsg .= "Email��ַ����Ϊ��\\n";
		}
		}
		
		if( $Error )
		{
			echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--//
				alert( '����д����Ϣ�������´���      \\n========================\\n$ErrMsg' );
				history.back();
			//-->
			</SCRIPT>";
			exit;
		}


		

		if( $_POST[password] != '' && $_POST[password] == $_POST[repassword] and $_POST[actionp] == 'true')
		{
			$UpdateStr = " password = '" . md5( $_POST[password] ) . "' where password !='' ";
		}
		
		else
		{
			$UpdateStr = " site = '$_POST[site]', sitename = '$_POST[sitename]', website = '$_POST[website]', sitedes = '$_POST[sitedes]', sitetype = '$_POST[sitetype]', email = '$_POST[email]', qq = '$_POST[qq]', msn = '$_POST[msn]' where id = '$_POST[id]'";
		}
		$Sql = " update $TableList[users] set " . $UpdateStr . " ";
		mysql_query( $Sql );
		include_once "kxparse.php";
		global $website;
		$xmlsite=new kxparse("current_site.xml");
		$xmlsite->set_tag_text("site:siteStr","1:1",$_POST[website]);
		$xmlsite->set_tag_text("site:siteName","1:1",$_POST[sitename]);
		$xmlsite->set_tag_text("site:siteUrl","1:1",$_POST[site]);
		$xmlsite->save("current_site.xml");		
		echo "<SCRIPT LANGUAGE=\"JavaScript\">
		<!--
			location='html/index.htm';
		//-->
		</SCRIPT>";
		exit;
	}
	
	if( $_POST[action] == 'newsite' and $_POST[website] != "")
	{
		
		if( $_POST[sitename] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ�����ֲ���Ϊ��\\n";
		}

		if( $_POST[website] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ����벻��Ϊ��\\n";
		}

		if( $_POST[site] == '' )
		{
			$Error = true;
			$ErrMsg .= "վ����ַ����Ϊ��\\n";
		}

		if( $_POST[email] == '' )
		{
			$Error = true;
			$ErrMsg .= "Email��ַ����Ϊ��\\n";
		}

		if( $Error )
		{
			echo "<SCRIPT LANGUAGE=\"JavaScript\">
			<!--
				alert( '����д����Ϣ�������´���      \\n========================\\n$ErrMsg' );
				history.back(-1);
			//-->
			</SCRIPT>";
			exit;
		}
		mysql_query("insert into $TableList[users](site,sitename,website,sitedes,sitetype,qq,email,msn) values('$_POST[site]','$_POST[sitename]','$_POST[website]','$_POST[sitedes]','$_POST[sitetype]','$_POST[qq]','$_POST[email]','$_POST[msn]')");
		include_once "kxparse.php";
		global $website;
		$xmlsite=new kxparse("current_site.xml");
		$xmlsite->set_tag_text("site:siteStr","1:1",$_POST[website]);
		$xmlsite->set_tag_text("site:siteName","1:1",$_POST[sitename]);
		$xmlsite->set_tag_text("site:siteUrl","1:1",$_POST[site]);
		$xmlsite->save("current_site.xml");		
		echo "<SCRIPT LANGUAGE=\"JavaScript\">
		<!--
			location='html/index.htm';
		//-->
		</SCRIPT>";
		exit;
	}

	$Res = mysql_query( " select * from $TableList[users] where website = '$website'" );
	$UserData = mysql_fetch_array( $Res, MYSQL_ASSOC );
	if( $_POST[newsite] == '' )
	{
		$Tpl->assign( 'UserData', $UserData );		
	}
	else
	{
		$Tpl->assign( 'actionnew', 'newsite' );
	}
	$Tpl->assign( 'Main', $Tpl->fetch( 'profile.html' ) );

	$Tpl->assign( 'Title', '�޸����� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', '�޸�����' );
	$Tpl->assign( 'QuickLink', "<a href=\"main.php\">����</a>" );

	_out( $Tpl->fetch( 'main.html' )  );
?>