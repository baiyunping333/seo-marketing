<?
session_start();
include("../../config/config.php");
include("../../config/adodb.php");
$new_admin=$new_admin;
global $conn;
$tables_priv="chepai_tables_priv";
$_session['ecard_session_username']=$HTTP_SESSION_VARS["ecard_session_username"];
$username=$_session['ecard_session_username'];
if(!$_session['ecard_session_username']){
echo "<meta http-equiv=refresh content=0;URL=../login/relogin.php>";exit;}
$user_result=$conn->Execute("select * from $new_admin where username='$username'");
$user_row=$user_result->FetchRow();
$admingroup=$user_row[bodyid];
$loginbuildcode=$user_row[chargebuild];
$chargebuild=$user_row[chargebuild];
$chinesename=$user_row[name];

$result=$conn->Execute("select * from $tables_priv where UserID='$admingroup'");
while($row=$result->FetchRow())
{   $tablenameid=$row[Table_name];
	$query_table_name="select * from $dbtable where id='$tablenameid' limit 1";
	$result_table_name=$conn->Execute($query_table_name);
	$row_table_name=$result_table_name->FetchRow();
	$tablename=$row_table_name[table_name];
	$table_name=$row_table_name[table_name];	
	$priv_array[$tablenameid]=$tablenameid;
	//echo $tablenameid;
	//echo $tablenameid.":";
	$priv_right=explode(",",$row[Table_priv]);
	for($i=0;$i<count($priv_right);$i++)
	{	
		$priv_right_str=$priv_right[$i];
		
		$table_column_priv[$table_name][$priv_right_str]=$priv_right_str;
	
	}
	

}
?>