<? require("../../config/config.php"); ?>
<? require("../../config/functions.php"); ?>
<? $word=$HTTP_GET_VARS[word];?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�û���¼</title>
<link href="../../config/style.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE="JavaScript"> 

function defaultset()
{
	document.form1.loginusername.focus();
}
function checknull()
{
	if(document.form1.loginusername.value=='')
		{
		alert("�������û���");
		document.form1.loginusername.focus();
		return false;
		}
    else if(document.form1.loginpassword.value=='')
		{
		alert("����������");
		document.form1.loginpassword.focus();
		return false;
		}
	else{
		window.form1.submit();
		}

}
function onkeypressed()
{
	if(event.keyCode==13) //�س���
	{
		checknull();
	}
}
</SCRIPT>
</head>
<body bgcolor="#006699" leftmargin="0" topmargin="0" onload="defaultset()" onkeypress="onkeypressed()">
<br>
<br>
<br>
<br>
<br>
<form name="form1" method="post" action="../login/checkpass.php">
  <input name="check_subed" type="hidden" id="check_subed" value="true">
  <table width="416" height="254" border="0" align="center" cellpadding="1" cellspacing="0" background="images/2004.jpg">
    <tr> 
      <td valign="bottom" background="2004.jpg"><table width="100%" height="46" border="0" cellpadding="1" cellspacing="0">
          <tr> 
            <td width="123" rowspan="2" align="right"><div align="center"><font color="#FFFFFF" size="3"></font></div></td>
            <td width="83" align="right"> <p class="font2"><strong><font color="#FFFFFF">�û����� 
                </font></strong></td>
            <td width="123"> <input type="text" name="loginusername" size="16" class="font2" id=1> 
            </td>
            <td width="77" height="20" rowspan="2"> <div align="center"><img src="login.gif" onclick="checknull()" style="CURSOR: hand" > 
              </div></td>
          </tr>
          <tr> 
            <td width="83" align="right"> <p class="font2"><strong><font color="#FFFFFF">�ܡ��룺 
                </font></strong></td>
            <td width="123"> <input type="password" name="loginpassword" size="16"
      class="font2" id=2> </td>
          </tr>
        </table></td>
    </tr>
  </table>

</form>
</body>
</html>