<?
session_start();
//session_register($GroupID."_passed");
session_register("ecard_session_username");
require("../../config/config.php"); 
include("../../config/adodb.php");
global $conn;
$loginpassword=$HTTP_POST_VARS[loginpassword];
$loginusername=$HTTP_POST_VARS[loginusername];
$check_subed=$HTTP_POST_VARS[check_subed];
$loginmemory=$HTTP_POST_VARS[loginmemory];



if($check_subed=="true"){


	$loginusername=str_replace("'","''",$loginusername);
	$loginpassword=str_replace("'","''",$loginpassword);

	$sql="select * from ".$UserTableName." where ".$UserNameFeild."='" . $loginusername .  "' and " . $PassWordFeild . "='" . $loginpassword . "'";
	$checkpassresult=$conn->Execute($sql);
	
	if($checkpassresult->RecordCount() >= 1)
		{
		$row=$checkpassresult->FetchRow();
		$uid=$row["id"];
		$ecard_session_username=$loginusername;
		$session_password=$row["password"];
		echo "<meta http-equiv=refresh content=0;URL=../html/index.htm>";
		}
		

		else 
			{
		     $word="�û������������,��ȷ��";
			 echo "<meta http-equiv=refresh content=0;URL=../login/relogin.php?word=$word>";
			}

}