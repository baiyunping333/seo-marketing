<? require("../../config/config.php"); ?>
<? require("../../config/functions.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�û���¼</title>
<link href="../../config/style.css" rel="stylesheet" type="text/css">
</head>
<body topmargin="0" leftmargin="0" bgcolor="#006699">
<br>
<br>
<br>
<br>
<table width="285" border="0" align="center">
  <tr> 
    <td width="277"> <div align="center">
        <p><font color="#FFFFFF"><strong>����Ȩ�޲���</strong></font></p>
        <p><A  href="javascript:window.history.go(-1)"><FONT color=ffffff>�뷵��</FONT></A></p>
      </div></td>
  </tr>
</table>
</body>
</html>