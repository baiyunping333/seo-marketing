<? require("../../config/config.php");
   include("../../config/functions.php");
   $table=$user_right;
   $online=$online;
   $operation=$operation;
?>
<?  
	session_start();
	$_session['session_username']=$HTTP_SESSION_VARS[session_username];
	admin_is_line_del($online,$_session['session_username']);
	admin_loginout($table,$_session['session_username'],$rtable);
	session_destroy();

?>
<html>
<head>
<title>�˳���¼</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link href="../../config/style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#006699">

<p>&nbsp;</p>
<p align="center"><font color="#FFFFFF">�˳���¼�ɹ�!</font></p>
<meta http-equiv=refresh content=0;URL=../login/relogin.php> 
</body>
</html>