<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>PCS��վ��������Ϣͳ��ϵͳ</TITLE>


<META http-equiv=Content-Type content="text/html; charset=gb2312"><LINK 
href="style_menu.css" rel=stylesheet>
<STYLE type=text/css>A:link {
	COLOR: #000000; TEXT-DECORATION: none
}
A:visited {
	COLOR: #000000; TEXT-DECORATION: none
}
A:active {
	COLOR: #3333ff; TEXT-DECORATION: none
}
A:hover {
	COLOR: #ff0000; TEXT-DECORATION: none
}
</STYLE>

<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>
<BODY bgColor=#d9e8ff leftMargin=0 topMargin=3 rightMargin=0 marginwidth="0" 
marginheight="0"><!-- OA����ʼ-->
<TABLE class=small cellSpacing=3 cellPadding=0 width="180" align=center 
border=0>
  <TBODY>
  <TR>
    <TD> 
      <!-- OA������ -->
      <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="16"><IMG class=outline id=MENU_44 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
            <TD width="19"><img src="images/sms.gif" width="16" height="16"></TD>
            <TD width="71" colSpan=3><A onclick=MENU_44.click(); 
            href="menu.php#A">&nbsp;ͳ��ժҪ</A> </TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small id=MENU_44d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="146"> <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../main.php')" 
                        href="menu.php#A">&nbsp;ͳ�Ƹſ�</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                      <TD width="80" colSpan=2><A 
                        href="../report.php" target="_blank" >&nbsp;���ٱ���</A> 
                      </TD>
                    </TR>
                  </TBODY>
                </TABLE>
				 <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                      <TD width="80" colSpan=2><A onclick="openURL('../myreport/')" 
                        href="menu.php#A">&nbsp;ÿ�ܱ���</A> </TD>
                    </TR>
                  </TBODY>
                </TABLE>
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../stat_day.php')" 
                        href="menu.php#A">&nbsp;ʱ��ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../stat_month.php')" 
                        href="menu.php#A">&nbsp;�ն�ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>                  
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="79" colSpan=2><A onclick="openURL('../stat_year.php')" 
                        href="menu.php#A">&nbsp;�¶η���</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="81" colSpan=2><A onclick="openURL('../show_today.php')" 
                        href="menu.php#A">&nbsp;������ϸ</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="79" colSpan=2><A onclick="openURL('../alexa.php')" 
                        href="menu.php#A">&nbsp;Alexa����</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="79" colSpan=2><A onclick="openURL('../stat_alexa.php')" 
                        href="menu.php#A">&nbsp;Alexa������</A> </TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
      </TABLE>
      <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
          <TBODY>
            <TR> 
              <TD width="16"><IMG class=outline id=MENU_11 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
              
            <TD width="19"><img src="images/dot_12.gif" width="19" height="16"></TD>
              
            <TD width="71" colSpan=3><A onclick=MENU_11.click(); 
            href="menu.php#A">&nbsp;��������</A></TD>
            </TR>
          </TBODY>
        </TABLE>
      <TABLE class=small id=MENU_11d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="146"> <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../return.php')" 
                        href="menu.php#A">&nbsp;��ͷ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../referer.php')" 
                        href="menu.php#A">&nbsp;��Դͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../page.php')" 
                        href="menu.php#A">&nbsp;�ܷ�ҳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../area.php')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../language.php')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../timezone.php')" 
                        href="menu.php#A">&nbsp;ʱ��ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../screen.php')" 
                        href="menu.php#A">&nbsp;��Ļͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../soft.php')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="84" colSpan=2><A onclick="openURL('../referer.php?engine=true')" 
                        href="menu.php#A">&nbsp;��������</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE width="131" border=0 cellPadding=0 cellSpacing=0 class=small>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../keyword.php')" 
                        href="menu.php#A">&nbsp;�ؼ���ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="16"><IMG class=outline id=MENU_12 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
            <TD width="19"><img src="images/oldboard.gif" width="15" height="14"></TD>
            <TD width="71" colSpan=3><A onclick=MENU_12.click(); 
            href="menu.php#A">&nbsp;��������</A></TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small id=MENU_12d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="146"> <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../return.php?type=2')" 
                        href="menu.php#A">&nbsp;��ͷ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../referer.php?type=2')" 
                        href="menu.php#A">&nbsp;��Դͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../page.php?type=2')" 
                        href="menu.php#A">&nbsp;�ܷ�ҳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../area.php?type=2')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../language.php?type=2')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../timezone.php?type=2')" 
                        href="menu.php#A">&nbsp;ʱ��ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../screen.php?type=2')" 
                        href="menu.php#A">&nbsp;��Ļͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../soft.php?type=2')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="84" colSpan=2><A onclick="openURL('../referer.php?engine=true&type=2')" 
                        href="menu.php#A">&nbsp;��������</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE width="131" border=0 cellPadding=0 cellSpacing=0 class=small>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../keyword.php?type=2')" 
                        href="menu.php#A">&nbsp;�ؼ���ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="16"><IMG class=outline id=MENU_13 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
            <TD width="19"><img src="images/file_folder.gif" width="16" height="16"></TD>
            <TD width="71" colSpan=3><A onclick=MENU_13.click(); 
            href="menu.php#A">&nbsp;��������</A></TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small id=MENU_13d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="146"> <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../return.php?type=0')" 
                        href="menu.php#A">&nbsp;��ͷ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../referer.php?type=0')" 
                        href="menu.php#A">&nbsp;��Դͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../page.php?type=0')" 
                        href="menu.php#A">&nbsp;�ܷ�ҳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../area.php?type=0')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../language.php?type=0')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../timezone.php?type=0')" 
                        href="menu.php#A">&nbsp;ʱ��ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../screen.php?type=0')" 
                        href="menu.php#A">&nbsp;��Ļͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../soft.php?type=0')" 
                        href="menu.php#A">&nbsp;����ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="84" colSpan=2><A onclick="openURL('../referer.php?engine=true&type=0')" 
                        href="menu.php#A">&nbsp;��������</A> </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE width="131" border=0 cellPadding=0 cellSpacing=0 class=small>
                <TBODY>
                  <TR> 
                    <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                    <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                    <TD width="19"><img src="images/polg1(1).gif" width="20" height="16"></TD>
                    <TD width="80" colSpan=2><A onclick="openURL('../keyword.php?type=0')" 
                        href="menu.php#A">&nbsp;�ؼ���ͳ��</A> </TD>
                  </TR>
                </TBODY>
              </TABLE></TD>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
          <TR> 
            <TD width="16"><IMG class=outline id=MENU_15 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
            <TD width="19"><img src="images/home_icon.gif" width="16" height="16"></TD>
              <TD width="121" colSpan=3><A onclick=MENU_15.click(); 
            href="menu.php#A">&nbsp;ͳ��վ��</A></TD>
          </TR>
        </TBODY>
      </TABLE>
        <TABLE class=small id=MENU_15d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
          <TBODY>
            <TR> 
              <TD width="183"> 
                <? 	
			include_once '../include.inc/config.inc.php';
//			include_once 'session.php';
			include_once '../include.inc/conn.db.inc.php';
//			include_once './include.inc/global.inc.php';
//			include_once './include.inc/tpl.inc.php';
//			include_once './include.inc/function.php';
//echo $TableList[users];
			$rs = mysql_query("select sitename,website,site from $TableList[users] where password = ''");
			while($row = mysql_fetch_array($rs))
			{
			?>
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/polg1(1).gif" width="19" height="16"></TD>
                      <TD width="131" colSpan=2><A onclick="openURL('../website.php?website=<?=$row[website]?>&sitename=<?=$row[sitename]?>&siteadd=<?=urlencode($row[site])?>')" 
                        href="menu.php#A">&nbsp;<?=$row[sitename]?></A> </TD>
                    </TR>
                  </TBODY>
                </TABLE>
                <? }?>
        </TABLE>
        <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
          <TBODY>
            <TR> 
              <TD width="16"><IMG class=outline id=MENU_14 style="CURSOR: hand" 
            src="images/tree_plus.gif"></TD>
              <TD width="19"><img src="images/sms_type6.gif" width="16" height="16"></TD>
              <TD width="71" colSpan=3><A onclick=MENU_14.click(); 
            href="menu.php#A">&nbsp;����Աѡ��</A></TD>
            </TR>
          </TBODY>
        </TABLE>
        <TABLE class=small id=MENU_14d style="DISPLAY: none" cellSpacing=0 
      cellPadding=0 border=0>
          <TBODY>
            <TR> 
              <TD width="146"> <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                      <TD width="80" colSpan=2><A onclick="openURL('../all_site_code.php')" 
                        href="menu.php#A">&nbsp;ͳ�ƴ���</A> </TD>
                    </TR>
                  </TBODY>
                </TABLE>
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                      <TD width="80" colSpan=2><A onclick="openURL('../manage_all_site.php')" 
                        href="menu.php#A">&nbsp;վ�����</A> </TD>
                    </TR>
                  </TBODY>
                </TABLE>
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                      <TD width="80" colSpan=2><A onclick="openURL('../profile.php')" 
                        href="menu.php#A">&nbsp;վ����Ϣ</A> 
                      </TD>
                    </TR>
                  </TBODY>
                </TABLE>
               
                <TABLE class=small cellSpacing=0 cellPadding=0 border=0>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/member_face.gif" width="19" height="16"></TD>
                      <TD width="80" colSpan=2><A onclick="openURL('../checkupdate.php')" 
                        href="menu.php#A">&nbsp;������</A> </TD>
                    </TR>
                  </TBODY>
                </TABLE>
                <TABLE width="131" border=0 cellPadding=0 cellSpacing=0 class=small>
                  <TBODY>
                    <TR> 
                      <TD width="16"><IMG src="images/tree_line.gif" border=0></TD>
                      <TD width="16"><IMG src="images/tree_blank.gif"></TD>
                      <TD width="19"><img src="images/e1brep.gif" width="17" height="12"></TD>
                      <TD width="80" colSpan=2><A onclick="javascript:if(confirm('ȷʵҪ�˳�������?')) openURL('../login.php?logout')" 
                        href="menu.php#A">&nbsp;��ȫ�˳�</A> </TD>
                    </TR>
                  </TBODY>
                </TABLE></TD>
            </TR>
          </TBODY>
        </TABLE></TD>
          </TR>
        </TBODY>
      </TABLE>
      <SCRIPT language=JavaScript>
var openedid;
var openedid_ft;
var flag=0,sflag=0;

function clickHandler()
{
	var targetid,srcelement,targetelement;
	var strbuf;
	srcelement=window.event.srcElement;

	//-------- ��������չ����������ť---------
	if(srcelement.className=="outline")
	{
		targetid=srcelement.id+"d";
		targetelement=document.all(targetid);
		if (targetelement.style.display=="none")
		{
			targetelement.style.display='';
			strbuf=srcelement.src;
			if(strbuf.indexOf("plus.gif")>-1)
				srcelement.src="./images/tree_minus.gif";
			else
				srcelement.src="./images/tree_minusl.gif";
		}
		else
		{
			targetelement.style.display="none";
			strbuf=srcelement.src;
			if(strbuf.indexOf("minus.gif")>-1)
				srcelement.src="./images/tree_plus.gif";
			else
				srcelement.src="./images/tree_plusl.gif";
		}
	}
}

document.onclick = clickHandler;

function openURL(URL)
{
    parent.parent.main.location=URL;
}

</SCRIPT></BODY></HTML></TD>
    </TR></TBODY></TABLE></BODY></HTML>

