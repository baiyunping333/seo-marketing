<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>PCS��վ��������Ϣͳ��ϵͳ</title>
<link href="../../config/style.css" rel="stylesheet" type="text/css">
</head>

<body  class=body>
<table width="100%" height="222" border="0" cellpadding="1" cellspacing="2">
  <tr> 
    <td width="100%"><div align="center"><font color="#33FF00" size="4"><strong>PCS��վ��������Ϣͳ��ϵͳ<BR><A href=http://www.sndg.net target=_blank><font color="#33FF00" size="4">SNDG��ҵ�Ŷ�</font></a></strong></font></div></td>
  </tr>
</table>
</body>
</html>
