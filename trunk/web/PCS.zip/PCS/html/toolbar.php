
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--TOOLBAR_EXEMPT--><HTML><HEAD><TITLE>PCS��վ��������Ϣͳ��ϵͳ</TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312">
<META content="" name=Description>
<META content=all name=Robots>
<META content="" name=Keywords>
<META content=en-us name=MS.LOCALE>
<script Language=JavaScript>
window.setTimeout('this.location.reload();',60000000);

var OA_TIME = new Date();

function timeview()
{
  timestr=OA_TIME.toLocaleString();
  timestr=timestr.substr(timestr.indexOf(" "));
  time_area.innerHTML = timestr;
  OA_TIME.setSeconds(OA_TIME.getSeconds()+1);
  window.setTimeout( "timeview()", 1000 );
}
</script>
<LINK href="template_css.css" type=text/css rel=stylesheet>

<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>
<BODY text=#000000 bgColor=#ffffff leftMargin=0 topMargin=0 MARGINWIDTH="0" 
MARGINHEIGHT="0">
<DIV id=msviMasthead 
xmlns:Utility="http://www.microsoft.com/MSCOM/VisualIdentity/Utility"> 
  <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#336699">
    <tr>
      <td width="46%" background="header_text.png">&nbsp;</td>
      <td width="54%" bgcolor="#336699">
<div align="right"><img src="header_blue.jpg" width="552" height="38"></div></td>
    </tr>
  </table>
  <DIV id=msviLocalToolbar> 
  <?
  //����xml���ļ�������xml�ļ�
include_once "../kxparse.php";
global $website;
$xmlsite=new kxparse("../current_site.xml");
$siteName = $xmlsite->get_tag_text("site:siteName","1:1");
  ?>
    <table width="79%" height="18" border="0" cellpadding="0" cellspacing="0">
      <tr> 
        <td width="21%" height="18"><a href="#" onclick="parent.parent.fstMain.cols='190,*'"><img src="images/synctoc1.gif" width="65" height="18" border=0 alt="չ��"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td width="50%"><strong>�û�:</strong>&nbsp;&nbsp;����,&nbsp;&nbsp;&nbsp;&nbsp;<u>����Ա</u><strong>&nbsp;&nbsp;&nbsp;&nbsp;��ǰͳ��վ��:<font color=red>&nbsp;<?=$siteName?></font></strong> 
        </td>
        <td width="29%" align="left" ><strong>
          <div id="jnkc"> </div>
          </strong> <script>setInterval("jnkc.innerHTML=new Date().toLocaleString()+'      ����'+'��һ����������'.charAt(new Date().getDay());",1000);
</script> </td>
      </tr>
    </table>
  </DIV>
</DIV></BODY></HTML>
