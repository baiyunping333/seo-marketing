<?php

$data = array(
    'port'      =>      '3306',
    'host'      =>      'localhost',
    'name'      =>      'test',
    'user'      =>      'root',
    'pass'      =>      'micronsky.net'
);

?>