-- SQL Dump
-- Backup script written by Mark Wraith �� ����ϸ�� ������

--
-- Table structure for table 'count_ip'
--

CREATE TABLE count_ip (
  id int(10) unsigned NOT NULL auto_increment,
  ip varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  pageurl varchar(255) NOT NULL default '',
  pagefrom varchar(255) NOT NULL default '',
  language varchar(16) NOT NULL default '',
  color varchar(4) NOT NULL default '',
  screensize varchar(20) NOT NULL default '',
  http_user_agent varchar(255) NOT NULL default '',
  pagefromsite varchar(255) NOT NULL default '',
  keyword varchar(255) NOT NULL default '',
  country varchar(32) NOT NULL default '',
  address varchar(255) NOT NULL default '',
  alexatool int(11) NOT NULL default '0',
  timezone int(11) NOT NULL default '0',
  firsttime int(11) NOT NULL default '0',
  lasttime int(11) NOT NULL default '0',
  system varchar(32) NOT NULL default '',
  browser varchar(32) NOT NULL default '',
  todayfirst int(11) NOT NULL default '0',
  return int(11) NOT NULL default '0',
  website varchar(50) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY pagefromsite (pagefromsite),
  KEY keyword (keyword),
  KEY ip (ip),
  KEY time (time),
  KEY country (country),
  KEY userid (time,alexatool),
  KEY timezone (timezone)
) TYPE=MyISAM;



--
-- Dumping data for table 'count_ip'
--



--
-- Table structure for table 'count_ip'
--

CREATE TABLE count_ip (
  id int(10) unsigned NOT NULL auto_increment,
  ip varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  pageurl varchar(255) NOT NULL default '',
  pagefrom varchar(255) NOT NULL default '',
  language varchar(16) NOT NULL default '',
  color varchar(4) NOT NULL default '',
  screensize varchar(20) NOT NULL default '',
  http_user_agent varchar(255) NOT NULL default '',
  pagefromsite varchar(255) NOT NULL default '',
  keyword varchar(255) NOT NULL default '',
  country varchar(32) NOT NULL default '',
  address varchar(255) NOT NULL default '',
  alexatool int(11) NOT NULL default '0',
  timezone int(11) NOT NULL default '0',
  firsttime int(11) NOT NULL default '0',
  lasttime int(11) NOT NULL default '0',
  system varchar(32) NOT NULL default '',
  browser varchar(32) NOT NULL default '',
  todayfirst int(11) NOT NULL default '0',
  return int(11) NOT NULL default '0',
  website varchar(50) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY pagefromsite (pagefromsite),
  KEY keyword (keyword),
  KEY ip (ip),
  KEY time (time),
  KEY country (country),
  KEY userid (time,alexatool),
  KEY timezone (timezone)
) TYPE=MyISAM;



--
-- Dumping data for table 'count_ip'
--



--
-- Table structure for table 'count_ip'
--

CREATE TABLE count_ip (
  id int(10) unsigned NOT NULL auto_increment,
  ip varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  pageurl varchar(255) NOT NULL default '',
  pagefrom varchar(255) NOT NULL default '',
  language varchar(16) NOT NULL default '',
  color varchar(4) NOT NULL default '',
  screensize varchar(20) NOT NULL default '',
  http_user_agent varchar(255) NOT NULL default '',
  pagefromsite varchar(255) NOT NULL default '',
  keyword varchar(255) NOT NULL default '',
  country varchar(32) NOT NULL default '',
  address varchar(255) NOT NULL default '',
  alexatool int(11) NOT NULL default '0',
  timezone int(11) NOT NULL default '0',
  firsttime int(11) NOT NULL default '0',
  lasttime int(11) NOT NULL default '0',
  system varchar(32) NOT NULL default '',
  browser varchar(32) NOT NULL default '',
  todayfirst int(11) NOT NULL default '0',
  return int(11) NOT NULL default '0',
  website varchar(50) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY pagefromsite (pagefromsite),
  KEY keyword (keyword),
  KEY ip (ip),
  KEY time (time),
  KEY country (country),
  KEY userid (time,alexatool),
  KEY timezone (timezone)
) TYPE=MyISAM;



--
-- Dumping data for table 'count_ip'
--



--
-- Table structure for table 'count_ip'
--

CREATE TABLE count_ip (
  id int(10) unsigned NOT NULL auto_increment,
  ip varchar(32) NOT NULL default '',
  time int(11) NOT NULL default '0',
  pageurl varchar(255) NOT NULL default '',
  pagefrom varchar(255) NOT NULL default '',
  language varchar(16) NOT NULL default '',
  color varchar(4) NOT NULL default '',
  screensize varchar(20) NOT NULL default '',
  http_user_agent varchar(255) NOT NULL default '',
  pagefromsite varchar(255) NOT NULL default '',
  keyword varchar(255) NOT NULL default '',
  country varchar(32) NOT NULL default '',
  address varchar(255) NOT NULL default '',
  alexatool int(11) NOT NULL default '0',
  timezone int(11) NOT NULL default '0',
  firsttime int(11) NOT NULL default '0',
  lasttime int(11) NOT NULL default '0',
  system varchar(32) NOT NULL default '',
  browser varchar(32) NOT NULL default '',
  todayfirst int(11) NOT NULL default '0',
  return int(11) NOT NULL default '0',
  website varchar(50) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY pagefromsite (pagefromsite),
  KEY keyword (keyword),
  KEY ip (ip),
  KEY time (time),
  KEY country (country),
  KEY userid (time,alexatool),
  KEY timezone (timezone)
) TYPE=MyISAM;



--
-- Dumping data for table 'count_ip'
--

