<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>֣�ݴ�ѧ����˹ѧԺ2005-2006ѧ���һѧ��ѧ��������</title>
<link href="style.css" rel="stylesheet" type="text/css">

<body topmargin="10" >
<object id="factory" style="display:none" viewastext classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="http://www.meadroid.com/scriptx/ScriptX.cab#Version=5,60,0,360"></object>

<script defer>

function window.onload() {

  factory.printing.header = ""

  factory.printing.footer = " &bӢ��(��)&b��&pҳ/��&Pҳ"

  factory.printing.leftMargin = 0.6

  factory.printing.topMargin = 0.3

  factory.printing.rightMargin = 0.6

  factory.printing.bottomMargin = 0.3
  
  factory.printing.portrait=false

  }

</script>
</head>

<body onbeforeprint="printsub.style.display='none';" onafterprint="printsub.style.display='';">
<table width="1000" border="0" align="center" cellpadding="1" cellspacing="0" >
  <tr> 
    <td width="1017"><table width="1000" border="0" cellspacing="0" cellpadding="1">
        <tr> 
          <td ><div align="center"> 
              <H1>֣�ݴ�ѧ����˹ѧԺ2005-2006ѧ���һѧ��ѧ��������</H1>
            </div></td>
        </tr>
        <tr> 
          <td><div align="center"> 
              <h2>FIRST SEMESTER STUDNET ROSTER OF YEAR 2005-2006</h2>
            </div></td>
        </tr>
        <tr> 
          <td><div align="center"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="1" class=table1>
                <tr > 
                  <td width="200">ϵ��(<strong>DPT</strong>)���������ѧ</td>
                  <td width="200">����(<strong>Grade</strong>)��2003��</td>
                  <td width="200">רҵ(<strong>Major</strong>)�� Ӣ��(��)</td>
                  <td width="200">�༶(<strong>Class</strong>)��(1)</td>
                  <td width="200">
<table width="100%" border="0" cellspacing="0" cellpadding="1">
                      <tr> 
                        <td>��(<strong>Y</strong>)</td>
                        <td>��(<strong>M</strong>)</td>
                        <td>��(<strong>D</strong>)</td>
                      </tr>
                    </table></td>
                </tr>
              </table>
            </div></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td>&nbsp;
      <div align="right"><input type=button value=ҳ������ onclick="factory.printing.PageSetup()"> 
<input type=button value=��ӡԤ�� onclick="factory.printing.Preview()">         <input type=button name=printsub value="��ӡ��ҳ" onclick="window.print();">
      </div></td>
  </tr>
</table>
</body>
</html>
