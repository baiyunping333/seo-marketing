<?
$file_name="toexcel.csv";
$file_dir="./";
$file=fopen($file_dir.$file_name,"r");
Header("Content-type: application/octet-stream");
Header("Accept-Ranges: bytes");
Header("Accept-Length: ".filesize($file_dir . $file_name));
Header("Content-Disposition: attachment; filename=" . $file_name);
echo fread($file,filesize($file_dir.$file_name));
fclose($file);
?>