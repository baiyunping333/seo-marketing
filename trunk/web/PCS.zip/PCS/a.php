<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>PCS��վ��������Ϣͳ��ϵͳ�������շ�����ϸ����</title>
<link href="print.css" rel="stylesheet" type="text/css">

<body topmargin="10" >
<object id="factory" style="display:none" viewastext classid="clsid:1663ed61-23eb-11d2-b92f-008048fdd814" codebase="tools/cab/ScriptX.cab#Version=5,60,0,360"></object>
<script defer>
function window.onload() {

  factory.printing.header = ""

  factory.printing.footer = " &bӢ��(��)&b��&pҳ/��&Pҳ"

  factory.printing.leftMargin = 0.6

  factory.printing.topMargin = 0.3

  factory.printing.rightMargin = 0.6

  factory.printing.bottomMargin = 0.3
  
  factory.printing.portrait=false

  }

</script>
</head>
<body onbeforeprint="printsub.style.display='none';" onafterprint="printsub.style.display='';">
<table width="1000" border="0" align="center" cellpadding="1" cellspacing="0" >
  <tr> 
    <td width="1000"><table width="1000" border="0" cellspacing="0" cellpadding="1">
        <tr> 
          <td ><div align="center"> 
              <H1>PCS��վ��������Ϣͳ��ϵͳ�������շ�����ϸ����</H1>
            </div></td>
        </tr>
        <tr> 
          <td><div align="center"> 
            </div></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="1000" border="0" cellspacing="0" cellpadding="1" class=tabp>
 <tr> 
                  <td width="200" class=td><div align="center"><strong>����ʱ��</strong></div></td>
                  <td width="120" class=td><div align="center"><strong>����IP</strong></div></td>
                  <td width="120" class=td><div align="center"><strong>����</strong></div></td>
                  <td width="280" class=td><div align="center"><strong>����ҳ</strong></div></td>
                  <td width="280" class=td><div align="center"><strong>��·ҳ</strong></div></td>
                </tr>
<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once './session.php';
	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	global $website;
	$Year = date( 'Y' );
	$Month = date( 'm' );
	$Day = date( 'd' );
	$StartTime = mktime (0,0,0,$Month,$Day,$Year );
	$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );	
	$Res = mysql_query( " select ip,time,pageurl,pagefrom,country,address  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and `website` = '$website' ORDER BY `time` DESC " );

	$loop=0;
	$page_max_num=25;
	$page_now_num=0;
while($Tmp = mysql_fetch_array($Res))
  {	
	$time = date("Y-m-d H:i:s",$Tmp['time']);
	$page_now_num++;//��¼����1
	echo "<tr >\n";
    echo "    <td width=\"200\" class=td>&nbsp;".$time."</td>\n";
    echo "    <td width=\"120\" class=td>&nbsp;".$Tmp[ip]."</td>\n";
    echo "    <td width=\"120\" class=td>&nbsp;".$Tmp[country].$Tmp[address]."</td>\n";
    echo "    <td width=\"280\" class=td>&nbsp;".$Tmp[pageurl]."</td>\n";
    echo "    <td width=\"280\" class=td>&nbsp;".$Tmp[pagefrom]."</td>\n";
    echo "</tr>\n";


	if(($page_now_num%$page_max_num)==0)//�жϸ�ҳ�ļ�¼�����������25�����ҳ
	  {
		?>
		  <tr> 
    <td width="1000"><table width="1000" border="0" cellspacing="0" cellpadding="1">
        <tr> 
          <td ><div align="center"> 
              <H1>PCS��վ��������Ϣͳ��ϵͳ�������շ�����ϸ����</H1>
            </div></td>
        </tr>
        <tr> 
          <td><div align="center"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="1" class=table1>
                <tr > 
                  <td width="200">����ʱ��</td>
                  <td width="200">����IP</td>
                  <td width="200">����</td>
                  <td width="200">����ҳ</td>
                  <td width="200">��·ҳ</td>
                </tr>
              </table>
            </div></td>
        </tr>
      </table>
    </td>
  </tr>
		<?
	  }
  }
  ?>
  
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td>&nbsp;
      <div align="right"><input type=button value=ҳ������ onclick="factory.printing.PageSetup()"> 
<input type=button value=��ӡԤ�� onclick="factory.printing.Preview()">         <input type=button name=printsub value="��ӡ��ҳ" onclick="window.print();">
      </div></td>
  </tr>
</table>
</body>
</html>
