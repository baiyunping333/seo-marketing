<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once './parse_site.php';
	global $website;
	Initialize( $_GET, array( 'Date_Year'=>'intval', 'Date_Month'=>'intval', 'Date_Day'=>'intval' ) );
	include_once 'initmenu.php';
	if( isset( $_GET[Date_Year] ) )
	{
		$Year = isset( $_GET[Date_Year] ) ? intval( $_GET[Date_Year] ) : date(Y);
		$Month = isset( $_GET[Date_Month] ) ? intval( $_GET[Date_Month] ) : date(n);
		$Day = isset( $_GET[Date_Day] ) ? intval( $_GET[Date_Day] ) : date(d);
		$DataTime = mktime (0,0,0,$Month,$Day,$Year);
	}
	else
	{
		$DataTime = mktime (0,0,0,date("m"),date("d"),date("Y"));
		$Year = date( 'Y', $DataTime );
		$Month = date( 'm', $DataTime );
		$Day = date( 'd', $DataTime );
	}
	$Week = date( 'w', $DataTime );
 

	//��ȡ����ͳ����Ϣ
	$Res = mysql_query( " select * from $TableList[day_data] where times = $DataTime and  website = '$website'" );
	$Row = mysql_fetch_array( $Res, MYSQL_ASSOC );

	$MaxCount = 0;
	for( $i = 0; $i < 24; $i++ )
	{
		$CountIpAll += $Row["hourip$i"];
		$CountAll += $Row["hour$i"];
		$MaxCount = $Row["hour$i"] > $MaxCount ? $Row["hour$i"] : $MaxCount;
	}

	$CountIpAll = $CountIpAll > 0 ? $CountIpAll : 0;
	$CountAll = $CountAll > 0 ? $CountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$HourLineCount = intval( $MaxCount / 5 );

	for( $i = 0; $i < 24; $i++ )
	{
		$Row["hourippercent$i"] = $CountIpAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hourip$i"]/$CountIpAll ) * 100 );
		$Row["hourippillarheight$i"] = $Quotiety * $Row["hourip$i"];
		$Row["hourippillarheight$i"] = $Row["hourippillarheight$i"] < 1 ? 1 : $Row["hourippillarheight$i"];

		$Row["hourpercent$i"] = $CountAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hour$i"]/$CountAll ) * 100 );
		$Row["hourpillarheight$i"] = ( $Quotiety * $Row["hour$i"] ) - $Row["hourippillarheight$i"];
		$Row["hourpillarheight$i"] = $Row["hourpillarheight$i"] < 1 ? 1 : $Row["hourpillarheight$i"];

		$HourData[$i] = array(
								'hourippercent' =>$Row["hourippercent$i"], 
								'hourippillarheight' => $Row["hourippillarheight$i"],
								'hourpercent' => $Row["hourpercent$i"],
								'hourpillarheight' => $Row["hourpillarheight$i"],
								'hourip' => $Row["hourip$i"],
								'hour' => $Row["hour$i"],
								
								);

		$DayHour[$i] = $i;
	}


	$Tpl->assign( 'DayHour', $DayHour );
	$Tpl->assign( 'HourData', $HourData );
	$Tpl->assign( 'HourLineCount', $HourLineCount );

	$Tpl->assign( 'CountIpAll', $CountIpAll );
	$Tpl->assign( 'CountAll', $CountAll );

	$Tpl->assign( 'PillarTdWidth', PILLAR_WIDTH/24 );
	$Tpl->assign( 'PillarWidth', ( PILLAR_WIDTH/24 ) - 4  );

	//����ͳ����Ϣ��������


	//��ȡ����24Сʱ��¼
	$Res = mysql_query( " select sum(hour0) as hour0, sum(hour1) as hour1, sum(hour2) as hour2, sum(hour3) as hour3, sum(hour4) as hour4, sum(hour5) as hour5, sum(hour6) as hour6, sum(hour7) as hour7, sum(hour8) as hour8, sum(hour9) as hour9, sum(hour10) as hour10, sum(hour11) as hour11, sum(hour12) as hour12, sum(hour13) as hour13, sum(hour14) as hour14, sum(hour15) as hour15, sum(hour16) as hour16, sum(hour17) as hour17, sum(hour18) as hour18, sum(hour19) as hour19, sum(hour20) as hour20, sum(hour21) as hour21, sum(hour22) as hour22, sum(hour23) as hour23, sum(hourip0) as hourip0, sum(hourip1) as hourip1, sum(hourip2) as hourip2, sum(hourip3) as hourip3, sum(hourip4) as hourip4, sum(hourip5) as hourip5, sum(hourip6) as hourip6, sum(hourip7) as hourip7, sum(hourip8) as hourip8, sum(hourip9) as hourip9, sum(hourip10) as hourip10, sum(hourip11) as hourip11, sum(hourip12) as hourip12, sum(hourip13) as hourip13, sum(hourip14) as hourip14, sum(hourip15) as hourip15, sum(hourip16) as hourip16, sum(hourip17) as hourip17, sum(hourip18) as hourip18, sum(hourip19) as hourip19, sum(hourip20) as hourip20, sum(hourip21) as hourip21, sum(hourip22) as hourip22, sum(hourip23) as hourip23 from $TableList[day_data]  where website = '$website'" );
	$Row = mysql_fetch_array( $Res, MYSQL_ASSOC );

	$MaxCount = 0;
	for( $i = 0; $i < 24; $i++ )
	{
		$AllCountIpAll += $Row["hourip$i"];
		$AllCountAll += $Row["hour$i"];
		$MaxCount = $Row["hour$i"] > $MaxCount ? $Row["hour$i"] : $MaxCount;
	}

	$AllCountIpAll = $AllCountIpAll > 0 ? $AllCountIpAll : 0;
	$AllCountAll = $AllCountAll > 0 ? $AllCountAll : 0;
	$MaxCount = $MaxCount > 0 ? $MaxCount : 0;

	$Quotiety = $MaxCount == 0 ? 0 : PILLAR_HEIGHT / $MaxCount;
	$AllHourLineCount = intval( $MaxCount / 5 );

	for( $i = 0; $i < 24; $i++ )
	{
		$Row["hourippercent$i"] = $AllCountIpAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hourip$i"]/$AllCountIpAll ) * 100 );
		$Row["hourippillarheight$i"] = $Quotiety * $Row["hourip$i"];
		$Row["hourippillarheight$i"] = $Row["hourippillarheight$i"] < 1 ? 1 : $Row["hourippillarheight$i"];

		$Row["hourpercent$i"] = $AllCountAll == 0 ? 0 : sprintf("%01.2f", ( $Row["hour$i"]/$AllCountAll ) * 100 );
		$Row["hourpillarheight$i"] = ( $Quotiety * $Row["hour$i"] ) - $Row["hourippillarheight$i"];
		$Row["hourpillarheight$i"] = $Row["hourpillarheight$i"] < 1 ? 1 : $Row["hourpillarheight$i"];

		$AllHourData[$i] = array(
								'hourippercent' =>$Row["hourippercent$i"], 
								'hourippillarheight' => $Row["hourippillarheight$i"],
								'hourpercent' => $Row["hourpercent$i"],
								'hourpillarheight' => $Row["hourpillarheight$i"],
								'hourip' => $Row["hourip$i"],
								'hour' => $Row["hour$i"],
								);

		$AllDayHour[$i] = $i;
	}

	$Tpl->assign( 'AllDayHour', $AllDayHour );
	$Tpl->assign( 'AllHourData', $AllHourData );
	$Tpl->assign( 'AllHourLineCount', $AllHourLineCount );

	$Tpl->assign( 'AllCountIpAll', $AllCountIpAll );
	$Tpl->assign( 'AllCountAll', $AllCountAll );
	//��ȡ����24Сʱ��¼


	$Tpl->assign( 'Year', $Year );
	$Tpl->assign( 'Month', $Month );
	$Tpl->assign( 'Day', $Day );
	$Tpl->assign( 'DataTime', $DataTime );	

	$Tpl->assign( 'Main', $Tpl->fetch( 'stat_day.html' ) . $ScriptCode );

	$Tpl->assign( 'Title', 'ʱ�η��� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', 'ʱ�η���' );
	$Tpl->assign( 'QuickLink', '<a href="stat_day.php">ʱ�η���</a> <a href="stat_month.php">�նη���</a> <a href="stat_year.php">�·��� </a>' );
	_out( $Tpl->fetch( 'main.html' )  );

?> 
