<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	class _Stat
	{

		//var $TmpDir = './count/tmpdir';
		var $TmpDir = TMPDIR;
		var $UserDataDir;
		var $UserData;
		var $UserTodayDir;
		var $Time;
		var $Year;
		var $Month;
		var $Day;
		var $Week;
		var $Hour;
		var $website;
		var $NewDay = false;
		var $NewViewer = true;
		var $ViewerInfo = array();
		var $ArrTypes = array(
										'keyword'=>array( 'lastpage'=>true, 'allownull'=> false, 'newviewer'=>false ),
										'referer'=>array( 'lastpage'=>true, 'allownull'=> true, 'newviewer'=>true ),
										'color'=>array( 'lastpage'=>false, 'allownull'=> false, 'newviewer'=>true ),
										'screen'=>array( 'lastpage'=>false, 'allownull'=> false, 'newviewer'=>true ),
										'language'=>array( 'lastpage'=>true, 'allownull'=> false, 'newviewer'=>true ),
										'browser'=>array( 'lastpage'=>false, 'allownull'=> false, 'newviewer'=>true ),
										'system'=>array( 'lastpage'=>false, 'allownull'=> false, 'newviewer'=>true ),
										'area'=>array( 'lastpage'=>true, 'allownull'=> false, 'newviewer'=>true ),
										'timezone'=>array( 'lastpage'=>false, 'allownull'=> false, 'newviewer'=>true ),
										'page'=>array( 'lastpage'=>true, 'allownull'=> false, 'newviewer'=>false ),
										'return'=>array( 'lastpage'=>true, 'allownull'=> false, 'newviewer'=>true )
										);
		

		var $DayStartTime;

		function _Stat( )
		{
			global $TableList;$time1 = microtime();
			$this->website = $_GET[website];
			$this->TableList = $TableList;
			$this->Time = time();
			$this->Year = date( 'Y', $this->Time );
			$this->Month = date( 'm', $this->Time );
			$this->Day = date( 'j', $this->Time );
			$this->Week = date( 'w', $this->Time );
			$this->Hour = date('G', $this->Time );
			$this->DayStartTime = mktime(0, 0, 0, $this->Month, $this->Day, $this->Year);

			$this->GetUserDir();
			$this->GetUserData();			
			$this->GetViewerInfo();
			$this->CheckNewDay();
			$this->CheckNewViewer();

			
			//����alexa����
			$this->AddAlexa();

			$this->SaveArr();
			$this->SaveViewerInfo();



			$this->ShowArr = Array ( 	'DayCount'=>array('day_count','���շ���'), 
														'DayIpCount'=>array('day_count_ip','����IP'), 
														'HourCount'=>array('hour'.$this->Hour,'��Сʱ����'), 
														'HourIpCount'=>array('hourip'.$this->Hour,'��СʱIP') 
													);


			$Res = $this->_query( " select * from " . $this->TableList[day_data] . " where times = {$this->DayStartTime} and website = '$this->website'" );
			$DayData = mysql_fetch_array( $Res, MYSQL_ASSOC );
			if( count( $DayData ) < 1 )
			{
				$this->IniToday();
			}

			$UpdateStr = "day_count = day_count + 1, hour{$this->Hour} = hour{$this->Hour} + 1";
			if( $this->NewViewer )
			{
				 $UpdateStr .= ", hourip{$this->Hour} = hourip{$this->Hour} + 1, day_count_ip = day_count_ip + 1 " ;
			}
			$Sql = " update " . $this->TableList[day_data] . " set $UpdateStr where times = {$this->DayStartTime} and website = '$this->website'";
			$this->_query( $Sql );
			$this->OutLog( $DayData );$time2 = microtime();
			echo '<B>'.sprintf("%01.4f",($time2-$time1)).'</B>';
		}

		function OutLog( $DayData )
		{
			$_GET[show] = @array_flip ( $_GET[show] );

			foreach( $this->ShowArr as $Key=>$Val )
			{
				if( isset( $_GET[show][$Key] ) )
				{
					$ShowStr .= '[' . $this->Charset( $Val[1] ) . ':' . $DayData["$Val[0]"] . ']';
				}
				
			}

			$Title = $this->Charset( '��վ������ͳ�Ʒ���ϵͳ' );
			if( $this->ViewerInfo[type] == 2 )
			{
				echo "document.getElementById(\"OurplusCount\").innerHTML='<a href=http://wiwiboy.sodns.net target=\"_blank\" title=\"PCS " . $Title . "\"><img src=\"" . $this->ViewerInfo['counturl'] . "/countlogo.gif\" style=\"border:0px;\"  align=\"absmiddle\"></a>';";
			}
			else
			{
				echo "document.write('<a href=http://wiwiboy.sodns.net target=\"_blank\" title=\"PCS " . $Title . "\"><img src=\"" . $this->ViewerInfo['counturl'] . "/countlogo.gif\" style=\"border:0px;\"  align=\"absmiddle\"></a>');";
				if( trim( $ShowStr ) != '' )
				{
					echo "document.write('$ShowStr')";
				}
			}
		}

		function Charset( $Str )
		{
			return $this->ViewerInfo[charset] == 'utf-8' ? utf82gb2312( $Str ) : $Str;
		}

		function GetUserDir()
		{
			$this->UserDataDir = $this->TmpDir;
			if( ! is_dir( $this->UserDataDir ) )
			{
				if( ! mkdir( $this->UserDataDir ) )
				{
					$this->_Error( 'Error In GetUserDir At ' . __line__ );
				}
			}
		}

		function GetUserData()
		{
			$Sql = "SELECT  `id` , `manager` , `password` , `site` , `sitename` , `sitedes` , `sitetype` , `qq` , `email` , `msn` FROM " . $this->TableList[users] . "  where manager !=''";
			$Res = $this->_query( $Sql );
			$RetRows = mysql_num_rows( $Res );

			if( $RetRows == 1 )
			{
				$this->UserData = $UserData[0];
			}
			elseif ( $RetRows == 0 )
			{
				$this->_Error( 'Uninstall, Error At ' . __line__ );
			}
			elseif ( $RetRows > 1 )
			{
				$this->_Error( 'Database User Data Error' );
			}

			$this->UserData = mysql_fetch_array( $Res, MYSQL_ASSOC );
		}
		

		function CheckNewDay()
		{
			$this->UserTodayDir = $this->UserDataDir . '/' . $this->website .'_'.$this->DayStartTime;
			if( ! is_dir( $this->UserTodayDir ) )
			{
				$this->NewDay = true;
				mkdir( $this->UserTodayDir );
				$this->ClearYesterday();
				$this->IniToday();
			}
		}

		function CheckNewViewer()
		{
			$Sql = "SELECT count(*) as count FROM " . $this->TableList[ip] . " where ip = '{$this->ViewerInfo[REMOTE_ADDR]}' and time > $this->DayStartTime and website = '$this->website'";
			$Res = $this->_query( $Sql );
			$Count = mysql_fetch_array( $Res, MYSQL_ASSOC );
			$Count = intval( $Count[count] );
			if( $Count > 0 )
			{
				$this->NewViewer = false;
			}
		}

		function ClearYesterday()
		{
			//echo '������������������';
			$YesterdayStartTime = mktime (0, 0, 0, $this->Month, $this->Day-1, $this->Year);


			$YesterdayYear = date( 'Y', $YesterdayStartTime );
			$YesterdayMonth = date( 'm', $YesterdayStartTime );
			$YesterdayDay = date( 'j', $YesterdayStartTime );
			$YesterdayWeek = date( 'w', $YesterdayStartTime );
			$YesterdayHour = date('G', $YesterdayStartTime );

			$Res = $this->_query( " select * from " . $this->TableList[day_data] . " where times = $YesterdayStartTime and  website = '$this->website'" );
			$YesterdayData = mysql_fetch_array( $Res, MYSQL_ASSOC );

			$YesterdayData[day_count] = intval( $YesterdayData[day_count] );
			$YesterdayData[day_count_ip] = intval( $YesterdayData[day_count_ip] );

			//Update Count Table
			$Sql = "update " . $this->TableList[users] . " set week{$YesterdayWeek} = week{$YesterdayWeek} + $YesterdayData[day_count], weekip{$YesterdayWeek} = weekip{$YesterdayWeek} + $YesterdayData[day_count_ip], 			day{$YesterdayDay} = day{$YesterdayDay} + $YesterdayData[day_count], dayip{$YesterdayDay} = dayip{$YesterdayDay} + $YesterdayData[day_count_ip], all_count = all_count  + $YesterdayData[day_count], all_count_ip = all_count_ip + $YesterdayData[day_count_ip] where website = '$this->website'";
			$this->_query( $Sql );



			//Update Month Table
			$YesterdayMonthTime = mktime (0,0,0,$YesterdayMonth, 1, $YesterdayYear );
			$Res = $this->_query( " select count(*) as count from " . $this->TableList[month_data] . " where times = $YesterdayMonthTime and website = '$this->website'" );
			$Row = mysql_fetch_array( $Res, MYSQL_ASSOC );
			
			if( $Row[count] == 0 )
			{	
				$Sql = " insert into " . $this->TableList[month_data] . " 
				( website, times, year, month, month_count, month_count_ip ) 
				values 
				( '$this->website', $YesterdayMonthTime, $YesterdayYear, $YesterdayMonth, $YesterdayData[day_count], $YesterdayData[day_count_ip] )
				";
				$this->_query( $Sql );
			}
			else
			{
				$Sql = " update " . $this->TableList[month_data] . " set month_count = month_count + $YesterdayData[day_count], month_count_ip = month_count_ip + $YesterdayData[day_count_ip] where times = $YesterdayMonthTime and website = '$this->website'";
				$this->_query( $Sql );
			}

			//Update Year Table
			$YesterdayYearTime = mktime ( 0, 0, 0, 1, 1, $YesterdayYear );
			$Res = $this->_query( " select count(*) as count from " . $this->TableList[year_data] . " where times = $YesterdayYearTime and website = '$this->website'" );
			$Row = mysql_fetch_array( $Res, MYSQL_ASSOC );
			
			if( $Row[count] == 0 )
			{	
				$Sql = " insert into " . $this->TableList[year_data] . " 
				(website, times, year, year_count, year_count_ip ) 
				values 
				( '$this->website', $YesterdayYearTime, $YesterdayYear, $YesterdayData[day_count], $YesterdayData[day_count_ip] )
				";
				$this->_query( $Sql );
			}
			else
			{
				$Sql = " update " . $this->TableList[year_data] . " set year_count = year_count + $YesterdayData[day_count], year_count_ip = year_count_ip + $YesterdayData[day_count_ip] where times = $YesterdayYearTime and website = '$this->website'";

				$this->_query( $Sql );
			}


			//ɾ��������ϸ����ͳ��
			$this->_query( "delete from " . $this->TableList[ip] . " where time < {$this->DayStartTime} and website = '$this->website'" );
			//echo mysql_error();

			foreach( $this->ArrTypes as $Key=>$Val )
			{
				$Sql = "delete from " . $this->TableList[$Key] . " where types = 2 and website = '$this->website'";
				$this->_query( $Sql );
				$Sql = "update " . $this->TableList[$Key] . " set types = 2 where types = 1 and website = '$this->website'";
				$this->_query( $Sql );
			}


			//ɾ�����ղ�������ʱ�ļ�
			@rmdir( $this->UserDataDir . '/' . $this->website .'_'.$YesterdayStartTime );
		}

		function IniToday()
		{
			$Sql = "INSERT INTO " . $this->TableList[day_data] . " (
													`website`, `times`, `year`, `month`, `day`, `week`
													) VALUES ('{$this->website}',
													'{$this->DayStartTime}', '{$this->Year}', '{$this->Month}', '{$this->Day}', '{$this->Week}'
													);";
			$this->_query( $Sql );
		}

		function GetFLTime( $Val )
		{
			$Val = explode( '-', $Val );
			return mktime ( $Val[3], $Val[4], $Val[5], $Val[1], $Val[2], $Val[0] );
		}

		function GetViewerInfo()
		{
			$this->ViewerInfo[TIME] = &$this->Time;
			$this->ViewerInfo[page] = $_GET[pageurl];
			if(eregi("script", $this->ViewerInfo[page]) or eregi("iframe", $this->ViewerInfo[page]))
			{exit;}
			$this->ViewerInfo[REFERER] = $_GET[referer];
			$this->ViewerInfo[language] = strtolower( $_GET[language] );
			$this->ViewerInfo[color] = $_GET[color];
			$this->ViewerInfo[screen] = $_GET[screensize];
			$this->ViewerInfo[HTTP_USER_AGENT] = $_SERVER["HTTP_USER_AGENT"];
			$this->ViewerInfo[REMOTE_ADDR] = '127.0.0.1'; //'60.'.rand(0,2).rand(0,1).rand(0,1).'.'.rand(0,1).rand(0,1).'.'.rand(0,1).rand(0,1).rand(0,1);//$_SERVER["REMOTE_ADDR"];
			$this->ViewerInfo[timezone] = $_GET["timezone"];
			$this->ViewerInfo[firsttime] = $this->GetFLTime( $_GET["firsttime"] );
			$this->ViewerInfo[lasttime] = $this->GetFLTime( $_GET["lasttime"] );
			$this->ViewerInfo['return'] = intval( $_GET['return1'] );
			$this->ViewerInfo['counturl'] = $_GET['counturl'];
			//$this->ViewerInfo[website] = $_GET[website];
			

			
			//$this->ViewerInfo[returncount]  = 0;

			$this->ViewerInfo[charset] = $_GET["charset"];
			$this->ViewerInfo[type] = intval( $_GET["type"] );


			//����վ��
			preg_match( "|(http://[^/]+?)/.*|isU", $this->ViewerInfo[REFERER], $Tmp );
			$this->ViewerInfo[referer] = trim( $Tmp[1] );

			//���ҹؼ���
			$this->GetKeyWord();

			//������Դ����
			$IpInfo = $this->GetIpAdd( );
			$this->ViewerInfo[area] = $IpInfo[country];
			$this->ViewerInfo[address] = $IpInfo[address];

			//�����Ƿ���alexa������
			if( strpos( $this->ViewerInfo[HTTP_USER_AGENT], 'Alexa') )
			{
				$this->ViewerInfo[alexatool] = 1;
			}
			else
			{
				$this->ViewerInfo[alexatool] = 0;
			}

			//��ȡ�������Ϣ
			$this->GetBrowser();
			$this->GetSystem();
		}

		function SaveViewerInfo()
		{
			$Sql = "INSERT INTO " . $this->TableList[ip] . " ( 
								`ip`, `time`, `pageurl`, `pagefrom`, `language`, `color`, `screensize`, `http_user_agent`, `pagefromsite`, `keyword`, `country`, `address`, `alexatool`, `timezone`, `firsttime`, `lasttime`, `browser`, `system`, `todayfirst`, `return` ,`website`
								) VALUES ( 
								'{$this->ViewerInfo[REMOTE_ADDR]}', '{$this->ViewerInfo[TIME]}', '{$this->ViewerInfo[page]}', '{$this->ViewerInfo[REFERER]}', '{$this->ViewerInfo[language]}', '{$this->ViewerInfo[color]}', '{$this->ViewerInfo[screen]}', '{$this->ViewerInfo[HTTP_USER_AGENT]}', '{$this->ViewerInfo[referer]}', '{$this->ViewerInfo[keyword]}', '{$this->ViewerInfo[area]}', '{$this->ViewerInfo[address]}', '{$this->ViewerInfo[alexatool]}', '{$this->ViewerInfo[timezone]}', '{$this->ViewerInfo[firsttime]}', '{$this->ViewerInfo[lasttime]}', '{$this->ViewerInfo[browser]}', '{$this->ViewerInfo[system]}', '" . ( $this->NewViewer == true ? 1 : 0 ) . "', '".$this->ViewerInfo['return']."',
								'{$this->website}');";
			//echo $Sql;
			//mysql_query( $Sql );
			$this->_query( $Sql );
		}

		function _Error( $Msg )
		{
			exit( $Msg );
		}

		//���ҹؼ���
		function GetKeyWord()
		{

			$DomainName = &$this->ViewerInfo[referer];
			$RefererUrl = &$this->ViewerInfo[REFERER];
			if( strstr( $DomainName, 'baidu.com') )
			{
				preg_match( "|baidu.+wo?r?d=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'google.com') )
			{
				preg_match( "|google.+q=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = utf82gb2312( urldecode( $Tmp[1] ) );
			}
			else if( strstr( $DomainName, 'sohu.com') )
			{
				preg_match( "|sohu.+query=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'sina.com.cn') )
			{
				preg_match( "|sina.+searchkey=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, '163.com') )
			{
				preg_match( "|163.+q=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'yahoo.com') )
			{
				preg_match( "|yahoo.+p=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = utf82gb2312( urldecode( $Tmp[1] ) );
			}
			else if( strstr( $DomainName, 'lycos.com') )
			{
				preg_match( "|lycos.+query=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, '3721.com') )
			{
				preg_match( "|3721.+p=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'qq.com') )
			{
				preg_match( "|qq.+word=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'tom.com') )
			{
				preg_match( "|tom.+word=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, '21cn.com') )
			{
				preg_match( "|21cn.+word=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'sogou.com') )
			{
				preg_match( "|sogou.+query=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}
			else if( strstr( $DomainName, 'aol.com') )
			{
				preg_match( "|aol.+query=([^\&]*)|is", $RefererUrl, $Tmp );
				$KeyWord = urldecode( $Tmp[1] );
			}



			$this->ViewerInfo[keyword] = $KeyWord;
		}

		//��ȡ�������Ϣ
		function GetBrowser()
		{
			if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(myie[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Netscape[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Opera[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(NetCaptor[^;^^()]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(TencentTraveler)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Firefox[0-9/\.^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(MSN[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Lynx[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Konqueror[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(WebTV[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(msie[^;^)^(]*)|i" ) );
			else if( $Browser = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Maxthon[^;^)^(]*)|i" ) );
			else 
			{
				$Browser = '����';
			}
			//echo $Browser.'<br>';
			$this->ViewerInfo[browser] = trim( $Browser );
		}

		//��ȡ����ϵͳ�汾
		function GetSystem()
		{
			if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Windows NT[\ 0-9\.]*)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Windows[\ 0-9\.]*)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Mac[^;^)]*)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(unix)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(Linux[\ 0-9\.]*)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(SunOS[\ 0-9\.]*)|i" ) );
			else if( $System = $this->matchbrowser( $this->ViewerInfo[HTTP_USER_AGENT], "|(BSD[\ 0-9\.]*)|i" ) );
			else 
			{
				$System = '����';
			}
			$this->ViewerInfo[system] = trim( $System );
		}

		function matchbrowser( $Agent, $Patten )
		{
			if( preg_match( $Patten, $Agent, $Tmp ) )
			{
				return $Tmp[1];
			}
			else
			{
				return false;
			}
		}

		function ip2num( $Ip )
		{
			$IpData = explode( '.', $Ip );
			if( count( $IpData ) != 4 )
			{
				return 0;
			}
			$IpNum = 0;	
			foreach( $IpData as $Key => $Val )
			{
				$IpNum += intval( $Val ) * pow ( 256, 3-$Key );
			}
			return $IpNum;
		}

		//��ȡip��ַ��Դ
		function GetIpAdd( )
		{
			$IpNum = $this->ip2num( $this->ViewerInfo[REMOTE_ADDR] );
			$Res = $this->_query( " select * from " . $this->TableList[ip_data] . " where ipstart <= $IpNum and ipend >= $IpNum " );
			$IpInfo = mysql_fetch_array( $Res, MYSQL_ASSOC );
			return $IpInfo;
		}

		//����alexa����������
		function AddAlexa()
		{
			if( $this->ViewerInfo[alexatool] != 1 || $this->NewViewer == false )
			{
				return false;
			}
			
			//$Time = mktime (0, 0, 0, $this->Month, $this->Day, $this->Year);

			$Sql = " select  count(*) as count from " . $this->TableList[alexa] . " where times={$this->DayStartTime} and website = '$this->website'";
			$Res = $this->_query( $Sql );
			
			//����Ƿ�����Ҫ���ӵļ�¼
			$Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC );
			if( $Tmp[count] == 0 )
			{
					$Sql = "INSERT INTO " . $this->TableList[alexa] . " ( `website`,`times`, `lastpage`, `counts` ) VALUES ('$this->website', '{$this->DayStartTime}', '{$this->ViewerInfo[REFERER]}', '0' );";
					$this->_query( $Sql );
			}

			$Sql = " update " . $this->TableList[alexa] . " set counts = counts + 1, lastpage='{$this->ViewerInfo[REFERER]}', http_user_agent = '{$this->ViewerInfo[HTTP_USER_AGENT]}' where times={$this->DayStartTime}  and website = '$this->website'";
			$this->_query( $Sql );
		}


		//�������������Ϣ
		function SaveArr()
		{
			//if( $this->ViewerInfo['return'] == 0 )
			//{
			//	unset( $this->ViewerInfo['return'] );
			//}
			foreach( $this->ArrTypes as $Key=>$Val )
			{

				if( ( $this->ViewerInfo[$Key] == '' && $Val[allownull] == false ) || ( $this->NewViewer == false && $Val[newviewer] == true ) )
				{
					continue;
				}

				$this->_SaveType( $Key );
			}
		}

		function _SaveType( $Type )
		{
			$Types = &$this->ArrTypes;

			if( ! isset( $Types[$Type] ) )
			{
				return false;
			}

			$Sql = " select count(*) as count, types, counts, {$Type}id from " . $this->TableList[$Type] . " where {$Type} = '" . $this->ViewerInfo["$Type"] . "' and types != 2 and website = '$this->website' group by types,{$Type}id,counts ";
			$Res = $this->_query( $Sql );

			unset( $DelData );
			unset( $Data );
			
			while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
			{
				if( isset( $Data["$Tmp[types]"] ) )
				{
					$Tmp['isset'] = $Data["$Tmp[types]"];
					$DelData[] = $Tmp;
					continue;
				}
				$Data["$Tmp[types]"] = $Tmp;
			}

			//����Ƿ�����Ҫ���ӵļ�¼
			for( $i = 0; $i < 2; $i++ )
			{
				if( ! isset( $Data[$i] ) )
				{
					$Sql = "INSERT INTO " . $this->TableList[$Type] . " ( `website`,`{$Type}`, `times`,"  . ( $Types[$Type][lastpage] ?  "`lastpage`," : '' ) . " `counts`, `types` ) VALUES ( '$this->website','" . $this->ViewerInfo["$Type"] . "', '{$this->ViewerInfo[TIME]}', " . ( $Types[$Type][lastpage] ?  "'{$this->ViewerInfo[REFERER]}', " : '' ) . "'0', '$i' );";
					$this->_query( $Sql );
				}
			}
			
			//����Ƿ�����Ҫɾ���ļ�¼
			if( count( $DelData ) > 0 )
			{
				foreach( $DelData as $Val )
				{
					$Sql = " delete from " . $this->TableList[$Type] . " where {$Type}id = " . $Val["{$Type}id"] ." and website = '$this->website'";
					$this->_query( $Sql );
					$Sql = " update " . $this->TableList[$Type] . " set counts = counts + $Val[counts] where {$Type}id = " . $Val['isset']["{$Type}id"]." and website = '$this->website'";
					$this->_query( $Sql );
				}
			}

			$Sql = " update " . $this->TableList[$Type] . " set counts = counts + 1, "  . ( $Types[$Type][lastpage] ?  "lastpage='{$this->ViewerInfo[REFERER]}', " : '' ) . "times = '{$this->ViewerInfo[TIME]}' where {$Type} = '" . $this->ViewerInfo["$Type"] . "'  and types != 2 and website = '$this->website'";

			$this->_query( $Sql );

		}

		function _query( $Sql, $D = false )
		{
			$Res = mysql_query( $Sql );

			if( $D || $_GET[debug] == 'true'  )
			{
				echo $Sql . "<br>\n";
				echo mysql_error();
			}

			if( $Res )
			{
				return $Res;
			}
			else
			{
				$f = fopen( 'count/mysql_error.log', 'a+' );
				fwrite( $f, date("Y-m-d H:i:s") . mysql_error() . '--' . $Sql . "\n" );
				fclose( $f );
				return false;
			}
		}


	}




?>