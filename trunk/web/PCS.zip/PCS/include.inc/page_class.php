<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/

class Pages
{
	var $CurrentPage; // ��ǰҳ
	var $RecordCount; // ��¼����
	var $PageSize; // ҳ����	
	var $URL; // ���ӵ�ַ
	var $PageCount; // ҳ��
	var $URLChar; // URL �����ָ���

	var $LinkCount; // �ڽ�������
	var $PageVarName; // ҳ������
	var $Text_FirstPage; // ��ҳ
	var $Text_LastPage; // ĩҳ
	var $Text_PrevPage; // ǰҳ
	var $Text_NextPage; // ��ҳ
	var $Text_Overleap; // ʡ���ִ�
	var $RecordName; // ��¼����
	var $RecordUnit; // ��¼��λ	

	function Pages ( $RecordCount = 0, $PageSize = 0, $CurrentPage = 0, $URL = '' )
	{
		$this->RecordCount = $RecordCount;
		$this->PageSize = $PageSize;
		$this->CurrentPage = $CurrentPage;
		$this->URL = $URL;

		$this->LinkCount = 10;
		$this->PageVarName = "page";
		$this->Text_FirstPage = "��ҳ";
		$this->Text_LastPage = "ĩҳ";
		$this->Text_PrevPage = "ǰҳ";
		$this->Text_NextPage = "��ҳ";
		$this->Text_Overleap = "...";
		$this->RecordName = "��¼";
		$this->RecordUnit = "��";	
	}

	function MakePageItems ()
	{
		// ����ֵ
		// $PageItems[Links] : ҳ������
		// $PageItems[Before] : ��ҳ ǰҳ
		// $PageItems[After] : ��ҳ ĩҳ

		// [Links][type] : LINK/NOLINK/CURRENTPAGE
		// [Links][text] : ����
		// [Links][link] : ���ӵ�ַ

		// ������ǰҳ
		if ( $this->CurrentPage == 0 )
		{
			$this->CurrentPage = intval ( $_GET[$this->PageVarName] );
		}

		// ���� URL
		if ( $this->URL == '' )
		{
			$this->URL = $this->MakeURL ( $_GET );
		}

		$this->PageCount = @ceil ( $this->RecordCount / $this->PageSize ); // ������ҳ��
		if ( $this->PageCount == 0 )
		{
			return FALSE;
		}

		$this->URLChar = strstr ( $this->URL, "?" ) ? "&" : "?";
		$this->CurrentPage = min ( $this->PageCount, $this->CurrentPage );
		$this->CurrentPage = max ( 1, $this->CurrentPage );		

		if ( $this->CurrentPage - $this->LinkCount > 1 )
		{
			// ʡ�� {$this->LinkCount} ҳ��ǰ��ҳ������
			$PageItems[Links][0][type] = "NOLINK";
			$PageItems[Links][0][text] = $this->Text_Overleap;
		}

		for ( $i = max ( 1, $this->CurrentPage - $this->LinkCount ); $i <= min ( $this->PageCount, $this->CurrentPage + $this->LinkCount ); $i++ )
		{
			$PageItems[Links][$i][text] = $i;
			if ( $this->CurrentPage == $i )
			{
				$PageItems[Links][$i][type] = "CURRENTPAGE";
			}
			else
			{
				$PageItems[Links][$i][type] = "LINK";
				$PageItems[Links][$i][link] = $this->URL . $this->URLChar . $this->PageVarName . "=" . $i;
			}
		}
		if ( $this->CurrentPage + $this->LinkCount < $this->PageCount )
		{
			// ʡ�� {$this->LinkCount} ҳ�Ժ��ҳ������
			$PageItems[Links][$i][type] = "NOLINK";
			$PageItems[Links][$i][text] = $this->Text_Overleap;
		}

		$PageItems[Before][0][text] = $this->Text_FirstPage;
		$PageItems[Before][1][text] = $this->Text_PrevPage;
		$PageItems[After][0][text] = $this->Text_NextPage;
		$PageItems[After][1][text] = $this->Text_LastPage;
		$PageItems[Before][0][link] = $this->URL . $this->URLChar . $this->PageVarName . "=1";
		$PageItems[Before][1][link] = $this->URL . $this->URLChar . $this->PageVarName . "=" . ( $this->CurrentPage - 1 );
		$PageItems[After][0][link] = $this->URL . $this->URLChar . $this->PageVarName . "=" . ( $this->CurrentPage + 1 );
		$PageItems[After][1][link] = $this->URL . $this->URLChar . $this->PageVarName . "=" . $this->PageCount;

		if ( $this->CurrentPage > 1 )
		{
			$PageItems[Before][0][type] = "LINK";
			$PageItems[Before][1][type] = "LINK";
		}
		else
		{
			$PageItems[Before][0][type] = "NOLINK";
			$PageItems[Before][1][type] = "NOLINK";
		}
		if ( $this->CurrentPage < $this->PageCount )
		{
			$PageItems[After][0][type] = "LINK";
			$PageItems[After][1][type] = "LINK";
		}
		else
		{
			$PageItems[After][0][type] = "NOLINK";
			$PageItems[After][1][type] = "NOLINK";
		}

		$PageItems[RecordCount] = $this->RecordCount;
		$PageItems[PageCount] = $this->PageCount;
		$PageItems[PageSize] = $this->PageSize;
		$PageItems[CurrentPage] = $this->CurrentPage;
		$PageItems[Offset] = ( $this->CurrentPage - 1 ) * $this->PageSize;
		$PageItems[RecordName] = $this->RecordName;
		$PageItems[RecordUnit] = $this->RecordUnit;

		return $PageItems;
	}

	function MakeURL ( $Data )
	{
		unset ( $Data[$this->PageVarName] );
		while ( list ( $Key, $Val ) = @each ( $Data ) )
		{
			$Query[] = $Key . '=' . urlencode ( $Val );
		}
		$URL = $_SERVER[SCRIPT_NAME] . '?' . @join ( '&', $Query );
		return $URL;
	}
}
?>