<?
/*
* ===========================================*
* 项目: Ourplus网站流量统计分析系统*
* 版本: Bate1*
* 开发: 看海*
* ===========================================*
* Copyright (c) 2004 - 2005*
* 主页: http://stat.ourplus.com*
* 信箱: fantasysisky@hotmail.com*
* 版权信息: 本软体为共享软体(shareware)提供个人网站免费使用，
                作者看海 (stat.ourplus.com) 保留全部权力，受相关法律和国际
				公约保护，请勿非法修改、转载、散播，或用于其他赢利行为，
				并请勿删除版权声明。*
* ===========================================*
*/

	function GetSystem( $System )
	{
		$SystemLists = array( 
			'windows nt 5.2' => 'Windows 2003',
			'windows nt 5.1' => 'Windows XP',
			'windows nt 5.0' => 'Windows 2000',
		);

		$System = strtolower( trim( $System ) );
		if( $SystemLists[$System] == '' )
		{
			return $System;
		}
		else
		{
			return $SystemLists[$System];
		}
	}

?>