CREATE TABLE `count_ip_data` (
  `ipid` bigint(10) unsigned NOT NULL auto_increment,
  `ipstart` bigint(20) default NULL,
  `ipend` bigint(20) default NULL,
  `country` varchar(250) default NULL,
  `address` varchar(250) default NULL,
  PRIMARY KEY  (`ipid`),
  KEY `ip_start` (`ipstart`)
) TYPE=MyISAM AUTO_INCREMENT=218065 ;
