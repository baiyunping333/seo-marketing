var _OurplusCount = 'COUNTER_INSTALL_URL';


var _Debug;
var _OurplusWebSite;
var _OurplusType;
var _OurplusShow;
var _OurplusShowStr='';
var _OurplusIframe = true;

var _OurplusCountPage = _OurplusCount + '/count/count.php';
if( _OurplusIframe == true )
{
	var _OurplusPageurl = escape(location.href);
	var _OurplusReferer = escape(document.referrer);
}
else
{
	var _OurplusPageurl = escape(top.location.href);
	var _OurplusReferer = escape(top.document.referrer);
}

var _OurplusLanguage = (navigator.systemLanguage?navigator.systemLanguage:navigator.language);
var _OurplusColor = screen.colorDepth;
var _OurplusScreenSize = screen.width + '*' + screen.height;
var _OurplusCharset = document.charset


var _OurplusFirstTime;
var _OurplusLastTime;
_OurplusFirstTime = _OurplusReadCookie( '_OurplusFirstTime' );
if( _OurplusFirstTime == '' )
{
	_OurplusFirstTime = GetTime();
	_OurplusLastTime = _OurplusFirstTime;
	_OurplusWriteCookie( '_OurplusFirstTime', _OurplusFirstTime, 10000 );
}
else
{
	_OurplusLastTime = GetTime();
}

if( _OurplusType == null )
{
	_OurplusType = 1;
}

_OurplusReturnCount = _OurplusReadCookie( '_OurplusReturnCount' );
_OurplusReturnCount = _OurplusReturnCount == '' ? 0 : _OurplusReturnCount;

_OurplusReturnTime = _OurplusReadCookie( '_OurplusReturnTime' );
if( _OurplusReturnTime == '' )
{
	_OurplusReturnTime = GetTime();
	_OurplusWriteCookie( '_OurplusReturnTime', _OurplusReturnTime, 10000 );
}

Temp = _OurplusReturnTime.split( '-' )
_OurplusReturnTimeDate = new Date(Temp[0], Temp[1]-1, Temp[2], Temp[3], Temp[4], Temp[5] );
_OurplusNowTimeDate = new Date();

if( _OurplusNowTimeDate - _OurplusReturnTimeDate >= 43200000 )
{
	_OurplusWriteCookie( '_OurplusReturnCount', ++_OurplusReturnCount, 10000 );
	_OurplusWriteCookie( '_OurplusReturnTime', GetTime(), 10000 );
}
else
{
	_OurplusReturnCount = null;
}


if( _OurplusShow != null && _OurplusShow.length > 0 )
{
	var _OurplusShowStr = '';
	for( i = 0; i < _OurplusShow.length; i ++ )
	{
		_OurplusShowStr += "&show[]=" + _OurplusShow[i];
	}
}
else
{
	var _OurplusShowStr = "";
}



var _OurplusCountUrl = _OurplusCountPage + '?'
+ '&counturl=' + _OurplusCount
+ '&pageurl=' + _OurplusPageurl
+ '&referer=' + _OurplusReferer
+ '&language=' + _OurplusLanguage
+ '&color=' + _OurplusColor
+ '&screensize=' + _OurplusScreenSize
+ '&debug=' + _Debug
+ '&firsttime=' + _OurplusFirstTime
+ '&lasttime=' + _OurplusLastTime
+ '&type=' + _OurplusType
+ '&charset=' + _OurplusCharset
+ _OurplusShowStr
+ '&timezone=' + (new Date()).getTimezoneOffset()/60
+ '&website='+ _OurplusWebSite;

if( _OurplusReturnCount != null )
{
	_OurplusCountUrl += '&return1=' + _OurplusReturnCount;
}


if( _Debug )
{
	document.write(_OurplusCountUrl);
	document.write("<iframe src='" + _OurplusCountUrl + "' width=100% height=500></iframe>");
}
else
{
	document.write("<script src='" + _OurplusCountUrl + "'></script>");
}



//Functions

function GetTime() 
{ 
	now = new Date(); 
	year=now.getYear();
	Month=now.getMonth()+1;
	Day=now.getDate();
	Hour=now.getHours(); 
	Minute=now.getMinutes(); 
	Second=now.getSeconds(); 
	return year+"-"+Month+"-"+Day+"-"+Hour+"-"+Minute+"-"+Second;
} 


function _OurplusReadCookie(name)
{
  var cookieValue = "";
  var search = name + "=";
  if(document.cookie.length > 0)
  { 
    offset = document.cookie.indexOf(search);
    if (offset != -1)
    { 
      offset += search.length;
      end = document.cookie.indexOf(";", offset);
      if (end == -1) end = document.cookie.length;
      cookieValue = unescape(document.cookie.substring(offset, end))
    }
  }
  return cookieValue;
}

function _OurplusWriteCookie(name, value, hours)
{
  var expire = "";
  if(hours != null)
  {
    expire = new Date((new Date()).getTime() + hours * 3600000);
    expire = "; expires=" + expire.toGMTString();
  }
  document.cookie = name + "=" + escape(value) + expire + "domain=;" + "path=/;";
}