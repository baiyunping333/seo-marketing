<?
	chdir( '../' );

	include_once './include.inc/config.inc.php';
	include_once './include.inc/conn.db.inc.php';

	include_once './include.inc/stat.class.php';
	include_once './include.inc/function.php';

	$Stat = new _Stat( );

?>