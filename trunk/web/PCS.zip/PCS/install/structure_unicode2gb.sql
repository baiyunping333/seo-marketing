CREATE TABLE `PREFIX_unicode2gb` (
  `unicode` varchar(6) NOT NULL default '',
  `gb` varchar(6) NOT NULL default '',
  KEY `gb` (`unicode`,`gb`)
) TYPE=MyISAM;