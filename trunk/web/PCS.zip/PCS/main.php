<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once 'parse_site.php';
	global $website;
	$Tpl->assign( 'UserId', $UserId );

	$Res = mysql_query( " select site,sitename,sitedes,email,manager,all_count,all_count_ip from $TableList[users]  where website = '$website'" );
	$SiteInfo = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$Tpl->assign( 'SiteInfo', $SiteInfo );

	//���������С����
	$Res = mysql_query( "SELECT max( day_count ) as maxcount , max( day_count_ip ) as maxcountip , min( day_count ) as mincount, min( day_count_ip ) as mincountip FROM $TableList[day_data] where website = '$website'" );
	$MaxMin = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$Tpl->assign( 'MaxMin', $MaxMin );

	//ͳ�ƿ�ʼ��ͳ������
	$Res = mysql_query( " select times  from $TableList[day_data] where website = '$website' order by times asc" );
	$FirstDay = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$FirstDay[times] = intval( $FirstDay[times] ) == 0 ? time() - 1 : $FirstDay[times];
	$Tpl->assign( 'FirstDay', $FirstDay[times] );
	$Tpl->assign( 'CountDays', ceil( ( time() - $FirstDay[times] ) / 24 / 60 / 60 ) );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),date("d")-1,date("Y") );
	$Res = mysql_query( " select day_count, day_count_ip  from $TableList[day_data] where times = $Times and website = '$website'" );
	$YesterdayInfo = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$Tpl->assign( 'YesterdayInfo', $YesterdayInfo );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),date("d"),date("Y") );
	$Res = mysql_query( " select day_count, day_count_ip  from $TableList[day_data] where times = $Times and website = '$website'" );
	$TodayInfo = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$Tpl->assign( 'TodayInfo', $TodayInfo );

	//����ͳ��
	$Times = mktime (0,0,0,date("m"),1,date("Y") );
	$Res = mysql_query( " select * from $TableList[month_data] where times = $Times and website = '$website'" );
	$MonthInfo = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$Tpl->assign( 'MonthInfo', $MonthInfo );


	//ͳ����������
	$OnlineTime = 20;
	$Time = time() - $OnlineTime * 60;
	$Res = mysql_query( "SELECT * FROM $TableList[ip] WHERE time >= $Time GROUP BY ip" );
	$OnlineCount = intval( mysql_num_rows($Res) );


	//ͳ������
	$Countlink = 'http://' . $_SERVER["HTTP_HOST"] . ( $_SERVER["SERVER_PORT"] != 80 ? $_SERVER["SERVER_PORT"] : '' ) . dirname( $_SERVER["PHP_SELF"] ) . '/count/count.js';
	$Tpl->assign( 'Countlink', $Countlink );
	$Tpl->assign( 'website', $website );

	$Tpl->assign( 'OnlineTime', $OnlineTime );
	$Tpl->assign( 'OnlineCount', $OnlineCount );
	
	$Tpl->assign( 'Main', $Tpl->fetch( 'main_info.html' ) );

	$Tpl->assign( 'Title', '�ſ� - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'NowView', '�ſ�' );
	$Tpl->assign( 'QuickLink', '<a href="stat_day.php">ʱ�η���</a> <a href="stat_month.php">�նη���</a> <a href="stat_year.php">�·��� </a> <a href="stat_alexa.php">Alexa������</a>' );
	_out( $Tpl->fetch( 'main.html' )  );
?>