<?
/*
 �������ǿ�Դ���룬���ʹ��
 ԭ����: ����
 �޸��ߣ�������wiwiboy��
 ֣�ݴ�ѧ����˹����ѧԺ������Ϣ����רҵ
 �绰��13733804908
 ���䣺wiwiboy@126.com
 QQ�ţ�158839753
*/
	session_start();
	include_once './include.inc/config.inc.php';
	include_once 'session.php';

	include_once './include.inc/conn.db.inc.php';
	include_once './include.inc/global.inc.php';
	include_once './include.inc/tpl.inc.php';
	include_once './include.inc/function.php';
	include_once 'parse_site.php';
	global $website;
	Initialize( $_GET, array( 'page'=>'intval' ) );
	include_once 'initmenu.php';
	$Year = date( 'Y' );
	$Month = date( 'm' );
	$Day = date( 'd' );
	$StartTime = mktime (0,0,0,$Month,$Day,$Year );
	$EndTime = mktime (0,0,0,$Month,$Day+1,$Year );
	//echo $sitecode;
	//��¼����
	$Res = mysql_query( " select count(*) as count  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and  website = '$website'" );
	$Count = mysql_fetch_array( $Res, MYSQL_ASSOC );
	$DataCount = $Count[count];

	$PageSize = 20;
	if( $DataCount > 0 )
	{
		include_once ( './include.inc/page.inc.php' );
		$PageItems = MakePageItems ( $DataCount, $PageSize );
		$PageLinks = MakePageLinks ( $PageItems, '��¼','��' );
		$Tpl->assign( 'PageLinks', $PageLinks );
	}

	$Res = mysql_query( " select *  from $TableList[ip] where `time` <= $EndTime and `time` >= $StartTime and website = '$website' ORDER BY `time` DESC LIMIT " . intval( $PageItems[Offset] ) . ", $PageSize " );

	include_once './include.inc/function_timezone.php';
	include_once './include.inc/function_language.php';

	while( $Tmp = mysql_fetch_array( $Res, MYSQL_ASSOC ) )
	{
		$Tmp[language] = GetLanguage( $Tmp[language] );
		$Tmp[timezone] = GetTimeZone( $Tmp[timezone] );
		preg_match( "|http://[^/]+?(/.*)|is", $Tmp[pageurl], $Tmp1 );
		$Tmp[pagesite] = trim( $Tmp1[1] );

		if( $Tmp[firsttime] == $Tmp[lasttime] )
		{
			$Tmp[isfirst] = "<span style='color:red'>*</span>";
		}

		$Datas[] = $Tmp;
	}

	$Tpl->assign( 'Datas', $Datas );

	$Tpl->assign( 'Main', $Tpl->fetch( 'show_today.html' ) );

	$Tpl->assign( 'Title', '������ϸ - PCS��վ��������Ϣͳ��ϵͳ' );
	$Tpl->assign( 'QuickLink', '<a href=toexcel.php>����Ϊ�ļ�</a>  |   <a href=a.php target=_blank>��ӡ��ϸ</a>' );
	$Tpl->assign( 'NowView', '��ϸ����' );
	_out( $Tpl->fetch( 'main.html' )  );
?>